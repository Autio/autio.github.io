"""Freeze review artifacts without publishing or selecting a license."""
from pathlib import Path
import hashlib,json,zipfile,shutil,datetime

workspace=Path(__file__).resolve().parents[2]
root=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

# Self-contained TeX source: embedded bibliography, no local style assets.
with zipfile.ZipFile(root/'arxiv-source-draft.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(root/'manuscript/main.tex','main.tex')

files=[]
for p in root.iterdir():
    if p.is_file() and p.suffix in ('.py','.ps1','.md','.json','.log'):
        if p.name not in ('snapshot-manifest.json','package-validation.json'):files.append(p)
files += [root/'manuscript/main.tex',root/'manuscript/main.pdf',root/'manuscript/main.log']
files += [p for p in (root/'lean').iterdir() if p.is_file() and p.suffix in ('.lean','.log','.md','.json')]
legacy=workspace/'outputs/frontier-scan'
files += [legacy/n for n in ('general_complement.py','cut_transport.py','curvature_probe.py','general-theorem.md','sharp-theorems.md','mincut-algorithm.md','structural-theorem.md')]
files += [p for p in (legacy/'lean').iterdir() if p.is_file() and p.suffix in ('.lean','.log','.md','.json')]
files += [legacy/'lean/lean-toolchain']
page=workspace/'site/ai-science/sparse-transport/index.html';files.append(page)
manifest={'date':'2026-10-21','status':'unpublished review draft; license not selected',
    'files':[{'path':p.relative_to(workspace).as_posix(),'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(set(files))]}
(root/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2))
files.append(root/'snapshot-manifest.json')
with zipfile.ZipFile(root/'reproducibility-draft.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(workspace).as_posix())

# Deliberately allowlisted website artifact set; no inherited outreach files.
release=root/'website-release/ai-science/sparse-transport';release.mkdir(parents=True,exist_ok=True)
html=page.read_text(encoding='utf-8')
html=html.replace('../../../outputs/algorithm-frontier/manuscript/main.pdf','paper.pdf')
html=html.replace('../../../outputs/algorithm-frontier/arxiv-source-draft.zip','arxiv-source-draft.zip')
html=html.replace('../../../outputs/algorithm-frontier/reproducibility-draft.zip','reproducibility-draft.zip')
html=html.replace('../../../outputs/','research/outputs/')
(release/'index.html').write_text(html,encoding='utf-8')
for p in files:
    if p==page:continue
    dest=release/'research'/p.relative_to(workspace);dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,dest)
shutil.copy2(root/'manuscript/main.pdf',release/'paper.pdf')
shutil.copy2(root/'arxiv-source-draft.zip',release/'arxiv-source-draft.zip')
shutil.copy2(root/'reproducibility-draft.zip',release/'reproducibility-draft.zip')
with zipfile.ZipFile(root/'website-release-draft.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((root/'website-release').rglob('*')):
        if p.is_file():z.write(p,p.relative_to(root/'website-release').as_posix())
print(json.dumps({'snapshot_files':len(files),'arxiv_zip_bytes':(root/'arxiv-source-draft.zip').stat().st_size,
    'reproducibility_zip_bytes':(root/'reproducibility-draft.zip').stat().st_size,
    'website_zip_bytes':(root/'website-release-draft.zip').stat().st_size},indent=2))
