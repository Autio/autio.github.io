import Mathlib.Tactic

/-!
Conditional integer arithmetic for a universal Hall-obstruction filter.
This file does not formalize graph curvature, transport duality, or the
graph-theoretic derivation of the hypotheses. No inherited source is imported.
-/

namespace Curvature.SparseFilter

def bk (k : ℤ) : ℤ := max (k + 1) (2 * k - 2)

def hallNumerator (a beta d s p q : ℤ) : ℤ :=
  (s + p - beta) * a + d * (p + q)

def upperNumerator (k a beta d : ℤ) : ℤ :=
  (bk k - beta) * a + d * (k - 1)

/-- The pair-counting restriction improves the crude bound on s+p. -/
theorem sum_bound (k s p : ℤ)
    (hs : s ≤ k) (hp : p ≤ k - 1)
    (hpair : 2 ≤ p → s + 1 ≤ k) : s + p ≤ bk k := by
  unfold bk
  by_cases h : 2 ≤ p
  · have hsmall := hpair h
    have hmax := le_max_right (k + 1) (2 * k - 2)
    omega
  · have hmax := le_max_left (k + 1) (2 * k - 2)
    omega

/-- Nonnegative coefficients allow the two combinatorial upper bounds
to be substituted in the weighted Hall numerator. -/
theorem universal_upper_bound (k a beta d s p q : ℤ)
    (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hsp : s + p ≤ bk k) (hpq : p + q ≤ k - 1) :
    hallNumerator a beta d s p q ≤ upperNumerator k a beta d := by
  have hfirst : 0 ≤ (bk k - (s + p)) * a :=
    mul_nonneg (by omega) ha
  have hsecond : 0 ≤ d * (k - 1 - (p + q)) :=
    mul_nonneg hd (by omega)
  unfold hallNumerator upperNumerator
  nlinarith

/-- Every positive Hall numerator survives the universal filter. -/
theorem positive_hall_implies_positive_upper (k a beta d s p q : ℤ)
    (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hsp : s + p ≤ bk k) (hpq : p + q ≤ k - 1)
    (hpositive : 0 < hallNumerator a beta d s p q) :
    0 < upperNumerator k a beta d := by
  exact lt_of_lt_of_le hpositive
    (universal_upper_bound k a beta d s p q ha hd hsp hpq)

/-- If beta is at least twice the universal coefficient, a surviving
filter forces the other side to be small. This holds for arbitrary integer
k: positivity itself excludes the cases k <= 1. -/
theorem surviving_large_beta_small_a (k a beta d : ℤ)
    (ha : 0 ≤ a) (hd : 0 ≤ d) (hdb : d ≤ beta)
    (hbeta : 2 * bk k ≤ beta)
    (hpositive : 0 < upperNumerator k a beta d) :
    a < 2 * (k - 1) := by
  have hbetanonneg : 0 ≤ beta := le_trans hd hdb
  have hmax : k + 1 ≤ bk k := le_max_left _ _
  have hbkbeta : bk k ≤ beta := by omega
  have hk : 2 ≤ k := by
    by_contra h
    have hfirst : (bk k - beta) * a ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg (by omega) ha
    have hsecond : d * (k - 1) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos hd (by omega)
    unfold upperNumerator at hpositive
    omega
  have hbetapos : 0 < beta := by omega
  have hreplace : 0 ≤ (beta - d) * (k - 1) :=
    mul_nonneg (by omega) (by omega)
  have hhalf : 0 ≤ (beta - 2 * bk k) * a :=
    mul_nonneg (by omega) ha
  by_contra h
  have hproduct : 0 ≤ beta * (a - 2 * (k - 1)) :=
    mul_nonneg (by omega) (by omega)
  unfold upperNumerator at hpositive
  nlinarith

/-- Every surviving filter has at least one small side. -/
theorem surviving_small_side_disjunction (k a beta d : ℤ)
    (ha : 0 ≤ a) (hd : 0 ≤ d) (hdb : d ≤ beta)
    (hpositive : 0 < upperNumerator k a beta d) :
    beta < 2 * bk k ∨ a < 2 * (k - 1) := by
  by_cases h : beta < 2 * bk k
  · exact Or.inl h
  · exact Or.inr (surviving_large_beta_small_a k a beta d ha hd hdb
      (by omega) hpositive)

/-- Combined conditional conclusion from the original Hall hypotheses. -/
theorem positive_hall_small_side (k a beta d s p q : ℤ)
    (ha : 0 ≤ a) (hd : 0 ≤ d) (hdb : d ≤ beta)
    (hs : s ≤ k) (hp : p ≤ k - 1)
    (hpair : 2 ≤ p → s + 1 ≤ k) (hpq : p + q ≤ k - 1)
    (hpositive : 0 < hallNumerator a beta d s p q) :
    beta < 2 * bk k ∨ a < 2 * (k - 1) := by
  apply surviving_small_side_disjunction k a beta d ha hd hdb
  exact positive_hall_implies_positive_upper k a beta d s p q ha hd
    (sum_bound k s p hs hp hpair) hpq hpositive

#print axioms sum_bound
#print axioms universal_upper_bound
#print axioms positive_hall_implies_positive_upper
#print axioms surviving_large_beta_small_a
#print axioms surviving_small_side_disjunction
#print axioms positive_hall_small_side

end Curvature.SparseFilter
