"""Adaptive exact edge transport under a complement codegree bound.

Independent new reducer; the earlier implementation is retained unchanged
for replay. Large graph orders use the sharper persistent localization.
"""
from pathlib import Path
import sys
from fractions import Fraction
from itertools import combinations
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'frontier-scan'))
from general_complement import preprocess
from batched_transport import transport_cost


def edge_curvature(adj,x,y,k,data,certificate=False,force_reduce=False):
    h,common,_=data;n=len(adj)
    if len(adj[x])>len(adj[y]):x,y=y,x
    a,b=len(adj[x]),len(adj[y]);d=b-a
    R=set(common[x][y]);alpha=1+len(h[y])-len(R)
    beta=1+len(h[x])-len(R);c=a-alpha
    large=n>=k*k+k+2
    persistent_bound=max(k+1,2*k-2)
    bound=persistent_bound if large else k*k-k+1
    hall_upper=(persistent_bound-beta)*a+d*(k-1)
    if not force_reduce and (k==1 or beta>bound or hall_upper<=0):
        return Fraction(c,b),{'shortcut':True,'large_order':large,'beta':beta,
                             'target_bound':bound,'hall_upper_bound':hall_upper}
    A={y}|(h[y]-h[x]);B=sorted({x}|(h[x]-h[y]));index={v:j for j,v in enumerate(B)}
    rows={}
    def add_row(weight,exception):
        if weight:rows[exception]=rows.get(exception,0)+weight
    for u in sorted(A):
        exception=[]
        for s in common[x][u]:
            if s not in index:continue
            count=n-len(h[u])-len(h[s])+len(common[u][s])
            exception.append((index[s],2 if count else 3))
        assert len(exception)<=k
        add_row(b,tuple(sorted(exception)))
    if d and not large:
        for u in adj[x]&adj[y]:
            exception=tuple(sorted((index[s],2) for s in common[x][u] if s in index))
            assert len(exception)<=k
            add_row(d,exception)
    elif d:
        outside=A|set(B)|R;multiple=set()
        for s,t in combinations(B,2):
            multiple.update(v for v in common[s][t] if v not in outside)
        patterns={};miss_count=[0]*beta
        for u in multiple:
            mask=tuple(sorted(index[s] for s in common[x][u] if s in index))
            assert 2<=len(mask)<=k
            patterns[mask]=patterns.get(mask,0)+1
            for j in mask:miss_count[j]+=1
        single_total=0
        for j,s in enumerate(B):
            missing=len(h[s])-sum(v in h[s] for v in outside)
            single=missing-miss_count[j]
            assert single>=0
            if single:patterns[(j,)]=single
            single_total+=single
        empty=c-len(multiple)-single_total
        assert empty>=0
        if empty:patterns[()]=empty
        for mask,count in patterns.items():add_row(d*count,tuple((j,2) for j in mask))
    exceptions=list(rows);supplies=[rows[row] for row in exceptions]
    assert sum(supplies)==a*beta
    encoding='segment' if large else 'dense'
    cost,proof=transport_cost(supplies,[a]*beta,exceptions,index[x],
                              certificate=True,encoding=encoding)
    value=1-Fraction(cost,a*b)
    meta={'shortcut':False,'large_order':large,'beta':beta,'target_bound':bound,
          'sources':len(supplies),'exception_incidence':sum(map(len,exceptions)),
          'hall_upper_bound':hall_upper,'encoding':encoding,'solver':'batched_primal',
          'network':{z:v for z,v in proof.items() if z not in ('source_potentials','target_potentials')}}
    if certificate:meta['dual']=proof
    return value,meta


def all_curvatures(adj,k):
    data=preprocess(adj,k);answer={};stats=[]
    for x in range(len(adj)):
        for y in adj[x]:
            if x<y:
                answer[x,y],meta=edge_curvature(adj,x,y,k,data);stats.append(meta)
    return answer,{'neighbor_pair_updates':data[2],'edges':len(answer),
       'shortcuts':sum(s['shortcut'] for s in stats),
       'largest_sources':max((s.get('sources',0) for s in stats),default=0),
       'network_arcs':sum(s.get('network',{}).get('arcs',0) for s in stats)}
