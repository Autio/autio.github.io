> Historical first-stage review. The current manuscript and stage2-* reviews supersede its solver bounds and implementation status. This file is retained as research history.

# Bounded novelty audit: exact curvature with bounded complement codegree

21 October 2026. One bounded primary-literature pass. No external messages, paid research jobs, or manuscript edits were made. This review concerns uniform **open-neighborhood measures at idleness zero**, unequal degrees included, and non-induced exclusion of K_{2,k+1} from the complement. It is an assessment of a research candidate, not a priority certificate.

## Assessment

The worthwhile candidate is the **combination of sharp Hall-obstruction localization, indexed construction of a transport instance whose size depends only on complement codegree, and exact all-edge computation in poly(k)n² time**. The sharp finite-order cutoff makes this a stronger structural story than an isolated implementation speedup. The inspected literature did not contain that combined result.

The following should not be advertised as discoveries: canceling common mass; aggregating identical cost rows; matching/Hall or flow formulations; integral transport potentials; bounded-label implication networks; interval encodings of dense implications; and exploiting a small side of a bipartite flow network. The exponent improvement obtained by using these tools is valuable, but is primarily a consequence of the new structural bound. A general identical-row compression theorem by itself would be too elementary to carry a paper.

My assessment is **plausible focused graph-curvature/algorithmic-combinatorics contribution**, especially together with the sharp structural results. There is insufficient evidence to claim a major algorithms breakthrough, a new general transport paradigm, or an optimal dependence on k. The strongest publication case is a coherent theorem package, not the number 19, 11, 9, or a still smaller polynomial exponent.

## Primary sources actually inspected

1. **Christy Kelly, Exact Expressions and Reduced Linear Programmes for the Ollivier Curvature in Graphs**, [arXiv:1909.12156v2](https://arxiv.org/html/1909.12156v2). Theorem 4 states integral optimal potentials; Corollary 5 splits the calculation according to the anchored endpoint difference; Theorem 9 gives reduced programs associated with components of a local core. This is directly relevant zero-idleness prior art. It prevents a novelty claim for integer-potential enumeration or reduced curvature LPs in general. The proposed difference is the codegree-only dimension bound and the indexed all-edge construction. No such bound was identified in the inspected statements. The argument that the proposed construction is not merely Theorem 9 with new notation should be explicit in any paper.

2. **Bhaskar DasGupta, Elena Grigorescu, Tamalika Mukherjee, On computing Discretized Ricci curvatures of graphs: local algorithms and (localized) fine-grained reductions**, [author-hosted full text](https://bdasgup.github.io/resume/publ/papers/local-ricci.pdf). Section 2.1 explicitly uses **closed neighborhoods**; Fact 1 cancels the endpoints as well as common neighbors. Theorem 3 relates ternary minimum-weight perfect matching to its curvature LP, including unequal-degree cases under specified conditions. This is important algorithmic prior art but not an identical measure convention. Its dependence on original degrees does not state the proposed complement-codegree localization. A citation must preserve this convention distinction rather than casually describing the paper as an open-neighborhood zero-idleness algorithm.

3. **Michael Lampis, Algorithmic Meta-theorems for Graphs of Bounded Vertex Cover**, [arXiv:0910.0582v2 PDF](https://arxiv.org/pdf/0910.0582). Definitions 1–2 define identical vertex types and neighborhood diversity. Lemma 1 bounds diversity using vertex cover. Theorem 5 describes the clique/independent-set structure of the classes and their algorithmic recognition; Theorem 6 gives algorithms for several graph problems. Numbering is version-dependent: the indexed later paper titled *Algorithmic Meta-theorems for Restrictions of Treewidth* labels the corresponding structural theorem Theorem 7; its old author URL failed, so the reliable inspected reference here is the arXiv version. This is clear antecedent for aggregation by neighborhood type, but a global twin partition is stronger than the proposed equality of cost rows on one edge's residual targets.

4. **Rémy Belmonte and Martin Vatshelle, On classes of graphs with logarithmic boolean-width**, [arXiv:1009.0216v2](https://arxiv.org/pdf/1009.0216). Section 3.7 and Theorem 3.20 bound boolean-width of complements of degenerate graphs; Theorem 5.5 concerns their specified vertex-partitioning problems. This is pertinent precedent for algorithms exploiting dense complements and structured neighborhoods. It is neither a transport theorem nor a complement-codegree theorem. In particular, codegree does not bound degeneracy: incidence graphs of projective planes have codegree at most one and arbitrarily large regular degree. That last comparison is an elementary mathematical observation used here, not a claim extracted from this paper.

5. **A. Volgenant, Linear and semi-assignment problems: A core oriented approach**, [Computers & Operations Research 23 (1996), 917–932](https://www.sciencedirect.com/science/article/pii/030505489600010X), [DOI](https://doi.org/10.1016/0305-0548(96)00010-X). The primary publisher abstract was inspected; it studies dense assignment, sparse cores, and semi-assignment. Full text was not available in this pass, so no theorem-level statement about identical rows is attributed to it. The exact row-merging statement below is independently proved and treated as elementary standard optimization, not credited to a theorem that was not read.

The coordinating flow audit additionally identified Ahuja–Orlin–Stein–Tarjan, *Improved Algorithms for Bipartite Network Flow* (1991), [Princeton report 338](https://www.cs.princeton.edu/techreports/1991/338.pdf). My independent browser fetch returned 403; I therefore rely on the separate audit for its exact bound and hypotheses. This must be cited as the classical small-side flow subroutine if used. Neither that subroutine nor a vertex-cover interpretation should be claimed as new.

## Why standard graph parameters do not settle the claim

**Neighborhood diversity / twins.** A direct counterexample rules out global neighborhood diversity bounded by k: let H be a sufficiently long path. Its maximum codegree is one; H has no twin classes of bounded total number, and taking complements preserves the twin relation. Hence G has unbounded neighborhood diversity. In the transport reduction, two common sources can have the same distances to B while having different neighbors elsewhere. The partition is relative to a small target set and a cost matrix. That distinction is mathematically real, although the idea of such relative types is standard.

**Induced matchings and mim-width.** There is actually a positive relationship that should not be overlooked. Every bipartite cut of G has induced matching number at most k+2. If its induced matching is a_i b_i for i=1,…,r, then a_1 and a_2 have all b_3,…,b_r as common neighbors in H, giving r−2≤k. Thus every branch decomposition has mim-width at most k+2. This deduction is included here as an elementary comparison, not as a new theorem claim. Generic bounded-mim-width dynamic programming is therefore relevant background; it does not by itself give the required exact weighted transport algorithm with poly(k)n² total complexity. A comparison should distinguish an n^{O(k)} type bound from a polynomial dependence on k multiplying n², and should not assert that this class has unbounded mim-width.

**Small vertex cover / small side of transport.** The residual bipartite source-target graph has vertex cover B simply because every transport arc meets B. Once beta=O(k) has been proved, small-side network-flow results become natural. This is a reason to optimize the solver using existing literature, not a reason to assign novelty to a new graph parameter. The source of the small side, the sharp order cutoff, and obtaining all capacities without scanning C remain the specific structural issues.

**Sparse complements.** Codegree and maximum degree are very different restrictions. H can have very high degrees at fixed k. Thus a bounded-complement-degree algorithm would not automatically cover the proposed class. Conversely, sparsity of H alone does not prove that only O(k) residual targets need attention at an exceptional edge. The indexed pair-intersection preprocessing and Hall argument provide extra information.

**Formal concept lattices / closed sets.** Replacing Hall subsets by closures, or describing equal incidence rows as object types, is an alternative language for the same incidence information. This pass found no primary curvature or transport result showing that such machinery supplies this exact codegree localization and total runtime. The search on this connection was weak and produced no useful primary source; it is not grounds to assert that the formal-concept literature lacks a related compression result. Avoid making a broad claim about that literature. Neither closed-set enumeration nor exact row merging alone proves that the number of relevant objects is bounded by k.

## A defensible general compression lemma

The following is a useful supporting proposition, with a short self-contained proof. It is not proposed as a stand-alone novelty claim.

Let a transport instance have sources U, targets Q of size q, nonnegative supplies s_u and demands summing to the same total, and costs c(u,t). Suppose a subset of sources has costs

    c(u,t) = a_u + b_t + delta * 1[t belongs to M(u)],

where delta is fixed and M(u) is a subset of Q. Suppose every pair of targets belongs to at most lambda of these masks, counting source vertices rather than just distinct masks. Then these sources can be replaced by at most

    1 + q + lambda * binomial(q,2)

rows, retaining the remaining sources separately, without changing the optimum except for the known offset sum_u a_u s_u. More generally, rows differing only by an additive row constant can be aggregated with this offset even without the mask assumption. Rational weights and unequal supplies cause no difficulty.

Proof: subtract row constants and the common column term. Aggregate each equal mask by adding its supplies. Any original plan sums to a quotient plan; any quotient row can be split proportionally to original supplies within its class, preserving demands and costs. There is at most one empty mask and q singleton masks. Every remaining source consumes at least one target-pair incidence; their number is at most lambda*binomial(q,2). This also bounds their distinct types. The existence of the quotient does not guarantee efficient construction from an implicit input: the indexed construction must still be proved separately.

A sharper count for **distinct** masks, valid for lambda>=1, is

    |F| <= 1 + q + ((lambda+2)/3) * binomial(q,2).

Indeed, writing N2 for the number of distinct masks of size two and N3 for the number of larger ones gives N2<=binomial(q,2) and N2+3N3<=lambda*binomial(q,2). Therefore N2+N3<=((lambda+2)/3)*binomial(q,2). Floors can be added. At q=k and lambda=k−1, the family consisting of all subsets of size at most three attains this bound: each pair appears in its own pair-mask and in k−2 triple-masks. Consequently cubic order is sharp for this incidence-type counting mechanism. This is a simple pair-budget extremal argument, and should be presented as such.

For the proposed curvature application, use lambda=k−1 because x already occupies one common H-neighbor slot for every pair of targets in Q=B\{x}. Common-source distances to B are exactly encoded by those masks, while exclusive sources require their own treatment. The common-source mass is positive only when endpoint degrees differ. A claimed cubic lower example for **active exceptional curvature kernels** must verify this and actual Hall deficiency; a cubic incidence graph by itself is not sufficient.

The row count does **not** prove an Omega(k³) lower bound for computing curvature, for every possible kernel, or for the compressed implication graph. A solver may exploit the pair-incidence representation without constructing every cost entry, and may bypass an edge whose value already equals the triangle bound.

## Recommended claim and presentation

Subject to correctness of the separate runtime audit, the defensible headline is:

> For connected graphs whose complements have maximum pair codegree k, all zero-idleness Ollivier edge curvatures can be computed exactly in poly(k)n² word-RAM time. Sharp Hall-obstruction bounds identify the edges requiring transport and yield bounded weighted transport instances constructible after shared quadratic preprocessing. Above a sharp finite-order cutoff the residual target size is linear in k.

Put the final, verified exponent in the theorem, but describe a classical flow/interval data structure as a subroutine. Explain the input model, O(log n)-bit arithmetic, unreduced rational output, and that quadratic order is optimal for explicit all-edge output in this dense class. A row-count sharpness statement should be scoped to the aggregation scheme. The finite-order cutoff and structural extremizers are better evidence of mathematical substance than a large exponent improved by substituting a textbook solver.

Do not use the formal phrase “polynomial kernel” without qualification: the weighted instance has a number of vertices bounded by k, but its capacities carry O(log n) bits. A polynomial-size **weighted transport reduction in numbers of rows/targets** is a safe description; a kernel whose total encoding length is polynomial only in k needs a separate argument.

## Search limitations

The pass used eight targeted search queries and inspected four full primary texts plus a primary publisher abstract, with failed old-author-link retries and within-document theorem lookups. Search themes were exact Ollivier algorithms with complement codegree, biclique-free neighborhood complexity, neighborhood diversity, boolean/mim-width, identical transport rows, formal concepts with curvature/transport, and sparse-complement matching. The unavailable small-side-flow report was checked only for access in this pass. No identical theorem appeared, but synonym coverage, citations beyond these texts, unpublished work, and easy corollaries remain genuine uncertainties. A focused expert priority query would still be appropriate before a public claim of novelty; this review does not send one.
