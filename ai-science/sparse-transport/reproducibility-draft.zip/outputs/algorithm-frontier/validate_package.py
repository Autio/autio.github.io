"""Verify archive hashes, source completeness and deployment-page local links."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
import json,zipfile,hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'snapshot-manifest.json').read_text())
with zipfile.ZipFile(root/'reproducibility-draft.zip') as z:
    for entry in manifest['files']:
        raw=z.read(entry['path'])
        assert len(raw)==entry['bytes']
        assert hashlib.sha256(raw).hexdigest()==entry['sha256'],entry['path']
with zipfile.ZipFile(root/'arxiv-source-draft.zip') as z:
    assert z.namelist()==['main.tex']
    assert z.read('main.tex')==(root/'manuscript/main.tex').read_bytes()
    assert b'\\begin{thebibliography}' in z.read('main.tex')
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[];self.ids=set()
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.add(attrs['id'])
        if tag=='a' and 'href' in attrs:self.links.append(attrs['href'])
page=root/'website-release/ai-science/sparse-transport/index.html'
parser=Links();parser.feed(page.read_text(encoding='utf-8'))
checked=0
for link in parser.links:
    url=urlparse(link)
    if url.scheme or url.netloc:continue
    if not url.path:
        assert not url.fragment or url.fragment in parser.ids,link
    else:assert (page.parent/unquote(url.path)).is_file(),link
    checked+=1
result={'passed':True,'manifest_entries':len(manifest['files']),
    'arxiv_source_files':['main.tex'],'deployment_local_links_checked':checked,
    'status':'mechanical validation; mathematical novelty and human acceptance unresolved'}
(root/'package-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
