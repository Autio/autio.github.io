"""Separate classical flow-backend effects from the implication encoding."""
from benchmark import instance
from sparse_closure import transport_cost
from pathlib import Path
import sys,time,statistics,json,platform
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'frontier-scan'))
from cut_transport import closure_transport

rows=[]
for k in (5,8,12,16):
    supplies,demands,exceptions,expected=instance(k)
    costs=[[dict(row).get(j,1) for j in range(len(demands))] for row in exceptions]
    result={'k':k}
    for backend in ('dense_edmonds_karp','dense_dinic','segment_dinic'):
        times=[]
        for _ in range(3):
            start=time.perf_counter()
            if backend=='dense_edmonds_karp':value=closure_transport(supplies,demands,costs,0)
            else:value=transport_cost(supplies,demands,exceptions,0,encoding='dense' if backend=='dense_dinic' else 'segment')
            times.append(time.perf_counter()-start);assert value==expected
        result[backend]={'median_seconds':statistics.median(times),'seconds':times}
    rows.append(result);print(json.dumps(result),flush=True)
Path(__file__).with_name('benchmark_backends.json').write_text(json.dumps({'platform':platform.platform(),'python':platform.python_version(),'scope':'synthetic family; classical backend versus encoding ablation','rows':rows},indent=2))
