"""Independent full-transport comparison of the canonical Hall specialization."""
from pathlib import Path
from itertools import combinations
from canonical_transport import edge_curvature
from adaptive_curvature import preprocess
from curvature_probe import complement,connected,transport
from verify import cubic_family
import json,time
root=Path(__file__).resolve().parent;start=time.perf_counter();checked=skipped=graphs=0
for n in range(2,7):
    pairs=list(combinations(range(n),2))
    for mask in range(1<<len(pairs)):
        adj=complement(n,[e for j,e in enumerate(pairs) if mask>>j&1])
        if not connected(adj):continue
        graphs+=1;h=[set(range(n))-{u}-adj[u] for u in range(n)]
        k=max(1,max((len(h[u]&h[v]) for u,v in pairs),default=0));data=preprocess(adj,k)
        for x,y in pairs:
            if y not in adj[x]:continue
            result=edge_curvature(adj,x,y,k,data,allow_small_order=True)
            if result is None:skipped+=1;continue
            actual,proof=result;expected=transport(adj,x,y)
            assert actual==expected,(n,k,x,y,actual,expected,proof)
            checked+=1
    print(json.dumps({'order':n,'checked':checked,'skipped':skipped}),flush=True)
families=[]
for k in range(5,17):
    adj,triples=cubic_family(k);data=preprocess(adj,k)
    actual,proof=edge_curvature(adj,0,1,k,data)
    assert actual==transport(adj,0,1)
    assert proof['scaled_deficit']==k-1 and proof['common_rows_materialized']==0
    families.append({'k':k,'triple_types_bypassed':triples,'value':str(actual)})
result={'passed':True,'graphs':graphs,'eligible_edge_checks':checked,'ineligible_edges_skipped':skipped,
        'families':families,'seconds':time.perf_counter()-start,
        'scope':'all connected labeled graphs through6 for eligible arithmetic/cost regime, plus large cubic families; optional backend'}
(root/'canonical-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
