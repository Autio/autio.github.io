# Stage 2 mathematical referee pass

21 October 2026. Reviewed the final `manuscript/main.tex` afresh, including every mathematical proposition and the algorithm's arithmetic model. This report refers to the version whose abstract stated implemented `O(k^7 log(k+1) n^2)` and theoretical `O(k^5 log(k+1) n^2)` bounds. Subsequent edits may supersede those statements.

## Recommendation and severity

**Major reworking of the algorithm presentation is justified.** I found no counterexample to the manuscript's mathematical theorems, but found two elementary changes that make the special bounded-dual/maximum-closure route unnecessary and improve the bound attained by the simple implemented solver. These should be addressed before presenting the current construction as the central algorithmic contribution.

1. Complete transportation with costs in `{1,2,3}` is solved by at most three classical primal-dual admissible-maxflow stages. This works without graph-metric potential integrality, clipping target labels, or a two-level closure graph.
2. A Hall-numerator upper bound supplies an additional constant-time equality test. Surviving small-order candidates have a small *minimum* bipartition size and only `O(k^3)` dense transport edges. Consequently a small-dense/large-segment hybrid with ordinary current-arc Dinic attains `O(k^5 log(k+1) n^2)` itself. An Orlin backend is no longer needed for that exponent.

There is also a credible completely dense `O(k^5 n^2)` algorithm using the published unbalanced-flow bound of Ahuja--Orlin--Stein--Tarjan. Its published institutional abstract explicitly confirms the requisite formula. I did not retrieve the full proof/theorem statement, so this final strengthening should be checked against the full paper before being advertised as the strongest result.

These developments preserve the value of sharp Hall localization and the indexed source construction. They substantially reduce the role of the special metric dual and cast the flow optimization as established machinery.

## 1. Exact statements checked in the original manuscript

**Residual cancellation and Hall witness lemma: no error found.** Maximizing diagonal mass among optimal plans is legitimate because the feasible transport polytope is compact. The rerouting operation preserves marginals and cannot reduce other diagonal entries. The residual source and target supports are disjoint, so costs are at least one. For a target set S the scaled deficiency is exactly `(s+p-beta)*a+d*(p+q)`. The exclusions of x, singleton sets, and sets larger than k all hold. The restriction `p>=2 => s<=k-1` correctly uses the extra common H-neighbor y.

**General localization proposition: no error found.** The proof uses the sign of `k+p-beta` correctly when replacing a by its lower bound. The final numerical identity is exact. Strict positivity and integrality give the stated `beta<=k^2-k+1`; endpoint-degree bookkeeping then gives the stated upper bounds.

**Cutoff theorem: no error found.** The variables `u=a-p-q>=1` and `h=beta-s-p>=1` are legitimate. The inequalities `hu<=e(s-1)-1` and `u+h<=hu+1` yield the displayed bound on `a+beta`. The cases p<=1 and p>=2 give k^2+1 and k^2-1, respectively. Adding r<=k proves the cutoff. In the sharpness construction, pairs in S have the claimed k witnesses; x,y share exactly R; pairs in the set `{x,z} union W` share at most S. The remaining mixed types do not violate the codegree bound. The construction is connected after complementing for k>=3 and has the claimed strictly negative slope and numerator one. The persistent construction also passes its pair-type and numerator checks.

**Row/incidence lemma: no error found.** Every missing target is in the list `L(x,u)`, so each row has at most k exceptions. The pair budget counts original sources, and aggregating equal masks can only lower that count. The inequality `t<=2*choose(t,2)` is used only for t>=2. Empty and singleton masks are counted separately. The outside set is exactly the complement of C. Consequently singleton counts can be recovered by subtraction without scanning C. Deterministic sorting of O(k^3) masks of length at most k fits the conservative `O(k^4 log(k+1))` construction bound.

**Three-label and sparse-closure lemmas: no error found, but unnecessary for the stronger direct algorithm below.** An anchored integer graph potential exists by the usual difference-constraint integrality. Source values lie between -1 and 1, and target values between -2 and 2. For equal-cost row aggregation, a common best feasible source value remains in [-1,1]: feasibility gives its lower bound, and the cost-one anchor gives its upper bound. Replacing positive target values by zero preserves every inequality. The implication table is exact. Selecting all threshold nodes gives the claimed finite cut, and the constants `M`, `2M`, and `3M-lambda` are consistent. Shared interval implications preserve the closure optimum in both directions.

**Short residual paths and original complexity theorem: no error found.** Deleting the O(beta) terminals/target/helper vertices leaves components of size at most two; reverse arcs do not alter this fact. The argument controls all simple DFS paths, not only shortest successful paths. Current-arc reuse is essential and is present in the implementation. Construction, always-on all-pairs certificate checks, and integer arithmetic all fit the original parameter bounds. Their bounds are weaker than necessary in the small-order branch, as shown below.

**Cubic family: no error found.** I rechecked the nontrivial pair types, the actual source supplies, and the Hall argument. Its triple rows have supply one because d=1. Thus the example really concerns positive-supply rows on defective edges. It proves sharpness only for distinct-row aggregation, exactly as the manuscript now states. Those rows do not force a lower bound for arbitrary optimization methods.

**Order-theoretic appendix: no error found.** The adjunction `B(f)<=g iff f<=A(g)` has the stated direction; AB is extensive and BA reductive. Reachability closure must include the forced anchor, as explicitly specified. These observations do not establish optimization or complexity and should remain optional exposition.

## 2. New necessary inequality: a small side on every surviving candidate

Put `b_k=max(k+1,2k-2)`. The Hall lemma already proves, at **every order**, that

    s+p <= b_k.

Indeed p<=1 gives s+p<=k+1. For p>=2, one has s<=k-1 and p<=k-1, giving s+p<=2k-2. Therefore every deficient witness satisfies

    0 < F = (s+p-beta)*a + d*(p+q)
          <= (b_k-beta)*a + d*(k-1) =: U.

This gives a valid constant-time equality shortcut whenever `U<=0`. It does not require the large-order cutoff.

Now retain only candidates with U>0. If beta<2*b_k, the target side already has O(k) vertices. If beta>=2*b_k, then

    (beta-b_k)*a < d*(k-1) < beta*(k-1),

because d=beta-alpha<=beta-1. Hence a<2*(k-1). In every case,

    min(a,beta) = O(k).

For small order, `a+beta<=n<=k^2+k+1`. The original, unaggregated residual transportation instance has m<=a rows and beta targets. Thus

    V = O(k^2),
    E_dense = O(m*beta+m+beta) = O(k^3),
    min(m,beta) = O(k).

The last two statements improve the small-branch analysis materially. They apply to surviving candidates, including candidates whose true curvature still attains equality; no oracle for actual defectiveness is needed.

## 3. Direct transportation needs at most three admissible-maxflow stages

The following is a specialization of classical primal-dual minimum-cost flow, not a proposed new general optimization method. A primary university lecture source describes the same shortest-path/admissible-maxflow iteration: [Lehigh, Graphs and Network Flows, Lecture 17](https://coral.ise.lehigh.edu/~ted/files/ie411/lectures/Lecture17.pdf). The sharper constant stage count below follows from completeness and the fixed cost range.

### Network and helper-flow projection

Construct a super-source s, source-row vertices i, target vertices j, and a super-sink t. Give s->i capacity U_i and cost zero, and j->t capacity V_j and cost zero. For every pair add capacity M+1 and cost c_ij in {1,2,3}, where M is total mass.

The sparse variant uses one shared segment tree for cost-one intervals. Source-to-cover arcs have cost one; tree-parent-to-child arcs have cost zero. Leaves are targets. Keep direct cost-two and cost-three exception arcs. All these internal arcs have capacity M+1.

This is an exact primal encoding. A matrix plan routes each pair's flow along its corresponding direct arc or tree path. Conversely the original network is a directed acyclic graph, so any feasible flow decomposes into source-to-sink paths. Each path goes from one source row through an allowed cost-one interval, or through its specified cost-two/three exception, to a target. Shared helper flow creates no additional allowed row/target pair. Decomposing paths yields a transportation plan with the same marginals and cost.

Every original internal arc carries at most the current total flow, at most M. Thus its capacity M+1 is never saturated. This fact is needed in the three-stage proof.

### Explicit pseudocode with safe potential updates

Use the reduced-cost convention `r(u,v)=c(u,v)+p(u)-p(v)`.

    flow := zero flow
    p(v) := 0 for every vertex
    sent := 0
    total_cost := 0
    while sent < M:
        d := shortest distances from s in the current residual graph,
             using nonnegative reduced costs r
        D := d(t)
        for every vertex v:
            p(v) := p(v) + min(d(v),D)
            # d(v)=infinity when unreachable, so the increment is D
        lambda := p(t)-p(s)
        form the residual subgraph of arcs with reduced cost zero
        augment a MAXIMUM s-to-t flow Delta in that subgraph
        sent := sent + Delta
        total_cost := total_cost + lambda*Delta
    return total_cost

The clipping in this pseudocode is deliberate. Leaving unreachable potentials unchanged can be harmless on the positive-support transportation network, but it does not maintain a globally feasible reduced-cost potential and complicates zero-supply certificates. The clipped update preserves nonnegative reduced costs on every positive-capacity residual arc, including arcs leaving unreachable helper vertices. It is preferable for both proof and implementation.

### Correctness and phase count

Initially all active original costs are nonnegative, so p=0 is feasible. If reduced costs are nonnegative and d are shortest distances, the clipped increment `delta(v)=min(d(v),d(t))` satisfies

    delta(v) <= delta(u)+r(u,v)

on every residual arc. For arcs leaving an unreachable vertex, delta(u)=d(t)>=delta(v), which suffices. An arc from a reachable vertex to an unreachable vertex cannot have positive residual capacity. Thus the updated potential is globally feasible.

Augmenting on zero reduced-cost arcs preserves feasibility: every newly active reverse arc also has reduced cost zero. Therefore the residual graph contains no negative-cost cycle. A feasible flow with that property is minimum-cost among flows of the same value, by the standard residual-cycle optimality argument. Any path in the admissible graph has original cost lambda by telescoping its potentials, justifying the cost accumulator.

At the first stage, the shortest original s-to-t path costs at least one, so lambda>=1. After exhausting a *maximum* admissible flow, there is no residual zero-reduced-cost s-to-t path. If mass remains, the next reduced distance to t is a positive integer. Thus lambda increases by at least one between stages.

While sent<M, choose a row with unused supply and a column with unfilled demand. Their direct transportation route, possibly through helpers, has original cost at most three. Its internal arcs are unsaturated because they have capacity M+1. Its endpoint capacity arcs also have positive residual capacity by the choice of row and target. Hence a residual s-to-t route of original cost at most three always exists. Since p(s)=0, shortest-path updating gives lambda<=3.

Consequently the stage marginal values form a strictly increasing subset of `{1,2,3}`. There are at most three stages, independent of M. Every stage sends positive mass, and completeness ensures that the algorithm reaches total mass M.

This argument does not require metric costs, an anchor target, or the manuscript's three-label lemma. It applies to arbitrary complete integer transportation matrices with entries in {1,2,3}. It must not be confused with greedily freezing a cost-one maximum flow and adding cost-two/three flow: admissible residual stages include reverse arcs and may reroute earlier assignments.

### Certificates and potential handling in the new code

I inspected the first `batched_transport.py` revision supplied during this pass. Its unchanged-unreachable update was safe for positive-supply rows and all targets because all targets are reachable while mass remains, and any positive-supply saturated row can be reached by reversing a positive flow path from a target. Unreachable helpers cannot become newly reachable merely by augmentation. However its zero-supply rows were excluded from the returned dual-feasibility check. I recommended the clipped update above; the owner is applying it.

With clipping, all vertex potentials lie between zero and the current lambda, hence in {0,1,2,3}. Projecting `f_i=-p(i)`, `g_j=-p(j)` gives a feasible transportation dual, including zero-supply rows: every original row/target route is unsaturated, and summing its nonnegative reduced costs proves `f_i-g_j<=c_ij`. On positive-flow routes every internal arc has both forward and reverse residual capacity, so reduced costs are zero. Summing over a flow decomposition gives equality between primal cost and the projected transport dual. This is a direct certificate without the special metric label restriction.

## 4. Complexity of the direct method

At most three shortest-path computations and at most three ordinary maxflow computations are needed. The admissible graph is a subgraph of a residual graph; deleting targets, helpers, and terminals still leaves isolated source rows. Its simple paths have length O(beta), so current-arc Dinic takes O(beta^2 E) per stage.

A binary-heap Dijkstra adds `O(E log(V+1))` per stage. This is absorbed in all parameter bounds below; it should not silently be dropped from an abstract bound for arbitrary m,beta. Alternatively clipped potentials keep all positive-capacity reduced costs in the integer range 0,...,6, permitting a standard constant-range bucket shortest-path implementation in O(E+V) time. No such bucket implementation is needed for the claimed final parameter exponent.

### Simple implemented hybrid

On the **small-order branch**, use the dense original transportation network after the U shortcut. It is bipartite, including terminals: the parts are `{targets,s}` and `{rows,t}`. Every simple residual path has length `O(min(m,beta)+1)=O(k)`. Thus ordinary Dinic takes `O(k^2 E)=O(k^5)` per stage. Dijkstra, construction, and direct certificate checking are lower-order terms.

On the **large-order branch**, retain the indexed common-source aggregation and use the single shared segment tree. There are O(k^3) rows and total missing incidences, O(k) targets, and `E=O(k^3 log(k+1))`. The O(k) path bound gives `O(k^5 log(k+1))` per stage. Dijkstra's `O(k^3 log^2(k+1))` overhead is absorbed, as is construction.

Therefore an ordinary batched-Dinic implementation achieves

    O(k^5 log(k+1) n^2)

for all edges. Indexed recognition, O(kn^2) storage, unreduced output, and the word-size qualifications remain as in the manuscript. This removes the original gap between the implemented exponent and the theoretical Orlin-backed exponent.

### Does direct unbalanced flow make the segment tree unnecessary?

For the new implemented bound above, the segment tree still improves the large-branch bound over ordinary dense Dinic: the latter has O(k^4) edges and gives O(k^6) per candidate. Thus direct transport alone removes the special dual/closure construction, not automatically the segment representation.

There is a stronger classical-backend option. The published author-institution record for [Ahuja, Orlin, Stein and Tarjan, Improved Algorithms for Bipartite Network Flow, SIAM J. Comput. 23(5), 906--933 (1994)](https://collaborate.princeton.edu/en/publications/improved-algorithms-for-bipartite-network-flow/) explicitly states the capacity-independent bound `O(n_small*E+n_small^3)` for its two-edge FIFO preflow-push variant. This is stronger than the basic Dinic small-side bound. No terminal conversion is necessary for the direct transport network: the bipartition given above already includes s and t.

Using that result in each of the three stages of the **dense** direct network yields:

* Large order: `n_small=O(k)`, `E=O(k^4)`, hence O(k^5).
* Small order after U filtering: `n_small=O(k)`, `E=O(k^3)`, hence O(k^4).

Shortest paths and deterministic row construction fit O(k^5). This supports a completely dense all-edge bound `O(k^5 n^2)` with no segment trees, no bounded metric dual, and no Orlin backend. The exact full-paper hypotheses and algorithm theorem should still be read before making this the headline claim; my PDF access failed and the verification here reaches the primary institutional abstract, not the entire proof. The new simple-Dinic `k^5 log(k+1)` result does not depend on that retrieval.

## 5. Explicit counterexample to a tempting invalid simplification

Large order does **not** force all residual costs to be one or two. For k=3, take vertices x,y,z1,z2,s1,s2,t and H-edges

    x -- {s1,s2,t},
    y -- {z1,z2},
    {z1,z2} -- {s1,s2},
    z1 -- t.

Adjoin arbitrarily many vertices, each H-adjacent only to z1 or only to s1. The maximum H-codegree is three. At xy, alpha=3, beta=4, d=1; the set `{s1,s2}` has F=2>0. Yet every vertex is H-adjacent to at least one of z1,s1, so they have no common G-neighbor and their G-distance is three. The length-three route is z1,x,y,s1. The complement is connected and its order can be arbitrarily large.

A bounded independent check at n=14 confirmed maximum codegree three, large-order classification, distance three, and exact triangle gap 1/55 with a=10,b=11. This does not refute any statement currently made in the manuscript; it rules out replacing the general solver by the one-level cost-one/two formula solely because the order cutoff has been crossed.

## 6. RAM, implementation, and review limits

The manuscript now correctly separates deterministic indexed RAM analysis from Python dictionaries, reduced Fraction outputs, and normalization. Capping k by max(1,n-2) avoids a hidden parameter-bit issue. Original capacities, total flow, costs, and output integers use O(log n) bits. The added U test also uses O(log n)-bit products after this cap. The proof of bounded recognition time on rejected graphs remains valid: each enumerated witness either contributes to one of the bounded lists or triggers immediate rejection.

The exact mathematical claims above were checked by hand; no end-to-end formal proof was produced. Apart from the explicit fourteen-vertex counterexample check, I did not rerun the manuscript's exhaustive edge or GPU experiments during this pass. The owner reports a separate new batched-solver replay over 21,279 complete ternary matrices; that is useful corroboration but is not counted as an experiment independently executed by this referee. I inspected its solver, not every verification harness or historical timing record.

I found no theorem-level disproof of the original manuscript. The principal finding is that its central optimization story should change: the structural Hall bounds and indexed construction are the defensible focus, while direct classical transportation supplies a simpler route to a stronger implemented guarantee. Any AOST-based further strengthening should be credited explicitly as application of a published general flow theorem.
