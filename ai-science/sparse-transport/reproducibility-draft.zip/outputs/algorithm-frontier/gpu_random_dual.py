"""Independent CUDA exhaustive-dual oracle, seeded random marked graphs.

Float32 operations are exact on these tiny integer instances; TF32 disabled.
This is corroboration, not a proof or GPU speedup claim.
"""
import argparse,itertools,json,random,time
from pathlib import Path
import torch

def run(count,n,batch,output):
    assert 3<=n<=9
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    random.seed(2026102104);start=time.perf_counter()
    pairs=[e for e in itertools.combinations(range(n),2) if e!=(0,1)]
    masks=[random.getrandbits(len(pairs)) for _ in range(count)]
    labels=torch.tensor([(0,)+v for v in itertools.product((-1,0,1),repeat=n-1)],device='cuda',dtype=torch.float32)
    index=torch.arange(n,device='cuda');records=[]
    for begin in range(0,count,batch):
        ids=torch.tensor(masks[begin:begin+batch],device='cuda')
        adj=torch.ones((len(ids),n,n),device='cuda');adj[:,index,index]=0
        for j,(u,v) in enumerate(pairs):adj[:,u,v]=adj[:,v,u]=1-((ids>>j)&1).float()
        deg=adj.sum(2);swap=deg[:,0]>deg[:,1]
        perm=index.expand(len(ids),n).clone();perm[swap,0]=1;perm[swap,1]=0
        adj=adj.gather(1,perm[:,:,None].expand(-1,-1,n)).gather(2,perm[:,None,:].expand(-1,n,-1))
        dist=torch.where(adj.bool(),1.,float(n+1));dist[:,index,index]=0
        for u in range(n):dist=torch.minimum(dist,dist[:,:,u,None]+dist[:,None,u,:])
        keep=dist[:,0,:].max(1).values<n
        ids=ids[keep];adj=adj[keep];dist=dist[keep]
        if not len(ids):continue
        nx=adj[:,0,:].bool();ny=adj[:,1,:].bool();A=nx&~ny;B=ny&~nx;C=nx&ny
        a=nx.sum(1).float();b=ny.sum(1).float()
        supply=A.float()*b[:,None]+C.float()*(b-a)[:,None]
        g=torch.full((len(ids),len(labels),n),-2.,device='cuda')
        for u in range(1,n):
            candidate=labels[None,:,u,None]-dist[:,None,u,:]
            g=torch.maximum(g,torch.where(nx[:,None,u,None],candidate,-100.))
        g[:,:,0]=0
        objective=supply@labels.T-(g*B[:,None,:]).sum(2)*a[:,None]
        optimum=objective.max(1).values
        assert torch.equal(optimum,optimum.round())
        for mask,num,den in zip(ids.tolist(),(a*b-optimum).int().tolist(),(a*b).int().tolist()):
            records.append({'mask':mask,'numerator':num,'denominator':den})
    torch.cuda.synchronize()
    result={'seed':2026102104,'n':n,'attempted':count,'connected':len(records),
      'device':torch.cuda.get_device_name(0),'torch':torch.__version__,'seconds':time.perf_counter()-start,
      'method':'all 3^(n-1) anchored source labels; integer-valued float32; TF32 off','records':records}
    Path(output).write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='records'}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--count',type=int,default=4096)
    p.add_argument('--n',type=int,default=9);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--output',required=True);a=p.parse_args();run(a.count,a.n,a.batch,a.output)
