param([string]$Workspace = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path)
$ErrorActionPreference = 'Stop'
$taskMathlib = Join-Path $Workspace 'work/mathlib4'
$taskLean = Join-Path $Workspace 'work/lean-toolchain/lean-4.19.0-windows/bin/lean.exe'
$taskLeanPaths = @((Join-Path $taskMathlib '.lake/build/lib/lean')) + @(Get-ChildItem -LiteralPath (Join-Path $taskMathlib '.lake/packages') -Directory | ForEach-Object { Join-Path $_.FullName '.lake/build/lib/lean' })
$env:LEAN_PATH = $taskLeanPaths -join ';'
$result = [ordered]@{scope='Existing partial supporting lemmas, not end-to-end algorithm formalization';compiler=(& $taskLean --version | Out-String).Trim();sources=@()}
foreach ($name in @('GraphHall','SharpLocalization','CutLabels')) {
    $source = Join-Path $Workspace "outputs/frontier-scan/lean/$name.lean"
    $log = & $taskLean $source 2>&1
    $exit = $LASTEXITCODE
    $log | Set-Content -LiteralPath (Join-Path $PSScriptRoot "$name.recheck.log") -Encoding utf8
    if ($exit -ne 0) { throw "Lean failed: $name" }
    $result.sources += [ordered]@{name="$name.lean";sha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash;exit_code=$exit}
}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean-recheck.json') -Encoding utf8
$result | ConvertTo-Json -Depth 5
