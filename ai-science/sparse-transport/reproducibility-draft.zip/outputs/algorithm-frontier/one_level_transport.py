"""Classical distance-one maxflow specialization for costs in {1, 2}.

Unlike the bounded-dual closure solver, this identity is valid for any
complete transportation matrix with costs one or two. Exceptions list
only cost-two entries. This is an optional independent backend.
"""
from collections import deque


def transport_cost(supplies, demands, exceptions, anchor=None,
                   certificate=False, encoding='dense'):
    m, q = len(supplies), len(demands)
    assert q and len(exceptions) == m
    assert encoding in ('dense', 'segment')
    if anchor is not None:
        assert 0 <= anchor < q
    total = sum(supplies)
    assert total == sum(demands) and all(v >= 0 for v in supplies + demands)
    infinity = total + 1
    src, sink = m + q, m + q + 1
    net = [[] for _ in range(sink + 1)]
    original = []

    def add(u, v, capacity):
        z = len(net[u])
        net[u].append([v, capacity, len(net[v])])
        net[v].append([u, 0, z])
        original.append((u, v, capacity, z))

    for i, amount in enumerate(supplies):
        add(src, i, amount)
    for j, amount in enumerate(demands):
        add(m + j, sink, amount)

    def tree(left, right):
        if right - left == 1:
            return (m + left, left, right, None, None)
        mid = (left + right) // 2
        first, second = tree(left, mid), tree(mid, right)
        u = len(net)
        net.append([])
        add(u, first[0], infinity)
        add(u, second[0], infinity)
        return (u, left, right, first, second)

    root = tree(0, q) if encoding == 'segment' else None

    def interval(source, branch, left, right):
        u, l, r, first, second = branch
        if left <= l and r <= right:
            add(source, u, infinity)
            return
        mid = (l + r) // 2
        if left < mid:
            interval(source, first, left, min(right, mid))
        if right > mid:
            interval(source, second, max(left, mid), right)

    incidence = 0
    for i, row in enumerate(exceptions):
        row = sorted(row)
        assert len({j for j, c in row}) == len(row)
        assert all(0 <= j < q and c == 2 and j != anchor for j, c in row)
        incidence += len(row)
        if encoding == 'dense':
            missing = {j for j, c in row}
            for j in range(q):
                if j not in missing:
                    add(i, m + j, infinity)
        else:
            previous = 0
            for j, c in row:
                if previous < j:
                    interval(i, root, previous, j)
                previous = j + 1
            if previous < q:
                interval(i, root, previous, q)

    flow = phases = augmentations = max_path = 0
    while True:
        level = [-1] * len(net)
        level[src] = 0
        queue = deque([src])
        while queue:
            u = queue.popleft()
            for v, cap, rev in net[u]:
                if cap > 0 and level[v] < 0:
                    level[v] = level[u] + 1
                    queue.append(v)
        if level[sink] < 0:
            break
        phases += 1
        max_path = max(max_path, level[sink])
        current = [0] * len(net)
        path, edges = [src], []
        while path:
            u = path[-1]
            if u == sink:
                amount = min(net[v][z][1] for v, z in edges)
                for v, z in edges:
                    edge = net[v][z]
                    edge[1] -= amount
                    net[edge[0]][edge[2]][1] += amount
                flow += amount
                augmentations += 1
                path, edges = [src], []
                continue
            while current[u] < len(net[u]):
                v, cap, rev = net[u][current[u]]
                if cap > 0 and level[v] == level[u] + 1:
                    break
                current[u] += 1
            if current[u] == len(net[u]):
                path.pop()
                if edges:
                    parent, z = edges.pop()
                    current[parent] += 1
            else:
                z = current[u]
                edges.append((u, z))
                path.append(net[u][z][0])

    reachable = {src}
    queue = deque([src])
    while queue:
        u = queue.popleft()
        for v, cap, rev in net[u]:
            if cap > 0 and v not in reachable:
                reachable.add(v)
                queue.append(v)
    cut = sum(cap for u, v, cap, z in original
              if u in reachable and v not in reachable)
    assert cut == flow and 0 <= flow <= total
    # Verify capacity feasibility and flow conservation independently of
    # the augmenting-path accumulator, including the segment helpers.
    balance = [0] * len(net)
    for u, v, cap, z in original:
        sent = cap - net[u][z][1]
        assert 0 <= sent <= cap
        balance[u] -= sent
        balance[v] += sent
    assert balance[src] == -flow and balance[sink] == flow
    assert all(v == 0 for i, v in enumerate(balance) if i not in (src, sink))
    f = [1 + int(i in reachable) for i in range(m)]
    g = [int(m + j in reachable) for j in range(q)]
    value = 2 * total - flow
    assert value == sum(u * p for u, p in zip(supplies, f)) - sum(v * p for v, p in zip(demands, g))
    if certificate:
        return value, {'source_potentials': f, 'target_potentials': g,
                       'maxflow': flow, 'cut_capacity': cut,
                       'phases': phases, 'augmentations': augmentations,
                       'max_path_length': max_path, 'nodes': len(net),
                       'arcs': len(original), 'source_count': m,
                       'target_count': q, 'exception_count': incidence,
                       'helper_nodes': q - 1 if encoding == 'segment' else 0}
    return value
