# Sparse exact graph transport — research snapshot

21 October 2026. This is an AI-assisted research draft, not a claim of a confirmed breakthrough, established priority, independent human review, or an accepted submission.

The revised paper is **Sharp Hall localization and exact curvature in graph complements**. Its candidate contribution is structural: sharp Hall localization, a universal scalar filter, indexed construction, and a canonical matching witness in the cost-one/two regime. For complements of maximum pair codegree k, the implemented general design now attains O(k^5 log(k+1)n²) word operations using direct batched transport and ordinary Dinic. The optional eligible large-order specialization takes O(k³) per edge after shared preprocessing. The earlier k^7 implementation / unimplemented-flow-backend split is superseded.

## Start here

- `manuscript/main.tex`, `manuscript/main.pdf`: complete compiled 15-page paper draft. The app preview compiler could not launch; official portable Tectonic compiled it.
- `stage2-referee.md`, `stage2-priority.md`, `stage2-improvements.md`: current bounded Astra analysis. The three earlier reviews record the superseded closure design. AI review is not independent human peer review.
- `submission-readiness.md`: remaining research, authorship, licensing, and arXiv decisions.
- `../../site/ai-science/sparse-transport/index.html`: unpublished companion page, including a plain-language explanation.

## Reproduce the numerical checks

Python 3.10+; the CPU code uses only the standard library. Keep the sibling `../frontier-scan` dependency directory supplied in the archive. From this directory:

```text
python verify.py
python replay_gpu.py
python verify_batched.py
python verify_canonical.py
python verify_distance_three.py
python benchmark_batched.py
python benchmark_canonical.py
python benchmark.py --repeats 3
python benchmark_backends.py
python verify_one_level.py
```

`verify.py` exhausts connected labeled graphs through order six and checks every edge against an independently implemented full min-cost transport solver. It also tests seeded larger graphs and defective cubic-row families. The recorded total is 218,956 exact edge comparisons, including 218,494 exhaustive comparisons on 27,475 graphs. These counts overlap inherited research datasets and should not be added to them as new distinct coverage.

The current replay uses the final scalar filter and direct primal backend; 92,853 calls return through equality shortcuts. `verify_batched.py` checks 21,279 complete ternary cost matrices in its listed dimensions with seeded marginals, using both encodings against an independent min-cost reference. The optional `canonical_transport.py` agrees on 137,414 eligible edges in the same exhaustive graph suite, skips 81,080 ineligible edges, and separately checks twelve cubic families. These are overlapping protocols, not additive graph coverage. Three large-order distance-three controls reject the optional specialization and pass the general solver.

The separate `gpu_random_n9.json` contains 3,988 connected cases from 4,096 random nine-vertex marked-edge graphs (seed 2026102104). IMT's RTX 5090 evaluated all 3^8 anchored source-label assignments for each sampled graph. Float32 sums/products are exact integers at this scale; TF32 was disabled. `replay_gpu.py` forces the CPU residual solver on every stored result; all agree. Sampling the graphs is not exhaustive nine-vertex coverage. The GPU is a falsification oracle, not a demonstrated acceleration of the proposed algorithm. To regenerate on a CUDA/PyTorch host:

```text
python gpu_random_dual.py --count 4096 --n 9 --batch 32 --output gpu_random_n9.json
python replay_gpu.py
```

## What the timings say

`benchmark.json` compares dense and shared-segment encodings with the SAME Dinic backend on one synthetic defective family. The segment encoding is slower at every measured k=5,8,12,16,24,32. At k=32 it reduces arcs from 268,196 to 96,742, but median elapsed time rises from 1.353 to 1.914 seconds. Reduced network size is not a measured runtime improvement.

`benchmark_backends.json` separates a classical solver upgrade: at k=16, dense Dinic is about 27 times faster than our earlier dense Edmonds–Karp implementation. This is not a new flow algorithm or a comparison against the best available transport software.

`one_level_transport.py` preserves the classical cost-one/two identity D=2M−F. The main reducer now uses `batched_transport.py`, not closure. `batched-benchmark.json` compares the two generations and retains cases where the new backend loses. `canonical-benchmark.json` measures actual cubic graphs: at k=20,n=857, the per-edge median falls from 57.049ms to 0.153ms with the canonical witness, while both exclude the same 170.359ms preprocessing. This is a structured-family observation, not a whole-graph or application speedup. Older one-level records remain historical evidence.

Timings are host-dependent, single-process synthetic measurements with three trials. They include construction and validation, not whole-graph preprocessing. The JSON records preserve raw observations.

## Implementation versus theorem

The theoretical deterministic word-RAM design uses dense indexed adjacency, O(log n)-bit words, and unreduced rational output. The prototype uses Python sets/dictionaries, arbitrary-precision integers and reduced `Fraction` output. Hashing, sorting bounded lists, allocation and gcd costs are implementation details; do not claim its literal running time is the theorem's arithmetic-operation bound. The explicit O(n²)-edge output model is part of the theorem.

The network-size, short-path, canonical-witness and complexity arguments are handwritten. Six new arithmetic lemmas in `lean/SparseFilter.lean` compile with Lean 4.19.0 / Mathlib v4.19.0, using only standard axioms and no sorry/native_decide. Inherited supporting files check selected graph/Hall and threshold facts. This is not an end-to-end formal proof. `recheck_lean.ps1` uses the cached workspace toolchain for inherited files; external users need their own pinned installation.

## Publication status and provenance

The arXiv source package is a prepared draft. The stage-two website change is prepared for a draft PR against the now-existing AI Science section. See RELEASE.md and the current task's final status for any resulting PR; no arXiv submission or expert email is implied. Petri Mikael Autio is the proposed human author, subject to acceptance and responsibility for the final work. Significant AI use covered research direction, literature searches, proof proposals/drafting, code, tests, review and presentation. Human verification must not be asserted before it happens.

Three authorized Astra research reviewers and bounded follow-ups were used. No separate paid API job or compute purchase was initiated. The app does not expose a reliable dollar meter here; no exact expenditure is asserted. The user's USD500 ceiling is not an instruction to spend it all.

The optional categorical connection is literal: the transport potential transforms form a monotone adjunction, and implication reachability is a closure operator. These are established structures. Hegel/nLab context is interpretive background, not a source of the complexity theorem.
