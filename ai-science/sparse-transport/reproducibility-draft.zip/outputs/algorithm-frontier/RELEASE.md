# Stage-two publication handoff

Prepared 21 October 2026. The revised 15-page paper is **Sharp Hall localization and exact curvature in graph complements**. Its source and PDF are manuscript/main.tex and manuscript/main.pdf. The official portable Tectonic 0.17.0 build succeeds without overfull boxes or unresolved references; all pages were rendered for review. The original 12-page paper is retained separately as stage1-main.tex/PDF in the working folder.

The revised implemented general design has O(k^5 log(k+1)n²) word-operation complexity using ordinary Dinic and direct transport, with the new scalar filter. The optional cost-one/two canonical witness has O(k³) per eligible large-order edge. Both are candidate mathematical contributions; no optimality or established priority is claimed.

The final general replay passes 218,956 exact edge comparisons; the GPU-oracle replay passes 3,988 sampled connected cases. The generic backend passes 21,279 complete ternary matrices with seeded marginals. The optional specialization passes 137,414 eligible edges plus twelve large cubic families, and rejects three necessary-distance-three controls. These protocols overlap. Six new conditional arithmetic lemmas compile in Lean; the full theorem is not formalized.

The deeper prior-art audit found closer overlap with Chen–Liu–You's Claim5.2 and Section5 counting. The paper now credits it explicitly and foregrounds the sharp structural statements. Stage2-priority.md recommends rework and expert review before submission. That review is AI-assisted, not external human peer review.

The self-contained arxiv-source-draft.zip contains only main.tex with embedded bibliography. The reproducibility ZIP preserves source, observations and proof logs with a SHA-256 manifest. A fresh extracted-package check is recorded separately. No compiler binaries, credentials, SSH data or email drafts are included.

The compact website proposal is under pr-site/ai-science/sparse-transport/. It includes the article, paper/source downloads and explicit review status; the existing AI Science landing page receives one link. The live repository already contains the earlier AI Science experiment, created separately from this fork. This change is intended for a DRAFT PR, with no merge or arXiv submission in this pass. The task final response and PR metadata record whether the draft PR was created.

Human acceptance of authorship, mathematical verification, final priority assessment, the arXiv license, and account/endorsement eligibility remain release decisions. Significant AI assistance is disclosed; human verification is not asserted. No external expert email has been sent by this fork.
