"""Classical primal-dual min-cost flow with batched admissible maxflows.

Complete cost matrix: default one, sparse exceptions two or three.
No graph-metric or bounded-label hypothesis is required. At most three
distinct marginal cost stages suffice. Segment helpers share cost-one arcs.
"""
from collections import deque
import heapq

def transport_cost(supplies,demands,exceptions,anchor=None,certificate=False,encoding='segment'):
    m,q=len(supplies),len(demands)
    assert q and len(exceptions)==m and encoding in ('dense','segment')
    assert all(x>=0 for x in supplies+demands)
    M=sum(supplies);assert M==sum(demands)
    if not M:
        proof={'stages':[],'nodes':0,'arcs':0,'source_potentials':[0]*m,
               'target_potentials':[0]*q,'cost':0}
        return (0,proof) if certificate else 0
    src=m+q;sink=src+1;net=[[] for _ in range(sink+1)];original=[]
    infinity=M+1
    def add(u,v,cap,cost):
        z=len(net[u]);net[u].append([v,cap,len(net[v]),cost])
        net[v].append([u,0,z,-cost]);original.append((u,v,cap,cost,z))
    def node():net.append([]);return len(net)-1
    for i,u in enumerate(supplies):add(src,i,u,0)
    for j,v in enumerate(demands):add(m+j,sink,v,0)
    def tree(left,right):
        if right-left==1:return (m+left,left,right,None,None)
        mid=(left+right)//2;first=tree(left,mid);second=tree(mid,right)
        u=node();add(u,first[0],infinity,0);add(u,second[0],infinity,0)
        return (u,left,right,first,second)
    if encoding=='segment':root=tree(0,q)
    def interval(source,part,left,right):
        u,l,r,first,second=part
        if left<=l and r<=right:add(source,u,infinity,1);return
        mid=(l+r)//2
        if left<mid:interval(source,first,left,min(right,mid))
        if right>mid:interval(source,second,max(left,mid),right)
    for i,row in enumerate(exceptions):
        row=sorted(row);assert len({j for j,c in row})==len(row)
        assert all(0<=j<q and c in (2,3) for j,c in row)
        if anchor is not None:assert all(j!=anchor for j,c in row)
        if encoding=='dense':
            costs=dict(row)
            for j in range(q):add(i,m+j,infinity,costs.get(j,1))
        else:
            previous=0
            for j,c in row:
                if previous<j:interval(i,root,previous,j)
                add(i,m+j,infinity,c);previous=j+1
            if previous<q:interval(i,root,previous,q)
    potential=[0]*len(net);sent=cost=0;stages=[];total_phases=total_augmentations=0
    while sent<M:
        distance=[None]*len(net);distance[src]=0;heap=[(0,src)]
        while heap:
            du,u=heapq.heappop(heap)
            if distance[u]!=du:continue
            for v,cap,rev,edge_cost in net[u]:
                if not cap:continue
                reduced=edge_cost+potential[u]-potential[v]
                assert reduced>=0,(u,v,reduced)
                nd=du+reduced
                if distance[v] is None or nd<distance[v]:
                    distance[v]=nd;heapq.heappush(heap,(nd,v))
        assert distance[sink] is not None
        # Standard clipped potential update preserves nonnegative reduced
        # costs globally, including currently unreachable helper/zero rows.
        delta=distance[sink]
        for u,du in enumerate(distance):
            potential[u]+=delta if du is None else min(du,delta)
        marginal=potential[sink]-potential[src]
        assert 1<=marginal<=3 and (not stages or marginal>stages[-1]['marginal'])
        before=sent;phases=augmentations=max_path=0
        # Exhaust all zero reduced-cost s-t paths with ordinary Dinic.
        while True:
            level=[-1]*len(net);level[src]=0;queue=deque([src])
            while queue:
                u=queue.popleft()
                for v,cap,rev,c in net[u]:
                    if cap and c+potential[u]-potential[v]==0 and level[v]<0:
                        level[v]=level[u]+1;queue.append(v)
            if level[sink]<0:break
            phases+=1;max_path=max(max_path,level[sink]);current=[0]*len(net)
            path=[src];edges=[]
            while path:
                u=path[-1]
                if u==sink:
                    amount=min(net[v][z][1] for v,z in edges)
                    for v,z in edges:
                        edge=net[v][z];edge[1]-=amount;net[edge[0]][edge[2]][1]+=amount
                    sent+=amount;augmentations+=1;path=[src];edges=[];continue
                while current[u]<len(net[u]):
                    v,cap,rev,c=net[u][current[u]]
                    if cap and level[v]==level[u]+1 and c+potential[u]-potential[v]==0:break
                    current[u]+=1
                if current[u]==len(net[u]):
                    path.pop()
                    if edges:
                        parent,z=edges.pop();current[parent]+=1
                else:
                    z=current[u];edges.append((u,z));path.append(net[u][z][0])
        assert sent>before
        cost+=(sent-before)*marginal
        stages.append({'marginal':marginal,'mass':sent-before,'phases':phases,
                       'augmentations':augmentations,'max_path_length':max_path})
        total_phases+=phases;total_augmentations+=augmentations
    assert len(stages)<=3
    balances=[0]*len(net);actual_cost=0
    for u,v,cap,c,z in original:
        flow=cap-net[u][z][1];assert 0<=flow<=cap
        balances[u]-=flow;balances[v]+=flow;actual_cost+=c*flow
    assert actual_cost==cost and balances[src]==-M and balances[sink]==M
    assert all(x==0 for u,x in enumerate(balances) if u not in (src,sink))
    f=[-potential[i] for i in range(m)];g=[-potential[m+j] for j in range(q)]
    for i,row in enumerate(exceptions):
        costs=dict(row);assert all(f[i]-g[j]<=costs.get(j,1) for j in range(q))
    dual=sum(x*y for x,y in zip(supplies,f))-sum(x*y for x,y in zip(demands,g))
    assert dual==cost,(dual,cost)
    proof={'cost':cost,'stages':stages,'nodes':len(net),'arcs':len(original),
           'phases':total_phases,'augmentations':total_augmentations,
           'source_potentials':f,'target_potentials':g}
    return (cost,proof) if certificate else cost
