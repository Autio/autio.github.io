"""Replay every new CUDA oracle record against the independent graph reducer."""
import json,itertools,time
from pathlib import Path
from fractions import Fraction
from adaptive_curvature import preprocess,edge_curvature

root=Path(__file__).resolve().parent
data=json.loads((root/'gpu_random_n9.json').read_text());n=data['n']
pairs=[e for e in itertools.combinations(range(n),2) if e!=(0,1)]
start=time.perf_counter();forced=0
for row in data['records']:
    adj=[set(range(n))-{u} for u in range(n)]
    for j,(u,v) in enumerate(pairs):
        if row['mask']>>j&1:adj[u].remove(v);adj[v].remove(u)
    h=[set(range(n))-{u}-adj[u] for u in range(n)]
    k=max(1,max(len(h[u]&h[v]) for u,v in itertools.combinations(range(n),2)))
    expected=Fraction(row['numerator'],row['denominator'])
    got,meta=edge_curvature(adj,0,1,k,preprocess(adj,k),certificate=True,force_reduce=True)
    assert got==expected,(row,k,got,expected)
    forced+=1
result={'passed':True,'gpu_records':forced,'forced_residual_solves':forced,
  'seconds':time.perf_counter()-start,'device':data['device'],'gpu_seconds':data['seconds'],
  'seed':data['seed'],'scope':'all connected records from new n9 CUDA random graph batch; not exhaustive graphs'}
(root/'gpu_replay.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
