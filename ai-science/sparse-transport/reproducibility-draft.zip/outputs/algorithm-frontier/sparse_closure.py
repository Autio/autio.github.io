"""Exact transport closure with shared interval implication trees and Dinic.

Rows give only exceptions to cost one: (target_index, cost in {2,3}).
The input must be a residual graph-metric transport instance with a target
anchor at cost one from every source, and the bounded integer-dual property
proved in the manuscript. Arbitrary unrelated cost arrays are not claimed.
"""
from collections import deque


def transport_cost(supplies, demands, exceptions, anchor, certificate=False,encoding='segment'):
    m,q=len(supplies),len(demands)
    assert q>0 and len(exceptions)==m and 0<=anchor<q
    M=sum(supplies)
    assert M==sum(demands) and all(v>=0 for v in supplies+demands)
    infinity=4*M+1
    src=2*(m+q);sink=src+1
    net=[[] for _ in range(sink+1)];original=[]
    def node():
        net.append([]);return len(net)-1
    def add(u,v,capacity):
        net[u].append([v,capacity,len(net[v])])
        net[v].append([u,0,len(net[u])-1])
        original.append((u,v,capacity))
    for i,amount in enumerate(supplies):
        add(src,2*i,amount);add(src,2*i+1,amount)
        add(2*i+1,2*i,infinity)
    for j,amount in enumerate(demands):
        lo=2*m+2*j;hi=lo+1
        add(lo,sink,amount);add(hi,sink,amount);add(hi,lo,infinity)
    # Two shared binary interval trees. Leaves ARE target threshold nodes;
    # internal nodes have zero weight and imply both children.
    def tree(level,left,right):
        if right-left==1:return (2*m+2*left+level,left,right,None,None)
        mid=(left+right)//2
        first=tree(level,left,mid);second=tree(level,mid,right)
        u=node();add(u,first[0],infinity);add(u,second[0],infinity)
        return (u,left,right,first,second)
    assert encoding in ('segment','dense')
    if encoding=='segment':
        low_tree=tree(0,0,q);high_tree=tree(1,0,q)
    def imply_interval(source,root,left,right):
        u,l,r,first,second=root
        if left<=l and r<=right:add(source,u,infinity);return
        mid=(l+r)//2
        if left<mid:imply_interval(source,first,left,min(right,mid))
        if right>mid:imply_interval(source,second,max(left,mid),right)
    total_exceptions=cost_two=cost_three=0
    for i,row in enumerate(exceptions):
        row=sorted(row)
        assert len({j for j,c in row})==len(row)
        assert all(0<=j<q and j!=anchor and c in (2,3) for j,c in row)
        if encoding=='dense':
            row_cost=dict(row)
            for j in range(q):
                cost=row_cost.get(j,1)
                if cost==1:
                    add(2*i,2*m+2*j,infinity)
                    add(2*i+1,2*m+2*j+1,infinity)
                elif cost==2:
                    add(2*i+1,2*m+2*j,infinity);cost_two+=1
                else:cost_three+=1
            total_exceptions+=len(row)
            continue
        previous=0
        for j,c in row:
            if previous<j:
                imply_interval(2*i,low_tree,previous,j)
                imply_interval(2*i+1,high_tree,previous,j)
            if c==2:add(2*i+1,2*m+2*j,infinity);cost_two+=1
            else:cost_three+=1
            previous=j+1
        if previous<q:
            imply_interval(2*i,low_tree,previous,q)
            imply_interval(2*i+1,high_tree,previous,q)
        total_exceptions+=len(row)
    add(src,2*m+2*anchor+1,infinity)
    flow=phases=augmentations=max_path=0
    while True:
        level=[-1]*len(net);level[src]=0;queue=deque([src])
        while queue:
            u=queue.popleft()
            for v,cap,rev in net[u]:
                if cap>0 and level[v]<0:level[v]=level[u]+1;queue.append(v)
        if level[sink]<0:break
        phases+=1;max_path=max(max_path,level[sink])
        current=[0]*len(net)
        # Iterative blocking flow avoids Python recursion-depth assumptions.
        path=[src];edges=[]
        while path:
            u=path[-1]
            if u==sink:
                amount=min(net[v][z][1] for v,z in edges)
                for v,z in edges:
                    edge=net[v][z];edge[1]-=amount;net[edge[0]][edge[2]][1]+=amount
                flow+=amount;augmentations+=1;path=[src];edges=[]
                continue
            while current[u]<len(net[u]):
                v,cap,rev=net[u][current[u]]
                if cap>0 and level[v]==level[u]+1:break
                current[u]+=1
            if current[u]==len(net[u]):
                path.pop()
                if edges:
                    parent,z=edges.pop();current[parent]+=1
            else:
                z=current[u];edges.append((u,z));path.append(net[u][z][0])
    reachable={src};queue=deque([src])
    while queue:
        u=queue.popleft()
        for v,cap,rev in net[u]:
            if cap>0 and v not in reachable:reachable.add(v);queue.append(v)
    cut=sum(cap for u,v,cap in original if u in reachable and v not in reachable)
    assert cut==flow
    f=[-1+int(2*i in reachable)+int(2*i+1 in reachable) for i in range(m)]
    g=[-2+int(2*m+2*j in reachable)+int(2*m+2*j+1 in reachable) for j in range(q)]
    assert g[anchor]==0
    for i,row in enumerate(exceptions):
        costs=dict(row)
        assert all(f[i]-g[j]<=costs.get(j,1) for j in range(q))
    value=3*M-flow
    assert value==sum(a*b for a,b in zip(supplies,f))-sum(a*b for a,b in zip(demands,g))
    assert M<=value<=3*M
    helper_nodes=2*(q-1) if encoding=='segment' else 0
    assert len(net)==2*(m+q)+2+helper_nodes
    assert max_path<=3*(2*q+helper_nodes)+3
    if certificate:
        dense_arcs=3*m+3*q+2*(m*q-total_exceptions)+cost_two+1
        return value,{'source_potentials':f,'target_potentials':g,'maxflow':flow,
          'cut_capacity':cut,'phases':phases,'augmentations':augmentations,
          'max_path_length':max_path,'nodes':len(net),'arcs':len(original),
          'dense_arcs':dense_arcs,'target_count':q,'source_count':m,
          'exception_count':total_exceptions,'helper_nodes':helper_nodes}
    return value
