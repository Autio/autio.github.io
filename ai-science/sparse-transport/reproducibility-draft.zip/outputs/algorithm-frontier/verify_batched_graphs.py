"""Replay the full graph protocol using the direct batched transport backend.

Writes stage2/verification.json, preserving the original closure evidence.
"""
from pathlib import Path
import adaptive_curvature,verify
from batched_transport import transport_cost
root=Path(__file__).resolve().parent
(root/'stage2').mkdir(exist_ok=True)
adaptive_curvature.transport_cost=transport_cost
verify.__file__=str(root/'stage2/verify_batched_graphs.py')
if __name__=='__main__':verify.run()
