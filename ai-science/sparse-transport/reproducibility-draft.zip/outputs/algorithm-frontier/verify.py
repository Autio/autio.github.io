"""Exact exhaustive and boundary verification of adaptive sparse transport."""
from adaptive_curvature import edge_curvature,preprocess
from curvature_probe import complement,connected,transport
from itertools import combinations
from fractions import Fraction
from pathlib import Path
import json,random,time


def cubic_family(k,padding=True):
    S=[2,3];T=list(range(4,k+2));Z=list(range(k+2,2*k+1))
    triples=list(combinations(T,3));start=2*k+1
    removed=[(0,s) for s in S+T]+[(1,z) for z in Z]+[(z,s) for z in Z for s in S]
    removed += [(start+i,s) for i,U in enumerate(triples) for s in U]
    n=start+len(triples)
    if padding:n=max(n,k*k+k+2)
    return complement(n,removed),len(triples)


def run():
    start=time.time();graphs=checks=forced=shortcuts=large_checks=0;max_sources=max_arcs=0
    def check(adj,pairs,force=False,parameter=None):
        nonlocal graphs,checks,forced,shortcuts,large_checks,max_sources,max_arcs
        n=len(adj);h=[set(range(n))-{u}-adj[u] for u in range(n)]
        k=parameter or max(1,max((len(h[u]&h[v]) for u,v in combinations(range(n),2)),default=0))
        data=preprocess(adj,k);graphs+=1
        for x,y in pairs:
            if y not in adj[x]:continue
            actual=transport(adj,x,y)
            value,meta=edge_curvature(adj,x,y,k,data,force_reduce=force)
            assert actual==value,(n,k,x,y,actual,value,meta)
            checks+=1;forced+=force;shortcuts+=meta['shortcut'];large_checks+=meta['large_order']
            max_sources=max(max_sources,meta.get('sources',0))
            max_arcs=max(max_arcs,meta.get('network',{}).get('arcs',0))
    for n in range(2,7):
        pairs=list(combinations(range(n),2))
        for mask in range(1<<len(pairs)):
            adj=complement(n,[e for i,e in enumerate(pairs) if mask>>i&1])
            if connected(adj):check(adj,pairs,force=(mask%37==0))
        print(json.dumps({'order':n,'graphs':graphs,'edges':checks,'seconds':time.time()-start}),flush=True)
    exhaustive_graphs=graphs;exhaustive_edges=checks
    rng=random.Random(2026102103)
    for n in (8,12,20,40,80):
        pairs=list(combinations(range(n),2))
        for trial in range(20):
            p=rng.choice([.02,.05,.12,.3,.65])
            adj=complement(n,[e for e in pairs if rng.random()<p])
            if connected(adj):check(adj,rng.sample(pairs,min(6,len(pairs))),force=True)
    families=[]
    for k in range(5,16):
        adj,triples=cubic_family(k);check(adj,[(0,1)],parameter=k)
        data=preprocess(adj,k);value,meta=edge_curvature(adj,0,1,k,data,certificate=True)
        a,b=len(adj[0]),len(adj[1]);c=len(adj[0]&adj[1])
        assert value==Fraction(c,b)-Fraction(k-1,a*b)
        assert meta['large_order'] and meta['sources']>=triples
        families.append({'k':k,'n':len(adj),'triple_types':triples,'curvature':str(value),
                         'sources':meta['sources'],'network':meta['network']})
    result={'passed':True,'exhaustive_connected_graphs':exhaustive_graphs,
      'exhaustive_edges':exhaustive_edges,'total_graphs':graphs,'total_edges':checks,
      'forced_residual_solves':forced,'large_order_checks':large_checks,'shortcuts':shortcuts,
      'largest_sources':max_sources,'largest_arcs':max_arcs,'cubic_families':families,
      'random_seed':2026102103,'seconds':time.time()-start}
    Path(__file__).with_name('verification.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='cubic_families'},indent=2))

if __name__=='__main__':run()
