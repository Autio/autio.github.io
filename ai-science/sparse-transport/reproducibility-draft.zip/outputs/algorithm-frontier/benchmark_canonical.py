"""Actual cubic graph family: optional canonical witness vs general reducer.

Shared preprocessing is measured separately. Neither is a best-software
baseline. Functions include their normal internal validation and construction.
"""
from pathlib import Path
from verify import cubic_family
from adaptive_curvature import edge_curvature as general,preprocess
from canonical_transport import edge_curvature as canonical
import time,gc,statistics,json,platform,hashlib
root=Path(__file__).resolve().parent;rows=[]
for k in (8,12,16,20):
    adj,triples=cubic_family(k);start=time.perf_counter();data=preprocess(adj,k)
    row={'k':k,'n':len(adj),'distinct_triple_rows':triples,'preprocess_seconds':time.perf_counter()-start}
    answer=None
    for name,solver in (('general_batched',general),('canonical',canonical)):
        times=[]
        for _ in range(3):
            gc.collect();start=time.perf_counter();value,proof=solver(adj,0,1,k,data)
            times.append(time.perf_counter()-start)
            if answer is None:answer=value
            assert value==answer
        row[name]={'median_seconds':statistics.median(times),'seconds':times}
    row['speed_ratio']=row['general_batched']['median_seconds']/row['canonical']['median_seconds']
    row['value']=str(answer);rows.append(row);print(json.dumps(row),flush=True)
result={'passed':True,'repeats':3,'python':platform.python_version(),'platform':platform.platform(),
    'scope':'actual cubic graph family; shared preprocessing separate; uncontrolled host load; no application or best-software baseline',
    'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('canonical_transport.py','adaptive_curvature.py','batched_transport.py')},'rows':rows}
(root/'canonical-benchmark.json').write_text(json.dumps(result,indent=2))
