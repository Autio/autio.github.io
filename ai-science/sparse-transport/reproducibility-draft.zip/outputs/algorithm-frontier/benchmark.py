"""Matched dense/segment encodings using the identical Dinic solver.

Timing includes construction, flow and certificates. This isolates encoding
from solver choice. The structured family is synthetic, not application data.
"""
from sparse_closure import transport_cost
from itertools import combinations
from pathlib import Path
import json,time,platform,statistics,argparse,gc

def instance(k):
    triples=list(combinations(range(3,k+1),3));count=len(triples)
    n=max(2*k+1+count,k*k+k+2);padding=n-(2*k+1+count)
    a=k+count+padding;b=a+1
    supplies=[b+padding,(k-1)*b]+[1]*count
    rows=[(),((1,2),(2,2))]+[tuple((j,2) for j in U) for U in triples]
    return supplies,[a]*(k+1),rows,a*(k+1)+k-1

def run(ks,repeats):
    rows=[]
    for k in ks:
        supplies,demands,exceptions,expected=instance(k);entry={'k':k,'sources':len(supplies),'targets':len(demands)}
        for encoding in ('dense','segment'):
            elapsed=[];proof=None
            for trial in range(repeats):
                gc.collect();start=time.perf_counter()
                value,proof=transport_cost(supplies,demands,exceptions,0,True,encoding=encoding)
                elapsed.append(time.perf_counter()-start);assert value==expected
            entry[encoding]={'median_seconds':statistics.median(elapsed),'seconds':elapsed,
                'nodes':proof['nodes'],'arcs':proof['arcs'],'phases':proof['phases'],
                'augmentations':proof['augmentations'],'max_path_length':proof['max_path_length']}
        entry['time_ratio_dense_over_segment']=entry['dense']['median_seconds']/entry['segment']['median_seconds']
        entry['arc_ratio_dense_over_segment']=entry['dense']['arcs']/entry['segment']['arcs']
        rows.append(entry);print(json.dumps(entry),flush=True)
    result={'passed':True,'python':platform.python_version(),'platform':platform.platform(),
       'processor':platform.processor(),'repeats':repeats,'scope':'synthetic defective triple-mask family; identical Dinic solver',
       'rows':rows}
    Path(__file__).with_name('benchmark.json').write_text(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-k',type=int,default=32)
    p.add_argument('--repeats',type=int,default=3);args=p.parse_args()
    run([k for k in (5,8,12,16,24,32) if k<=args.max_k],args.repeats)
