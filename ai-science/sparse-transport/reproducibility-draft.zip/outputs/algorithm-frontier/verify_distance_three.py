"""Large-order controls: cost three remains necessary in the optimal plan."""
from pathlib import Path
from fractions import Fraction
from adaptive_curvature import preprocess,edge_curvature
from canonical_transport import edge_curvature as canonical
from curvature_probe import complement,transport
import json
rows=[]
for c in (3,10,50):
    C=list(range(5,5+c));S=[3,4]
    removed=[(2,v) for v in [1]+S+C]+[(0,v) for v in S]
    adj=complement(5+c,removed);data=preprocess(adj,2)
    assert canonical(adj,0,1,2,data) is None
    expected=Fraction(c,c+3)-Fraction(2,(c+2)*(c+3))
    assert transport(adj,0,1)==expected
    assert edge_curvature(adj,0,1,2,data)[0]==expected
    rows.append({'n':len(adj),'common_neighbors':c,'value':str(expected),'canonical_rejected':True})
result={'passed':True,'scope':'three large-order graphs where optimal transport necessarily uses costthree','rows':rows}
Path(__file__).with_name('distance-three-verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
