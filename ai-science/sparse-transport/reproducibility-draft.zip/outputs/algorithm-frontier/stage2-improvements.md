# Stage 2: structural simplification and referee assessment

Prepared 21 October 2026. This bounded pass reviewed the existing manuscript, checked the new scalar filter, developed a canonical matching reduction, and tested its exact formula and a nested-witness identity in memory. It did not publish, submit, contact anyone, change the website, or start further agents. The revised complete LaTeX source is `manuscript-stage2.tex`; the previous `manuscript/main.tex` was preserved.

## Assessment in brief

The most defensible paper is a focused combinatorics paper with an exact-computation corollary. Its main objects should be the sharp finite-order cutoff, persistent Hall obstructions, and the universal scalar filter. The generic flow machinery is classical. The new filter removes the former small-order bottleneck, so the implemented dense-small/segment-large primal algorithm has the stated candidate bound O(k^5 log(k+1) n²) using ordinary Dinic throughout, without an Orlin backend or a graph-specific bounded dual.

There is also a more semantic improvement: when every residual cost is one or two, a canonical matching witness determines the exact deficit at large order. It requires O(k³) work per candidate after indexed preprocessing and never materializes the cubic collection of common-source rows. This applies to the purportedly hard cubic-row family itself. Consequently that family is a sharpness example for identical-row aggregation only, not an algorithmic lower bound.

## Notation and facts retained from the manuscript

Orient xy so a=deg_G(x)≤b=deg_G(y), d=b−a. Set A=N_G(x)\N_G(y), B=N_G(y)\N_G(x), C=N_G(x)∩N_G(y), R=V\(N_G(x)∪N_G(y)), with sizes α,β,c,r. Then β=α+d, a=α+c, n=a+β+r, and r≤k. Scale residual transport by ab: an exclusive source in A supplies b, a common source in C supplies d, each target in B demands a, and M=aβ is the total mass. Zero-supply common sources may be ignored.

For S⊆B, write p(S),q(S) for the numbers of exclusive and common sources with no cost-one edge to S. Define

    L(S)=|S|+p(S)−β=|S|−|N_A(S)|−d,
    F(S)=a L(S)+d(p(S)+q(S)).

F(S) is scaled weighted Hall deficiency. Triangle equality holds iff every F(S)≤0. A positive witness excludes x, has 2≤|S|≤k, p+q≤k−1, p+1≤α, and, if p≥2, |S|≤k−1. Above n=k²+k+1 no positive witness has L<0. These facts concern equality in zero-idleness curvature, not positivity of Lin–Lu–Yau curvature.

## 1. The universal scalar filter is valid and sufficient for a small side

For every positive witness,

    |S|+p ≤ b_k := max(k+1,2k−2).

Indeed p≤1 gives k+1; p≥2 gives (k−1)+(k−1). Therefore

    0 < F(S) ≤ U := (b_k−β)a+d(k−1).

So U≤0 is a valid equality shortcut at every order. On any surviving edge, if β<2b_k then the target side is O(k). Otherwise U>0 implies

    (β−b_k)a < d(k−1) ≤ β(k−1),

and β−b_k≥β/2 gives a<2(k−1). Thus min(a,β)=O(k) without a large-order hypothesis.

For n≤k²+k+1, a+β≤n=O(k²), so aβ=O(k³). The direct residual transport has at most a source rows, O(k³) explicit source-target arcs, and a side of size O(k). A simple residual path has O(k) length: delete both terminals and the smaller bipartition side, leaving isolated vertices. Ordinary current-arc Dinic therefore costs O(k²E)=O(k^5) for one admissible maximum flow.

For large order the previous indexed compression still gives β=O(k), m=O(k³), and missing incidence I=O(k³). A shared segment tree gives E=O(k³ log(k+1)); deleting the targets, helpers, and terminals again leaves isolated sources, hence O(k)-length simple paths and O(k^5 log(k+1)) admissible max flow.

Classical primal-dual batching needs at most three such maximum flows for complete costs in {1,2,3}. Before completion there is an unsaturated source supply and target demand; their complete forward transfer has cost at most three. Internal arcs have capacity M+1, so it is still residual, even in the segment representation. Exhausting zero-reduced-cost augmentations makes the next integral marginal cost strictly increase; the marginals therefore belong to {1,2,3}. Clipping each potential update to the sink distance preserves feasible reduced costs on unreachable vertices too. The manuscript now gives this proof directly.

This is a valid simplification of the actual runtime argument. It is not a new general min-cost-flow method. The structural filter is what makes the established method fast in the parameter.

## 2. Canonical matching removes common rows in the cost-one/two regime

**Proposition.** Assume a>d(k−1). Let ν be a maximum-cardinality matching between A and B using cost-one pairs, and set ℓ=α−ν. Among the sets maximizing L(S), let S₀ be the inclusion-minimal one. Then, with p₀=p(S₀), q₀=q(S₀),

    max_{S⊆B} F(S) = aℓ+d(p₀+q₀).

The same proof works with a≥d(k−1), allowing ties, but the strict version suffices for large order and is used in the revised manuscript.

**Proof.** Matching deficiency gives max_S(|S|−|N_A(S)|)=β−ν, hence max L=α−ν=ℓ≥0. Neighborhood cardinality is submodular, so L is supermodular. Its maximizers are closed under intersection and union. Their intersection S₀ is the unique smallest maximizer. Since p+q is antitone, S₀ has the largest intercept d(p+q) among all slope maximizers. Any positive-deficiency set with a smaller integer slope has

    F(S) ≤ a(ℓ−1)+d(k−1) < aℓ ≤ F(S₀).

Nonpositive deficiencies are harmless because F(S₀)≥0. This proves the formula.

**How to find S₀.** In the matching network, use unit arcs source→B and A→sink, with nonbinding B→A arcs for cost-one pairs. The cut determined by S⊆B has capacity β−|S|+|N_A(S)|. After a maximum matching, residual reachability from the source gives the smallest source side of a minimum cut and therefore S₀. Equivalently use alternating reachability from unmatched vertices of B. This is a standard matching/mincut fact, not a new matching algorithm.

**Why the arithmetic hypothesis is automatic at large order.** If d≥k then any positive witness has L≤|S|−d−1≤k−d−1<0, impossible above the cutoff. Such an edge attains equality. Otherwise d≤k−1. For remaining candidates β≤b_k, hence

    a=n−β−r ≥ k²+2−b_k > (k−1)² ≥ d(k−1).

**How to avoid scanning C.** Construct A and B from the small endpoint complement neighborhoods. Their sizes are O(k), so a basic augmenting-path matching costs O(k³). For d=0, δ=aℓ and no common-source query is required. If S₀ contains x, then L(S₀)=|S₀|−β≤0, and maximality forces S₀=B; δ=0. If d>0 and S₀≠B, then S₀ excludes x and has at least two vertices, because empty and singleton sets have L<0 while ℓ≥0. Choose s,t∈S₀. Every excluded common source lies in the precomputed list N_H(s)∩N_H(t), containing at most k vertices. Filter that list for C-membership and for adjacency in H to all of S₀. This determines q₀ in O(k²), without materializing any common-source masks. The exclusive count p₀ is already available from the matching graph.

Every common source has residual costs only one or two. Detecting whether any exclusive exception has cost three costs O(k²) using the indexed common-neighbor counts. When no such exception exists, max cost-one flow leaves exactly δ=max F units to send at cost two, so D=M+δ and κ₀=c/b−δ/(ab). Thus the entire specialization takes O(k³) per surviving large-order edge. It bypasses the Θ(k³) irrelevant common rows in the triple-mask construction.

The new manuscript contains this proposition and algorithm. The parent is implementing an optional backend separately; the mathematical statement does not depend on uncompleted implementation claims.

## 3. Cost three is a genuine obstruction, with an exact nested-witness identity

The canonical Hall formula above computes maximum Hall deficiency even if cost three exists, but it then need not compute the transport cost. This limitation persists at arbitrarily large order.

Take S={s₁,s₂}, any set C of size c, and complement edges u–({y}∪S∪C) and x–S, with no others. The maximum complement pair codegree is two. At xy, A={y,u}, B={x,s₁,s₂}, a=c+2, b=c+3, d=1. In G, u is pendant at x. Its scaled supply b exceeds the capacity a at x by one, forcing one unit of distance-three transport. All other mass can use cost-one arcs. Consequently max F=1 but D−M=2. Any claim that large-order Hall deficiency alone is the exact curvature gap is false.

A precise second-tier description is nevertheless possible. Let Q=B\{x}, let E(S) be the residual sources with no cost-one edge to S, and let w be scaled supply. For nonempty T⊆S⊆Q define

    P(S,T)=sum of w(u) over u∈E(S) having a cost-two edge to some t∈T.

Then the exact excess over baseline cost M is

    D−M = max( max_{S⊆Q} F(S),
                max_{∅≠T⊆S⊆Q} [F(S)+F(T)−P(S,T)] ).

**Proof.** Use an integral optimal graph potential anchored at x, and the standard clipping argument from the manuscript to take target values in {−2,−1,0} and source values in {−1,0,1}. Write T for targets of value −2 and S for targets of value at most −1. For nonempty T, the best source potential is

    f(u)=−1 + 1[u∈E(T)]
                + 1[u∈E(S) and every cost from u to T equals 3].

The third indicator is precisely E(S) with the sources counted by P removed. Substituting into the dual objective and subtracting M gives F(S)+F(T)−P(S,T). With T empty, it gives F(S). Every feasible nested pair specifies such a dual, and the bounded-label optimum is included, proving equality.

If δ=max F, any nested pair improving strictly on δ must satisfy both F(S)>0 and F(T)>0, since P≥0 and each separate deficiency is at most δ. Hence at large order both sets are persistent Hall witnesses. In the pendant example, S=T={s₁,s₂}, both deficiencies are one and P=0, giving the required excess two.

This identity explains exactly why the distance-three correction is needed and may support further semantic compression. It does not itself give a polynomial-in-k improvement: enumerating all nested pairs is exponential. Its derivation uses established transport duality, and no generic duality novelty is claimed. It is kept in this research note rather than added as another main theorem to the already complete manuscript.

## 4. Independent checks made in this pass

An in-memory Python check enumerated every connected labeled graph of orders two through five: 771 graphs and 4,294 oriented-by-degree edge instances. It compared the nested-witness identity against the independent full transport solver for all 4,294 edges, with no discrepancy. On the 4,094 edges satisfying a≥d(k−1), it independently enumerated all target subsets, constructed S₀ by intersection of all L-maximizers, and checked the canonical formula against max F, again with no discrepancy. These counts are not additional distinct cases beyond the larger parent suite; they test new identities on an overlapping exhaustive subset. No new script or result file was written for this in-memory check.

The parent reports final primal/scalar-filter replay success on 218,956 comparisons, independent matrix checks on 21,279 listed ternary matrices, and replay of all 3,988 retained GPU-oracle cases. The revised source preserves their separate protocols instead of adding overlapping replays into a graph count.

## 5. Literature credit and the unbalanced-flow option

[Chen, Liu, and You, arXiv:2605.03470](https://arxiv.org/html/2605.03470v1) is a close predecessor. Claim 5.2 already supplies the missing-neighbor mask bound, and Section 5 uses the endpoint-reservation counting principle. Those facts must be explicitly credited. Their theorem concerns positive Lin–Lu–Yau curvature; the sharp transient zero-idleness equality defect is a different phenomenon. For k≥8 the cutoff-sharp family has n=k²+k+1≥max(k²+1,8k+8), so Chen's Theorem 1.2 (t=k+1) gives positive Lin–Lu–Yau curvature on every edge while the marked transient equality defect remains. This is a useful concrete distinction, not a claim of priority.

[Hehl, arXiv:2407.08854v3](https://arxiv.org/abs/2407.08854v3) already gives optimal-assignment formulas for regular graph curvature, including zero idleness. Equal-degree cancellation and matching formulations should not be advertised as newly discovered. The canonical result above uses an unbalanced slope/intercept dominance condition, which requires its own literature check before a novelty claim.

The [Princeton author-institution record for Ahuja–Orlin–Stein–Tarjan, SIAM J. Computing 23(5), 906–933 (1994)](https://collaborate.princeton.edu/en/publications/improved-algorithms-for-bipartite-network-flow/) explicitly states an O(n_small E+n_small³) bipartite maximum-flow bound. The dense transport network, including its terminals, is bipartite: place the super-source with targets and the super-sink with source rows. Reverse arcs and admissible subgraphs preserve this property. Substituting the current dimensions suggests O(k^5) large-order and O(k^4) small-order admissible flow, potentially eliminating the logarithm with an all-dense theoretical backend. This pass verified the abstract and bibliographic record, not the full paper's theorem and implementation assumptions. The revised source therefore mentions the possible improvement only as unaudited further work, and retains the fully proved ordinary-Dinic bound as its headline.

## 6. Referee-style judgment and revision strategy

**A focused preprint is plausible if the sharp structural statement survives a serious priority audit and independent human checking.** A theorem with an exact quadratic cutoff, explicit extremizers, a persistent localization bound, and a clear different target from the closest prior work is a coherent combinatorics result. The scalar filter and canonical one/two-cost witness strengthen that story. The generic network construction alone would be a weak basis for an algorithms novelty claim; it mainly combines standard compression and standard optimization.

The current evidence does not support a broad claim of a breakthrough, an optimal k-exponent, or a practical sparse-network advantage. The original matched closure table is negative. The current primal speed differences are changes between classical backends on synthetic inputs with uncontrolled host load; the complete record contains losses as well as gains. These limitations should remain visible.

Recommended organization, now reflected in the revised source:

1. State the transient-versus-persistent Hall question and sharp cutoff first.
2. Prove the universal scalar filter and small-side consequence directly from the witness restrictions.
3. Credit Chen's local mask and endpoint-counting facts before using indexed construction.
4. Present the direct primal all-edge bound as a computational corollary, with its short complete proof.
5. Include the canonical matching specialization as the semantic reduction that bypasses the cubic-row family.
6. Keep cubic row sharpness narrowly stated, and retain the cost-three counterexample.
7. Separate verification protocols, historic negative benchmarks, new exploratory benchmarks, and remaining review work.

The matching maximizer lattice is a real order-theoretic structure; transport feasibility also has a genuine min-plus adjunction. Neither needs a philosophical analogy. Hegel adds no theorem or runtime justification and should not be used as evidence of mathematical novelty.

Authorship and responsibility remain subject to the named human's acceptance. The source explicitly discloses substantial AI contributions and does not assert independent human verification. Partial Lean checks are valuable but are not an end-to-end formalization of the full algorithm or manuscript.
