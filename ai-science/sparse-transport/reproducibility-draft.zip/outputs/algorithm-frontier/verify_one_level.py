"""Reproduce the bounded one-level comparisons and synthetic benchmark.

Run from any directory:
    python outputs/algorithm-frontier/verify_one_level.py
    python outputs/algorithm-frontier/verify_one_level.py --repeats 3 --output one-level-benchmark-replay.json

The default output is beside this script and preserves the original
one-level-benchmark.json. Timings cover solver construction, flow, and its
internal certificate checks; explicit cross-solver dual checks are outside
the timed interval. This saves the exact original harness as a script,
with platform metadata and configurable output/repetition count added.
"""
import argparse
import gc
import json
from pathlib import Path
import platform
import random
import statistics
import sys
import time

from benchmark import instance
from sparse_closure import transport_cost as closure
from one_level_transport import transport_cost as one
import adaptive_curvature as adaptive


def run(repeats=3):
    assert repeats >= 1
    results = []
    for k in (5, 8, 12, 16, 24, 32):
        supplies, demands, exceptions, expected = instance(k)
        row = {'k': k}
        for name, solver in [('closure', closure), ('one_level', one)]:
            for encoding in ('dense', 'segment'):
                times = []
                for _ in range(repeats):
                    gc.collect()
                    start = time.perf_counter()
                    value, proof = solver(supplies, demands, exceptions, 0,
                                          True, encoding=encoding)
                    times.append(time.perf_counter() - start)
                    assert value == expected
                    assert all(
                        proof['source_potentials'][i] - proof['target_potentials'][j]
                        <= dict(exceptions[i]).get(j, 1)
                        for i in range(len(supplies))
                        for j in range(len(demands)))
                row[name + '_' + encoding] = {
                    'median_seconds': statistics.median(times),
                    'arcs': proof['arcs'], 'nodes': proof['nodes']}
        results.append(row)
        print(json.dumps(row), flush=True)

    rng = random.Random(20261021)
    counts = {'checked': 0, 'cost_three_skipped': 0, 'graphs': 0}
    old = adaptive.transport_cost

    def compare(supplies, demands, exceptions, anchor, certificate=False, **kw):
        answer, proof = closure(supplies, demands, exceptions, anchor, True)
        if any(c == 3 for row in exceptions for j, c in row):
            counts['cost_three_skipped'] += 1
        else:
            for encoding in ('dense', 'segment'):
                value, checked = one(supplies, demands, exceptions, anchor,
                                     True, encoding)
                assert value == answer
                assert all(
                    checked['source_potentials'][i] - checked['target_potentials'][j]
                    <= dict(exceptions[i]).get(j, 1)
                    for i in range(len(supplies))
                    for j in range(len(demands)))
            counts['checked'] += 1
        return (answer, proof) if certificate else answer

    adaptive.transport_cost = compare
    try:
        for trial in range(60):
            n = rng.randrange(5, 31)
            prob = rng.choice((0.1, 0.25, 0.5, 0.75))
            h = [set() for _ in range(n)]
            for u in range(n):
                for v in range(u + 1, n):
                    if rng.random() < prob:
                        h[u].add(v)
                        h[v].add(u)
            adj = [set(range(n)) - {u} - h[u] for u in range(n)]
            reached, todo = {0}, [0]
            while todo:
                for v in adj[todo.pop()] - reached:
                    reached.add(v)
                    todo.append(v)
            if len(reached) < n:
                continue
            k = max(1, max(len(h[u] & h[v])
                           for u in range(n) for v in range(u + 1, n)))
            data = adaptive.preprocess(adj, k)
            edges = [(u, v) for u in range(n) for v in adj[u] if u < v]
            rng.shuffle(edges)
            for u, v in edges[:12]:
                adaptive.edge_curvature(adj, u, v, k, data, force_reduce=True)
            counts['graphs'] += 1
    finally:
        adaptive.transport_cost = old

    # Explicitly verify exclusion of a cost-three row.
    try:
        one([1], [1], [((0, 3),)], None)
        raise RuntimeError('cost-three input accepted')
    except AssertionError:
        pass

    # Zero supply, no-anchor matrix, and singleton cases.
    for supplies, demands, rows in [
            ([0], [0], [()]),
            ([2], [2], [()]),
            ([2], [2], [((0, 2),)]),
            ([1, 1], [1, 1], [((0, 2), (1, 2)), ()])]:
        for encoding in ('dense', 'segment'):
            value, proof = one(supplies, demands, rows, None, True, encoding)
            assert proof['maxflow'] == proof['cut_capacity']
    print(json.dumps(counts), flush=True)
    return {
        'passed': True,
        'python': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'platform': platform.platform(),
        'processor': platform.processor(),
        'executable': sys.executable,
        'repeats': repeats,
        'rows': results,
        'actual_graph_comparisons': counts,
        'seed': 20261021,
        'scope': 'synthetic defective triple-mask family and seeded actual graph residuals',
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--output', default='one-level-benchmark-replay.json')
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error('--repeats must be positive')
    if not __debug__:
        parser.error('run without -O so verification assertions remain enabled')
    output = Path(args.output)
    if not output.is_absolute():
        output = Path(__file__).resolve().parent / output
    output.write_text(json.dumps(run(args.repeats), indent=2), encoding='utf-8')
    print(str(output), flush=True)
