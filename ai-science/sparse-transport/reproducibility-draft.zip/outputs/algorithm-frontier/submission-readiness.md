# Stage-two submission readiness

21 October 2026. The revised draft is **Sharp Hall localization and exact curvature in graph complements**. [Paper PDF](manuscript/main.pdf), [source archive](arxiv-source-draft.zip), [reproducibility archive](reproducibility-draft.zip). The 15-page PDF compiles and has been rendered for review. No arXiv submission or independent human review is recorded.

The paper now leads with sharp Hall localization and the scalar filter. Direct batched transport gives the implemented O(k^5 log(k+1)n²) all-edge design, without the earlier unimplemented Orlin dependency. The optional canonical Hall witness uses O(k³) per eligible large-order edge when costs are at most two. The manuscript supplies the proofs; stage2-referee.md and stage2-improvements.md record internal review.

The broader [priority audit](stage2-priority.md) recommends rework and specialist review before submission. It found closer proof-level overlap with Chen–Liu–You than the initial draft credited. The revision credits Claim5.2, reserved-endpoint counting, and established matching/flow methods. No inspected theorem was shown to duplicate the complete result, but that does not establish novelty. Stronger classical unbalanced-flow substitutions deserve further comparison; no best-known exponent is claimed.

The final general replay passes 218,956 exact comparisons, including every edge of all 27,475 connected labeled graphs through order six. All 3,988 retained connected GPU-oracle samples agree with the new backend. It also passes 21,279 complete ternary matrices with seeded marginals. The canonical specialization passes 137,414 eligible edges in the same exhaustive suite and twelve large cubic families; ineligible cases are skipped. Six new conditional arithmetic lemmas compile in Lean 4.19.0. These checks overlap, and none is a full formal proof.

The local website proposal is pr-site/ai-science/sparse-transport/. The existing live AI Science landing page receives one link. A draft PR can expose the artifact set for review; it is not a merge, endorsement or arXiv submission. See RELEASE.md and the task final status for the resulting PR, if created. First-stage reviews and the original website-release layout are historical.

Before arXiv submission:

1. The named human author accepts or revises authorship and takes responsibility for the complete article. Significant AI assistance is disclosed; independent human verification must not be claimed until performed.
2. Have the structural proofs, canonical-witness theorem and priority comparison reviewed. This is a confidence recommendation, not an arXiv requirement that every preprint already be peer reviewed.
3. Choose a rights-compatible paper distribution license. None is selected here. The [official license guidance](https://info.arxiv.org/help/license/index.html) explains the permanence of a posted version's license.
4. Confirm the account and endorsement status, both unknown here. Follow the [official endorsement process](https://info.arxiv.org/help/endorsement.html); endorsement is not peer review.
5. Select the category after the paper is stable: math.CO or cs.DS may fit its structural/algorithmic emphasis. See the [official taxonomy](https://arxiv.org/category_taxonomy). This is not an acceptance prediction.
6. Upload the self-contained main.tex archive and inspect arXiv's own generated PDF before finalizing, following the [TeX instructions](https://info.arxiv.org/help/submit_tex.html).

The [official moderation and generative-AI policy](https://info.arxiv.org/help/moderation/index.html#policy-for-authors-use-of-generative-ai-language-tools) governs significant AI disclosure and human responsibility. AI systems are tools, not authors. Mechanical preparation does not guarantee acceptance. No expert email, endorsement request or account changes were made in this fork.
