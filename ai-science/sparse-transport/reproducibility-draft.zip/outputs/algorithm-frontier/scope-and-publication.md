> Historical first-stage review. The current manuscript and stage2-* reviews supersede its solver bounds and implementation status. This file is retained as research history.

# Scope, categorical structure, and publication preparation

Research assessment, 21 October 2026. One bounded independent pass. No submission, publication, website edit, paid job, or external contact was made. This assessment is not a priority certificate or independent mathematical referee report.

## Recommended scope

The strongest credible project is the existing exact transport reduction for graph curvature under bounded complement codegree, strengthened by sparse implication encoding and an explicit small-target flow analysis. The likely contribution is the structural reduction and its construction from pair witnesses. Maximum closure, threshold labels, range-tree encoding, and faster flow algorithms are established ingredients. A sharper exponent alone does not make their combination a major discovery.

| Rank | Narrow problem | Plausible contribution | Main risk |
|---|---|---|---|
| 1 | Exact all-edge zero-idleness curvature with complement codegree parameter k | Parameter-only transport dimension, construction without scanning large common neighborhoods, sparse cut encoding, sharp source-type examples | Priority relative to recent curvature reductions remains to be checked; distinction from Lin–Lu–Yau curvature must remain explicit |
| 2 | Maximum-weight unary implication closure with a small set of shared dependency nodes and sparse exception lists | General reusable formulation of the network used in rank 1; direct O(r² E) flow analysis when removing r nodes leaves bounded components | Short-path Dinic analysis is classical; a general theorem may be a useful lemma rather than a separate paper |
| 3 | Exact weighted Hall-deficiency queries for dense bipartite relations specified by sparse forbidden pairs | A clean combinatorial primitive, potentially reusable for matching feasibility, bottleneck certificates, and transport lower bounds | Classical maximum closure already solves the primitive; value depends on a genuinely better representation/construction bound |
| 4 | Faster formal-concept or general Horn-closure optimization | Strong literal Galois/closure vocabulary and broad applications | No new algorithm established in this pass; general closure systems have much less tractable optimization than unary implications; philosophically appealing terminology is not evidence of novelty |

Do not switch to an unrelated CS problem merely to promise greater novelty. The first two rows can form one coherent paper if the structural and complexity statements survive audit. The more general closure lemma can explain transferability without pretending to solve arbitrary closure optimization.

## Concrete efficiency observations

### Short augmenting paths

In the uncompressed two-threshold closure network, remove its two target-threshold nodes per target and the two terminals. Every remaining component has at most two source-threshold nodes. A simple residual path can visit each removed node at most once, and between such visits it can use at most two vertices in a source component. Its length is therefore O(beta), independently of the number of source types.

Dinic has O(L) phases when every simple residual path has length at most L. A DFS blocking-flow implementation has O(E) failed edge examinations and O(E) successful augmentations per phase, with O(L) work per augmentation. Thus O(L² E) is sufficient. With beta=O(k), O(k³) source types, and O(k⁴) explicit arcs, this gives O(k⁶) per residual problem.

This reasoning is classical. Ahuja, Orlin, Stein, and Tarjan explicitly analyze flow algorithms through longest simple path length and derive the O(L² E) Dinic bound for unbalanced networks in [Improved Algorithms for Bipartite Network Flow, Princeton technical report 338 (1991)](https://www.cs.princeton.edu/techreports/1991/338.pdf). The indexed paper text was available; direct PDF opening returned HTTP 403 during this pass. Our graph has two-node source gadgets instead of strict bipartiteness, so include the elementary deletion/path argument above rather than invoking bipartiteness incorrectly.

### Sparse implication encoding

For common-source masks M over q targets, pair-witness counting gives

    sum_M binomial(|M|, 2) <= (k-1) binomial(q, 2)

when the sum uses one representative per distinct multi-miss mask. Since |M| <= 2 binomial(|M|,2) for |M|>=2, the total cardinality of these distinct masks is O(k q²). At q=O(k) this is O(k³). Include the O(q) singleton masks and the empty mask separately.

The dense implications from a source to all targets outside its mask can be represented by a shared downward segment tree over each target-threshold layer. Decompose the complement of each sorted mask into intervals and each interval into canonical tree nodes. This uses O((|M|+1) log(q+1)) source-to-tree arcs. Tree edges have implication capacity and auxiliary nodes have zero weight. The sparse implications on missing targets are retained explicitly. There are O(q) shared tree nodes, so deleting the target/tree nodes again leaves tiny source gadgets.

Correctness obligation: every original feasible closure extends by selecting all tree nodes reachable from selected source nodes; every feasible extended closure restricts to an original feasible closure. Zero auxiliary weights preserve the objective. Extra voluntarily selected tree nodes cannot improve the optimum and do not invalidate this equivalence. Use one finite implication capacity exceeding a known feasible finite cut, including on tree edges.

For the large-order branch this gives E=O(k³ log(k+1)) and the same O(k) path bound, hence O(k⁵ log(k+1)) per residual problem. These are deductions, not a claim that segment-tree compression itself is novel.

The coordinating proof audit proposes the same E bound in the small-order branch with V=O(k²). Conditional on that construction bound, a general O(VE) flow solver yields the same O(k⁵ log(k+1)) time. Uniform Dinic instead has the directly supported O(k⁷ log(k+1)) bound in that branch. A paper must state which solver realizes which theorem; correctness and benchmark results from Dinic do not constitute an implementation of Orlin's algorithm.

### Orlin applicability and precise attribution

[James B. Orlin, Max flows in O(nm) time, or better, STOC 2013, pp. 765–774, DOI 10.1145/2488608.2488705](https://dspace.mit.edu/entities/publication/a8e3de96-c2b5-46ed-9ca3-0411c8549317) establishes the uniform O(VE) maximum-flow bound by combining a new sparse-network algorithm with earlier results for denser networks. Its displayed sparse bound alone has an additional E^(31/16) log² V term; do not apply that formula as O(VE) in every density regime. The author's [publication list](https://mitmgmtfaculty.mit.edu/jorlin/publications/) confirms the paper. Our finite nonnegative integer-capacity closure networks fall within ordinary maximum flow; no unit-capacity or bipartite assumption is required. The result supports a theoretical subroutine choice, not a claim that the included implementation uses it.

## Two exact categorical bridges

These are mathematical identifications, not evidence of a new category-theoretic theorem.

### Transport inequalities form an adjunction

For a finite cost matrix c, order source and target potential vectors coordinatewise. Define

    A(g)_i = min_j(c_ij + g_j),
    B(f)_j = max_i(f_i - c_ij).

Both maps are monotone, and direct rearrangement proves

    B(f) <= g  if and only if  f <= A(g).

Thus B is left adjoint to A between the two product posets. The composite A B on source potentials is extensive, monotone, and idempotent; B A on target potentials is reductive, monotone, and idempotent. Their fixed points encode tight compatible potentials. Feasibility of the transportation dual is precisely either side of the displayed adjunction condition.

This provides a literal Galois-connection interpretation of the potential-tightening operation. The existence of the adjunction does not produce a runtime bound, a number of iterations, or an optimal weighted potential by itself. The useful algorithmic facts come from integral bounded labels and the special matrix representation.

### Implication closure is a reflection

For the finite implication digraph, define C(S) as every vertex reachable from S, including S itself. Then C is extensive, monotone, and idempotent. Let Fix(C) be the family of successor-closed sets and i its inclusion into the powerset poset. For any closed T,

    C(S) subseteq T  if and only if  S subseteq i(T).

Consequently C, with codomain Fix(C), is left adjoint to i. If an anchor is forced, replace C(S) by the reachability closure of S together with that anchor, and take fixed points containing it. Threshold-label feasibility is exactly membership in this finite closure system. Maximum closure optimizes a weight over these fixed points; it is not merely application of the closure operator to an arbitrary starting set.

The [nLab closure-operator page](https://ncatlab.org/nlab/show/closure+operator) describes closure operators as monads on posets and relates them to reflections. Its [Galois-connection page](https://ncatlab.org/nlab/show/Galois+connection) distinguishes monotone adjunctions from the antitone convention used there and explains the induced closure operators. Our formulas use the monotone convention explicitly, preventing a sign/order ambiguity.

The computational reduction to maximum closure is established optimization machinery; cite [Jean-Claude Picard, Maximal Closure of a Graph and Applications to Combinatorial Problems, Management Science 22(11), 1268–1272 (1976)](https://pubsonline.informs.org/doi/abs/10.1287/mnsc.22.11.1268). Do not describe the minimum-cut reduction as discovered here.

## Hegel and website placement

The [nLab Science of Logic page](https://ncatlab.org/nlab/show/Science+of+Logic) explicitly presents an ongoing interpretation/formalization of Hegel using categorical logic and modal type theory. Its dictionary associates moments with modalities and an opposition/unity construction with adjoint modalities. This is an attributed interpretive project, not a consensus identification of Hegel's text with our finite transport algorithm.

A defensible optional note is: the finite reflection above gives an elementary example of the closure/adjunction structures discussed in that interpretive tradition. No stronger claim about dialectics producing a computational improvement is supported. Prefer a brief contextual footnote or separate website essay; omit Hegel from the theorem statement and algorithmic novelty claim.

The connected GitHub repository tree for Autio/autio.github.io on master contains [projects/scienceoflogic](https://github.com/Autio/autio.github.io/tree/master/projects/scienceoflogic). Its README identifies the existing project as HegelWheel, a D3 visualization of Science of Logic. The inspected tree did not reveal a dedicated science-experiments directory by that name. A new research/experiments entry is a proposed information-architecture choice, not an existing destination verified here. No website files were changed.

## arXiv preparation requirements checked on official pages

Checked 21 October 2026; verify again at actual submission because policy and tooling can change.

**Authorship and AI disclosure.** The [official moderation policy](https://info.arxiv.org/help/moderation/index.html#policy-for-authors-use-of-generative-ai-language-tools) requires reporting significant use of generative AI tools, holds each human author responsible for the entire work, and says generative AI tools should not be authors. It also requires substantive original research and careful scholarly presentation; a completed archive is not a guarantee of acceptance. A disclosure for this project should accurately describe AI-assisted conjecture exploration, proof drafting, code, testing, and literature search, and state only the human verification that actually occurred. Do not write that the author independently verified everything unless that is true.

**Endorsement.** The [official endorsement page](https://info.arxiv.org/help/endorsement.html) says endorsement is required for a first submission or a new category. Institutional email plus claimed authorship can support automatic endorsement; institutional email alone should not be promised sufficient. Otherwise the submission flow provides a personal-endorsement request. The endorser should be knowledgeable in the area; at least one positive endorsement is required for the relevant endorsement category. Endorsement is not peer review. No user account eligibility was inspected, and no endorser was contacted.

**Source package.** Follow the [official TeX submission instructions](https://info.arxiv.org/help/submit_tex.html): provide the needed TeX inputs, figures, and custom styles; a ZIP or tar archive is supported. Use paths relative to the submission root. Include bibliography inputs or the processed bibliography as appropriate to the selected system. Exclude unused files, backups, logs, and generated main-document output. Use a fixed date. Verify the PDF produced by arXiv's selected processor before completing submission. For this project a self-contained article with standard packages and a short embedded bibliography is the simplest robust option.

**Presentation.** The [format policy](https://info.arxiv.org/help/policies/format_requirements.html) requires named authorship, complete references, machine-readable text, single spacing, 10–14 point type, and at least one-inch margins. Avoid line numbers, distracting watermarks, margin notes, highlighting, and referee remarks. Code/data links must resolve publicly. Large code listings or datasets belong in ancillary material rather than the article body. Until a repository is public, do not invent or print a working artifact URL; supply the reproducibility archive locally and leave the public-link field explicitly pending.

**License.** The [official license page](https://info.arxiv.org/help/license/index.html) makes the submitter responsible for selecting a license they can grant. The chosen license for each posted version is irrevocable, and arXiv preserves a permanent record. Prepare the licensing decision as an explicit metadata item; do not infer it from the website repository's license or choose on the user's behalf during package assembly.

Suggested manuscript package: main.tex, necessary figure files, bibliography material if external, and a README giving compilation instructions. Keep a separate reproducibility archive with source code, exact commands, test output, parameter assumptions, and data provenance. Keep a separate submission-notes file with proposed title/abstract, suggested primary category (likely cs.DS for an algorithm-focused paper, subject to author and moderator judgment), author identity, endorsement status, disclosure, and license marked for final decision. The research claims need mathematical review before the package can honestly be called ready for submission; mechanical compilation alone is insufficient.

## Remaining decision boundary

This pass supports a concrete algorithm-paper direction and supplies an exact categorical explanation. It does not establish priority, guarantee arXiv acceptance, or certify the full proof. The immediate useful work is to finish the sparse-network proof in both order branches, verify the implementation independently, and compare the final claim with the closest transport/curvature literature. Broader speculation should not dilute that work.
