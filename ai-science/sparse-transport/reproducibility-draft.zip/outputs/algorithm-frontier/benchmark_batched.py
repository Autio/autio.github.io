"""Matched classical closure vs direct batched transport, no best-software claim."""
from pathlib import Path
from benchmark import instance
from sparse_closure import transport_cost as closure
from batched_transport import transport_cost as batched
import time,gc,json,platform,statistics,hashlib
root=Path(__file__).resolve().parent
rows=[]
for missing_cost in (2,3):
    for k in (8,16,32):
        supplies,demands,exceptions,expected=instance(k)
        exceptions=[tuple((j,missing_cost) for j,c in row) for row in exceptions]
        expected=sum(supplies)+(missing_cost-1)*(k-1)
        record={'k':k,'missing_cost':missing_cost,'sources':len(supplies),'targets':len(demands)}
        for name,solver,encoding in (('closure_dense',closure,'dense'),('closure_segment',closure,'segment'),
                                     ('batched_dense',batched,'dense'),('batched_segment',batched,'segment')):
            times=[]
            for _ in range(3):
                gc.collect();start=time.perf_counter()
                value,proof=solver(supplies,demands,exceptions,0,True,encoding=encoding)
                times.append(time.perf_counter()-start);assert value==expected
            record[name]={'median_seconds':statistics.median(times),'seconds':times,
                          'nodes':proof['nodes'],'arcs':proof['arcs'],'phases':proof['phases'],
                          'augmentations':proof['augmentations']}
            if 'stages' in proof:record[name]['stages']=proof['stages']
        rows.append(record);print(json.dumps(record),flush=True)
result={'passed':True,'repeats':3,'python':platform.python_version(),'platform':platform.platform(),
  'processor':platform.processor(),'scope':'synthetic triple-mask family; complete transport costs1/2 or1/3; identical inputs, includes construction and certificates',
  'solver_sha256':hashlib.sha256((root/'batched_transport.py').read_bytes()).hexdigest(),'rows':rows}
(root/'batched-benchmark.json').write_text(json.dumps(result,indent=2))
