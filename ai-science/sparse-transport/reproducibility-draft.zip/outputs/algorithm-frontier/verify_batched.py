"""Independent exact checks of batched direct transport, including nonmetrics."""
from pathlib import Path
from itertools import product
import json,random,time
from batched_transport import transport_cost
from adaptive_curvature import preprocess
from general_complement import mincost

root=Path(__file__).resolve().parent
def run():
    start=time.perf_counter();rng=random.Random(2026102105);checked=0;max_stages=0
    for m,q in ((1,1),(1,3),(3,1),(2,2),(2,3),(3,2),(3,3)):
        for values in product((1,2,3),repeat=m*q):
            costs=[list(values[i*q:(i+1)*q]) for i in range(m)]
            supplies=[rng.randrange(1,5) for _ in range(m)];M=sum(supplies)
            demands=[0]*q
            for _ in range(M):demands[rng.randrange(q)]+=1
            exceptions=[tuple((j,c) for j,c in enumerate(row) if c!=1) for row in costs]
            expected=mincost(supplies,demands,costs)
            for encoding in ('dense','segment'):
                actual,proof=transport_cost(supplies,demands,exceptions,certificate=True,encoding=encoding)
                assert actual==expected,(supplies,demands,costs,encoding,actual,expected)
                max_stages=max(max_stages,len(proof['stages']))
            checked+=1
    # Zero-supply and zero-total branches, plus arbitrary complete costs.
    for supplies,demands,rows in (([0,3],[1,2],[(),((1,3),)]),([0],[0],[()])):
        for encoding in ('dense','segment'):
            transport_cost(supplies,demands,rows,certificate=True,encoding=encoding)
    result={'passed':True,'complete_cost_matrices':checked,'max_stages':max_stages,
      'seed':2026102105,'seconds':time.perf_counter()-start,
      'scope':'all ternary cost matrices for dimensions through3x3 listed in script; random integral marginals; bothencodings against independent mincost'}
    (root/'batched-matrix-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':run()
