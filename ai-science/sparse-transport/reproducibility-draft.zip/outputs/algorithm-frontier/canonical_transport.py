"""Optional canonical Hall witness for the complete cost-one/two regime.

This bypasses common-source mask construction. It requires a>d*(k-1),
which holds on large-order candidates with 0<d<=k-1. Other cases return None.
Not selected by the main reducer, to keep general transport replay separate.
"""
from collections import deque
from fractions import Fraction

def edge_curvature(adj,x,y,k,data,allow_small_order=False):
    h,common,_=data;n=len(adj)
    if len(adj[x])>len(adj[y]):x,y=y,x
    a,b=len(adj[x]),len(adj[y]);d=b-a;R=set(common[x][y])
    beta=1+len(h[x])-len(R);alpha=1+len(h[y])-len(R);c=a-alpha
    large=n>=k*k+k+2;bk=max(k+1,2*k-2)
    if not large and not allow_small_order:return None
    if k==1 or (large and (beta>bk or d>=k)):
        return Fraction(c,b),{'shortcut':True,'large_order':large,'common_rows_materialized':0}
    if a<=d*(k-1):return None
    A=sorted({y}|(h[y]-h[x]));B=sorted({x}|(h[x]-h[y]));index={t:j for j,t in enumerate(B)}
    for u in A:
        for t in common[x][u]:
            if t in index and n-len(h[u])-len(h[t])+len(common[u][t])==0:
                return None # cost three is essential to the general problem
    edges=[[i for i,u in enumerate(A) if u in adj[t]] for t in B]
    mate_A=[-1]*alpha;mate_B=[-1]*beta;matching=0
    for first in range(beta):
        if mate_B[first]>=0:continue
        queue=deque([first]);seen={first};parent_A={};last=None
        while queue and last is None:
            j=queue.popleft()
            for i in edges[j]:
                if i in parent_A:continue
                parent_A[i]=j
                if mate_A[i]<0:last=i;break
                nxt=mate_A[i]
                if nxt not in seen:seen.add(nxt);queue.append(nxt)
        if last is not None:
            i=last
            while True:
                j=parent_A[i];previous=mate_B[j];mate_B[j]=i;mate_A[i]=j
                if previous<0:break
                i=previous
            matching+=1
    reached_B={j for j in range(beta) if mate_B[j]<0};reached_A=set();queue=deque(reached_B)
    while queue:
        j=queue.popleft()
        for i in edges[j]:
            if i in reached_A:continue
            reached_A.add(i);nxt=mate_A[i]
            assert nxt>=0 # otherwise the matching was not maximum
            if nxt not in reached_B:reached_B.add(nxt);queue.append(nxt)
    ell=alpha-matching;S0={B[j] for j in reached_B}
    assert len(S0)-len(reached_A)==beta-matching
    assert len(S0)-len(reached_A)-d==ell
    p0=alpha-len(reached_A);q0=0
    if d and S0 and len(S0)<beta:
        assert len(S0)>=2 and x not in S0
        s,t=sorted(S0)[:2];outside=set(A)|set(B)|R
        q0=sum(u not in outside and all(v in h[u] for v in S0) for u in common[s][t])
    elif len(S0)==beta:
        assert ell==0 and p0==0
    delta=a*ell+d*(p0+q0);assert delta>=0
    return Fraction(c,b)-Fraction(delta,a*b),{
      'shortcut':False,'large_order':large,'exclusive_sources':alpha,'targets':beta,
      'matching_size':matching,'ell':ell,'S0':sorted(S0),'p0':p0,'q0':q0,
      'scaled_deficit':delta,'common_rows_materialized':0,'dominance_margin':a-d*(k-1)}
