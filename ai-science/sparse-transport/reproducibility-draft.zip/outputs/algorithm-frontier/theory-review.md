> Historical first-stage review. The current manuscript and stage2-* reviews supersede its solver bounds and implementation status. This file is retained as research history.

# Algorithm frontier: structural compression and a sharp obstruction

Bounded theory review, 21 October 2026. This report reads the three prior frontier manuscripts and both Python solvers. It does not assert priority. No solver code was changed by this reviewer.

## Main recommendation

Combine the finite-order cutoff with a shared interval implication graph. This is a structural improvement of the reduction, independent of replacing one general maximum-flow algorithm by another.

For complement codegree at most k>=2, the resulting all-edge algorithm has the following bounds, including recognition and preprocessing:

* With a straightforward current-arc Dinic implementation and the separator argument below: O(k^7 log(k+1) n^2) arithmetic operations.
* Using that implementation on large graphs and an established O(VE) maximum-flow algorithm on the small-graph branch: O(k^5 log(k+1) n^2) arithmetic operations.

The second is a theoretical algorithm-selection corollary, not a claim that the more sophisticated O(VE) backend is implemented. Orlin's 2013 result, together with the earlier dense-network algorithm discussed there, supplies the established bound: [MIT repository](https://dspace.mit.edu/entities/publication/a8e3de96-c2b5-46ed-9ca3-0411c8549317). No new general flow algorithm is claimed. Capacities remain O(n^2), with O(log n)-bit words for fixed k.

The original Edmonds-Karp backend already improves from k^19 to k^11 simply by applying the order cutoff. With the segment graph below its safe coarse bound is O(k^9 log^2(k+1) n^2). These weaker statements are useful if one wants the theorem to track the old solver literally.

## 1. The two order regimes

Use the notation of sharp-theorems.md. When n>=k^2+k+2, any edge failing triangle equality has beta<=b_k=max(k+1,2k-2)=O(k). An edge with larger beta can therefore be returned immediately. This is a sufficient candidate filter; edges with smaller beta can still attain equality.

On remaining large-graph candidates, alpha<=beta=O(k). The common-source mask construction gives O(k^3) source types, since q=beta-1=O(k) and the number of original common sources missing at least two targets is at most (k-1) choose(q,2).

When n<=k^2+k+1, use the original residual sources without any compression if desired. There are at most n=O(k^2) sources and beta<=n=O(k^2) targets. This branch does not require sharper endpoint localization to obtain its dimension bound.

## 2. A bound on total missing incidence, not just the number of rows

Let Q=B minus {x}. For every residual source u, whether exclusive or common, define M(u)={t in Q: ut is an H-edge}. Since Q is contained in N_H(x),

    |M(u)| <= |N_H(u) intersect N_H(x)| <= k.

The vertices u and x are distinct, so the codegree hypothesis applies. Every target outside M(u), including x, has cost one. A common source has cost two on its mask; an exclusive source can have costs two or three there.

Let I be the sum of mask cardinalities over the retained source rows. In the small-graph branch, I<=k*m=O(k^3).

In the large-graph branch the exclusive rows contribute at most alpha*k=O(k^2). For common rows, count each distinct mask once after aggregation. There are at most q singleton masks. For masks of size r>=2 use r<=2 choose(r,2). Every target pair belongs to at most k-1 original common-source masks, because x is already a common H-neighbor of that pair. Therefore

    I_common <= q + 2*(k-1)*choose(q,2) = O(k^3).

Aggregation only lowers this pair-incidence count. Hence I=O(k^3) in BOTH order regimes. This is what makes sparse implication encoding useful.

## 3. Shared segment-tree implication graph

Retain the source and target threshold variables from mincut-algorithm.md. For each target threshold level, build a binary segment tree over the ordered targets. Its leaves are the actual target threshold nodes. A helper node has weight zero and implication arcs to its two children. Thus choosing a helper forces all target leaves in its interval. There are O(beta) helper nodes and arcs in each of the two trees.

The distance-one targets of row i are the complement of its sorted mask. They form at most |M_i|+1 consecutive intervals. Decompose each such interval into O(log(beta+1)) canonical tree nodes:

* Add implications from F_i^0 to the lower-tree cover of every distance-one interval.
* Add implications from F_i^1 to the upper-tree cover of every distance-one interval.
* For each distance-two mask entry j, add the original direct implication F_i^1 -> G_j^-1.
* Distance-three mask entries need no cross implication.

Keep the original F_i^1 -> F_i^0 and G_j^0 -> G_j^-1 implications and the forced anchor. Retain the original positive/negative weights, capacity 4M+1, and formula D=3M-lambda.

Correctness is exact: projecting a closure onto original nodes satisfies all old implications. Conversely, any old closure extends by selecting precisely the helper nodes reached from its selected source nodes, and all their descendants. The original target selections already include these leaves. Helpers have zero weight, so the objective is unchanged. Arbitrary extra helper selections cannot improve the optimum beyond a feasible original closure.

The resulting size is

    V=O(m+beta),
    E=O((m+I+beta)*log(beta+1)).

Consequently large candidates have V=O(k^3), E=O(k^3 log(k+1)), and small graphs have V=O(k^2), E=O(k^3 log(k+1)). Constructing the prior dense distance matrix, if retained for convenience and verification, costs at most O(k^4) per candidate and does not dominate any claimed runtime.

An alternative overlapping-power-of-two interval DAG gives O(1) arcs per interval but O(beta log beta) helpers. This gives a better Edmonds-Karp-only exponent/log bound, but a worse separator bound for Dinic. The ordinary segment tree is preferable for the recommended algorithm.

## 4. Dinic bound from a small separator

In the underlying undirected closure graph, delete the two terminals, all target threshold vertices, and all segment helpers. Only isolated pairs {F_i^0,F_i^1} remain. The deleted set has O(beta) vertices, regardless of m. The same statement holds for every residual network: reverse residual arcs add no new undirected incidences.

A simple residual source-to-sink path can visit at most O(beta) remaining source gadgets, because each transition between distinct gadgets passes through a distinct deleted vertex. Each gadget has two vertices. Thus every simple residual path has length L=O(beta).

Dinic strictly increases the shortest augmenting-path length between successful phases; there can be O(L) phases. A conventional current-arc blocking-flow implementation takes O(L*E) per phase: unsuccessful adjacency scans total O(E), and each successful augmentation saturates a level edge, with O(L) path work. Hence the total is O(beta^2 E), independently of capacities.

This yields O(k^5 log(k+1)) per large candidate and O(k^7 log(k+1)) per small candidate. For the theoretical stronger hybrid, the small-graph sparse network instead takes O(VE)=O(k^5 log(k+1)) via the established general solver. Multiplying by at most n^2 edges establishes the stated bounds.

This proof needs an actual blocking-flow implementation with current-arc reuse. It should not be attributed to arbitrary BFS augmenting paths or to an implementation that restarts all scans after every augmentation. In particular, the existing Edmonds-Karp implementation does not inherit this bound simply from being run on the sparse graph.

## 5. Cubic distinct source types are sharp, even on defective edges

For every k>=5 take x,y; a set S of size two; T of size k-2; Z of size k-1; and one common-source vertex c_U for every three-element subset U of T. Define H by exactly these edges:

    x -- (S union T),
    y -- Z,
    Z -- S,
    c_U -- U, for every U in choose(T,3).

Pad with isolated H vertices until n>=k^2+k+2 if necessary. At xy in the complement G,

    A={y} union Z, alpha=k,
    B={x} union S union T, beta=k+1,
    d=b-a=1.

All c_U lie in C and have distinct masks U, each with positive scaled supply d=1. Thus this family has at least choose(k-2,3)=Theta(k^3) distinct positive-supply common-source cost rows, in the large-order candidate regime.

The codegree condition holds at every pair. The two S vertices have exactly {x} union Z as common H-neighbors, giving codegree k. Two T vertices have x and the k-4 triple vertices containing both, giving k-3. Two distinct Z vertices share S union {y}, giving three. A pair x,c_U shares U, giving three. Two distinct triple vertices share at most two targets. The potentially larger mixed pair y,s for s in S shares Z, giving k-1. Other pair types have at most two common neighbors. Isolated padding changes none of these counts.

The graph G is connected: Z reaches x, S union T reaches y, and xy is an edge. Every relevant residual distance is at most two. Common sources use y for missing targets; a missing Z-to-S transfer can go through any T vertex.

The S witness has p=k-1, q=0 and s=2, so

    L=s+p-beta=0,
    F=d*(p+q)=k-1>0.

Thus these are genuinely triangle-defective edges, not just candidate edges accidentally requiring a redundant reduction. The exact gap is (k-1)/(ab): S is the only positive Hall obstruction. Proper subsets of S have negative numerator; a set meeting both S and T excludes no sources; subsets of T can exclude only triple sources and have strictly negative slope, so above the finite-order cutoff cannot be deficient. Sets containing x cannot be deficient.

This disproves any general O(k^(8/3)) bound on distinct masks in this setting. It does NOT prove an Omega(k^3) lower bound for every possible algorithm or every more semantic compression: many distinct rows can be irrelevant to the optimal value. In this family the triple rows do not cause the actual S obstruction.

## 6. Adversarial checks performed and remaining scope

Using the existing Python preprocessing and closure solver, an in-memory independent family generator checked k=5,...,10 after padding to n=max(k^2+k+2, 2k+1+choose(k-2,3)). It verified codegree recognition, positive source supplies, the triple-mask counts 1,4,10,20,35,56, and exact gap (k-1)/(ab) in all six cases. No test file or code changes were made by this reviewer.

Important checks for the implementation owner: preserve distance-three entries on exclusive rows; preserve zero-weight helper implications and the forced anchor; check equal-degree edges with no common-source supply; compare sparse and dense closure on random cost rows satisfying the anchor premise; compare graph cases against the independent full transport solver. The segment tree is a standard implication-sharing construction, not asserted to be a new data structure.

The substantive candidate contribution is the combination of the sharp order cutoff, O(k^3) total missing incidence, and a graph-class-specific sparse reduction. General maximum closure, interval trees, Dinic, O(VE) flow, and the small-side flow principle remain established machinery. Priority of this combination has not been established.
