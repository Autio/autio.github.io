> Historical first-stage review. The current manuscript and stage2-* reviews supersede its solver bounds and implementation status. This file is retained as research history.

# Bounded adversarial code audit

21 October 2026. Reviewed `sparse_closure.py`, `adaptive_curvature.py`, and `theory-review.md`. The owner reports an exact replay of 218,956 edges; this review does not recount that replay as a new independent experiment.

## Verdict

No fatal correctness or parameter-complexity issue was found. The sparse reduction preserves cost-three entries, both threshold levels, and the anchor. Aggregating exclusive and common sources with identical exception rows is exact even though their individual supplies differ: only total supply per identical cost row matters.

The one-level distance-one-flow specialization below gives a measured practical improvement on the structured test family. It is classical and was already justified by the diameter-two Hall formula in the earlier manuscripts. The existing adaptive reducer default was left unchanged.

## Specific adversarial checks

**Exception extraction.** For every source u, `common[x][u]` is exactly the set of H-neighbors it shares with x. Filtering this list against B therefore recovers every missing target and no distance-one target. Target x cannot occur. For an exclusive-source missing pair, `n-degree_H(u)-degree_H(s)+codegree_H(u,s)` is the correct common-G-neighbor count; using zero versus positive correctly distinguishes distances three and two. The common-source branch correctly assigns distance two through y.

**Large-order aggregation.** The outside set A union B union R is the complement of C. Pair enumeration therefore extracts all and only C sources missing at least two targets. Counting singleton masks by complement degree minus outside incidences minus multiple-mask incidences is correct. The anchor's singleton count is zero. Zero degree difference correctly suppresses all common-source supply. The final supply assertion checks total mass a*beta.

**Segment implications.** The two shared trees have exactly 2*(beta-1) helpers. Tree arcs point from an interval to its leaves; source interval covers force exactly the intended distance-one target thresholds. Cost-two exceptions retain the upper-source-to-lower-target implication. Cost-three exceptions correctly add none. Empty intervals are never passed to the recursive interval routine. The cases beta=1 and an empty exception list are valid.

**Blocking flow.** The iterative implementation retains its current-arc pointers after each successful augmentation. It only increments a parent's pointer after exhausting a child or encountering an unusable edge. Within a fixed level graph, forward capacities cannot increase, so an exhausted child does not become usable again. Resetting the path stack to the source does not reset the pointers and does not invalidate the O(L*E) blocking-flow bound. Each successful augmentation saturates an admissible edge. The separator argument bounds the length of all simple residual paths, including failed DFS branches, not only the recorded shortest path length.

**Finite infinity.** The existing closure capacity 4M+1 is sufficient, and its maxflow/mincut and dual-value checks remain correct with zero-weight helper vertices. The optional new one-level solver uses M+1, because its source-isolating cut has capacity M.

## Certificate and construction overhead

The closure certificate currently checks all m*beta source-target pairs, even when `certificate=False`. The adaptive reducer always requests the full internal certificate and strips potentials from its returned metadata unless requested. This is extra practical work, but not a contradiction in either claimed bound:

* Large candidates have m=O(k^3), beta=O(k), so verification costs O(k^4).
* Small graphs have m,beta=O(k^2), again giving O(k^4).
* Both are below O(k^5 log(k+1)), the stronger theoretical hybrid bound.

More generally m*beta<=O(beta*E), because the network has at least O(m) source arcs. The verification therefore also fits the O(beta^2*E) separator-Dinic bound directly. It would be inaccurate to describe the complete routine as spending only O(E) on certificate verification. If desired, checking all implication arcs plus the objective would provide a sparse certificate; the current stronger direct check is valid.

Row construction also fits. For large candidates, the pair enumeration has O(k^3) list entries. Reading up to k common-neighbor entries for each extracted source can take O(k^4); sorting their masks adds at most a log(k+1) factor. This remains below O(k^5 log(k+1)). The small branch scans at most O(k^2) original vertices and O(k^3) common-neighbor-list entries. No large common neighborhood is scanned in the large-order branch.

## Scope and representation qualifications

The supplied bound k may grow with n. The combinatorial bounds still hold; graph-derived capacities are at most O(n^2), uniformly in k. For a clean word-RAM statement, take 1<=k<=max(1,n-2), or cap an oversized bound at the trivial maximum codegree. An arbitrarily enormous encoded integer k otherwise needs its own input-bit accounting. This is a representation qualification, not a counterexample to the parameter bound.

The literal Python implementation uses sets/dictionaries, so its lookup guarantees are expected-time rather than the deterministic indexed-table version of the theorem. It also returns reduced `Fraction` objects. The theorem explicitly permits unreduced rational output; reducing every fraction entails additional gcd/bit work that is not part of that strict arithmetic bound. This distinction should remain explicit.

At audit time `all_curvatures` iterated `sorted(adj[x])`. In a comparison-cost analysis this introduces an avoidable O(n^2 log n) bound when k is fixed. The owner was notified and is handling the simple iteration-order fix. The ordering of edges does not affect correctness. Sorting the small A, B, and mask sets is already absorbed into the parameter-dependent bounds.

The theorem concerns well-formed connected graph inputs and ordinary `force_reduce=False` operation. The public routines do not comprehensively validate adjacency symmetry or connectedness. Forcing a reduction bypasses candidate-size filters, so forced diagnostic runs should not inherit the localized size guarantees.

## Optional one-level backend

Added `one_level_transport.py` without changing the existing reducer. For complete residual costs in {1,2}, let F be the maximum transportation mass routed along distance-one pairs, and M the total mass. Then

    exact transport cost D = 2M-F.

Any full plan has cost 2M minus its cost-one mass, which is at most F. Conversely extend a maximum cost-one partial flow to a full plan using the remaining complete transportation matrix, whose costs are at most two. This attains the bound. The identity does not require the special bounded-dual or anchor hypotheses; it works for any complete cost-one/two matrix. Cost-three inputs are explicitly rejected by this backend and must continue to use closure.

The backend has dense and one-segment-tree variants, ordinary weighted source/target capacities, and iterative Dinic. It verifies a maxflow/mincut certificate, every original arc's capacity feasibility, conservation at every intermediate vertex, and an attaining transport dual. These checks include all segment helpers. A mincut with reachable source rows U and reachable target columns T gives the feasible dual f_i=1+1[i in U], g_j=1[j in T]. Its objective is 2M-F. If all supplies and demands are equal, this specializes further to ordinary cardinality matching.

## Bounded tests and timings

Three timed runs per backend/encoding on `benchmark.instance(k)` gave the following median seconds, including each solver's own construction, flow, and certificate work. Additional cross-solver and all-pairs dual comparisons were outside the timed interval. Garbage collection ran before each trial. These are synthetic structured instances, not application workloads.

| k | Closure dense | Closure segment | One-level dense | One-level segment |
|---|---:|---:|---:|---:|
| 5 | 0.000188 | 0.000400 | 0.000084 | 0.000124 |
| 8 | 0.001030 | 0.002039 | 0.000332 | 0.000562 |
| 12 | 0.007259 | 0.015886 | 0.002136 | 0.004413 |
| 16 | 0.029275 | 0.054255 | 0.008087 | 0.013039 |
| 24 | 0.315002 | 0.406030 | 0.056156 | 0.083625 |
| 32 | 1.228150 | 1.968677 | 0.302003 | 0.286151 |

At k=32, one-level dense used 125,959 arcs versus 268,196 for dense closure. One-level segment used 40,232 arcs versus 96,742 for segment closure. The one-level specialization was consistently faster on this family. Dense one-level won through k=24; segment was only slightly faster at k=32, which does not establish a stable general crossover. Segment closure remained slower than dense closure throughout this bounded run.

Seeded actual-graph comparisons used seed 20261021, orders 5 through 30, and several complement densities. Of 60 generated graphs, 53 were connected. For up to 12 sampled edges per graph, forced reduction exposed 454 cost-one/two instances; both one-level encodings agreed exactly with the closure solver and passed explicit all-pairs transport-dual feasibility checks. Another 180 residual instances had cost-three entries and were excluded from the specialization as intended. Small zero-mass, singleton, all-cost-two, and anchor-free cases also passed. A cost-three input rejection was explicitly checked.

Raw bounded benchmark results are saved in `one-level-benchmark.json`. These tests supplement the owner's broader replay; they are not exhaustive verification of the new backend. The new backend's only mathematical ingredient is the established diameter-two Hall/maxflow identity.
