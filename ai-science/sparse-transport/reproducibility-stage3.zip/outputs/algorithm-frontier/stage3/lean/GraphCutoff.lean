import GraphHall
import SharpLocalization
import SparseFilter

/-! Graph-level bridge to sharp Hall localization.
The input is an actual target set with positive denominator-cleared Hall deficit.
Optimal transport, weighted Hall existence and extremal graph realization are not
formalized here. Imported historical modules are copied unchanged beside this file.
-/
namespace CurvatureGraph

variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def remainder (x y : V) : Finset V :=
  Gᶜ.neighborFinset x ∩ Gᶜ.neighborFinset y

theorem neighborhood_partition (x y : V) (hxy : G.Adj x y) :
    G.degree x + (targetsB G x y).card + (remainder G x y).card = Fintype.card V := by
  have hdis : Disjoint (G.neighborFinset x) (targetsB G x y) := by
    apply Finset.disjoint_left.mpr
    intro v hv ht
    exact (Finset.mem_sdiff.mp ht).2 hv
  have hrest : remainder G x y = Finset.univ \ (G.neighborFinset x ∪ targetsB G x y) := by
    ext v
    simp only [remainder, targetsB, Finset.mem_inter, SimpleGraph.mem_neighborFinset,
      SimpleGraph.compl_adj, Finset.mem_sdiff, Finset.mem_univ, Finset.mem_union,
      true_and]
    constructor
    · rintro ⟨⟨_, hx⟩, ⟨_, hy⟩⟩
      tauto
    · intro hv
      have hx : ¬G.Adj x v := by tauto
      have hy : ¬G.Adj y v := by tauto
      have hxv : x ≠ v := by intro he; subst v; exact hy hxy.symm
      have hyv : y ≠ v := by intro he; subst v; exact hx hxy
      exact ⟨⟨hxv,hx⟩,⟨hyv,hy⟩⟩
  have hc := Finset.card_sdiff_add_card_eq_card
    (show G.neighborFinset x ∪ targetsB G x y ⊆ Finset.univ from Finset.subset_univ _)
  rw [← hrest, Finset.card_union_of_disjoint hdis] at hc
  rw [Finset.card_univ] at hc
  change (remainder G x y).card + (G.degree x + _) = _ at hc
  omega

theorem exclusive_common_partition (x y : V) :
    (sourcesA G x y).card + (sourcesC G x y).card = G.degree x := by
  exact Finset.card_sdiff_add_card_inter _ _

theorem exclusive_target_difference (x y : V) :
    (targetsB G x y).card + G.degree x =
      (sourcesA G x y).card + G.degree y := by
  have ha := exclusive_common_partition G x y
  have hb := exclusive_common_partition G y x
  have hC : sourcesC G y x = sourcesC G x y := Finset.inter_comm _ _
  rw [hC] at hb
  change (sourcesA G y x).card + G.degree x = _
  omega

theorem excluded_partition (x y : V) (S : Finset V) :
    (excluded G (sourcesA G x y) S).card +
      (excluded G (sourcesC G x y) S).card =
      (excluded G (G.neighborFinset x) S).card := by
  have hunion : sourcesA G x y ∪ sourcesC G x y = G.neighborFinset x := by
    ext v; simp [sourcesA,sourcesC]; tauto
  have hdis : Disjoint (sourcesA G x y) (sourcesC G x y) := by
    apply Finset.disjoint_left.mpr
    intro v hv ht
    exact (Finset.mem_sdiff.mp hv).2 (Finset.mem_inter.mp ht).2
  have hfilter : excluded G (G.neighborFinset x) S =
      excluded G (sourcesA G x y) S ∪ excluded G (sourcesC G x y) S := by
    rw [← hunion]; simp [excluded, Finset.filter_union]
  have hdis' : Disjoint (excluded G (sourcesA G x y) S)
      (excluded G (sourcesC G x y) S) :=
    hdis.mono (Finset.filter_subset _ _) (Finset.filter_subset _ _)
  rw [hfilter, Finset.card_union_of_disjoint hdis']

/-- Actual finite graph inputs imply the sharp order bound. The positive Hall
deficit and its witness of size at least two are explicit assumptions, rather
than an unformalized assertion about Wasserstein curvature. -/
theorem graph_negative_slope_cutoff_of_witness_bounds (k : ℕ) (hk : 2 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (S : Finset V) (hS : S ⊆ targetsB G x y) (hx : x ∉ S)
    (hs : 2 ≤ S.card)
    (hU : (excluded G (G.neighborFinset x) S).Nonempty)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card)
    (hdef : ((targetsB G x y).card : ℤ) * G.degree x <
      (S.card : ℤ) * G.degree x +
      ((excluded G (sourcesA G x y) S).card : ℤ) * G.degree y +
      ((excluded G (sourcesC G x y) S).card : ℤ) *
        ((G.degree y : ℤ) - G.degree x)) :
    Fintype.card V ≤ k*k+k+1 := by
  have hsk := excluded_set_card G k hcode x y S hS hx hU
  have hex := excluded_sources_count G k hcode x y S hS hx hs
  have hpartition := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hqc : (excluded G (sourcesC G x y) S).card ≤ (sourcesC G x y).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  have hdegree := exclusive_common_partition G x y
  have hdiff := exclusive_target_difference G x y
  have horder := neighborhood_partition G x y hxy
  have hr : (remainder G x y).card ≤ k := hcode x y hxy.ne
  have hpair : 2 ≤ (excluded G (sourcesA G x y) S).card → S.card + 1 ≤ k :=
    two_excluded_exclusive_sources G k hcode x y S hS hne
  have hcut := Curvature.negative_slope_order_bound (k : ℤ) (G.degree x : ℤ)
    ((sourcesA G x y).card : ℤ) ((targetsB G x y).card : ℤ)
    ((G.degree y : ℤ) - G.degree x)
    ((excluded G (sourcesA G x y) S).card : ℤ)
    ((excluded G (sourcesC G x y) S).card : ℤ) (S.card : ℤ)
    ((remainder G x y).card : ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by intro hp; have hh := hpair (by omega); omega)
    (by omega) (by convert hdef using 1; ring)
  exact_mod_cast (show (Fintype.card V : ℤ) ≤ (k : ℤ)*k+k+1 by
    norm_cast at hcut ⊢
    omega)

def positiveDefect (x y : V) (S : Finset V) : Prop :=
  ((targetsB G x y).card : ℤ) * G.degree x <
    (S.card : ℤ) * G.degree x +
    ((excluded G (sourcesA G x y) S).card : ℤ) * G.degree y +
    ((excluded G (sourcesC G x y) S).card : ℤ) *
      ((G.degree y : ℤ) - G.degree x)

/-- Positivity alone forces a genuine target witness: at least two targets and
at least one excluded source. This uses actual graph partitions and the edge. -/
theorem positive_defect_witness_bounds (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S) :
    2 ≤ S.card ∧ (excluded G (G.neighborFinset x) S).Nonempty := by
  have ha := exclusive_common_partition G x y
  have hb := exclusive_common_partition G y x
  have hC : sourcesC G y x = sourcesC G x y := Finset.inter_comm _ _
  rw [hC] at hb
  change (targetsB G x y).card + (sourcesC G x y).card = G.degree y at hb
  unfold positiveDefect at hpositive
  have hne : S.Nonempty := by
    by_contra hn
    have hzero : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    subst S
    simp [excluded] at hpositive
    have haZ : ((sourcesA G x y).card : ℤ) + (sourcesC G x y).card = G.degree x := by omega
    have hbZ : ((targetsB G x y).card : ℤ) + (sourcesC G x y).card = G.degree y := by omega
    rw [← haZ, ← hbZ] at hpositive
    nlinarith
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hqc : (excluded G (sourcesC G x y) S).card ≤ (sourcesC G x y).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  have hcard : 2 ≤ S.card := by
    apply Classical.byContradiction
    intro hn
    have hpos : 0 < S.card := Finset.card_pos.mpr hne
    have hsone : S.card = 1 := by omega
    rw [hsone] at hpositive
    have h1 : 0 ≤ ((sourcesA G x y).card - 1 -
        ((excluded G (sourcesA G x y) S).card : ℤ)) * G.degree y :=
      mul_nonneg (by omega) (by omega)
    have h2 : 0 ≤ (((sourcesC G x y).card : ℤ) -
        (excluded G (sourcesC G x y) S).card) *
        ((G.degree y : ℤ) - G.degree x) := mul_nonneg (by omega) (by omega)
    have haZ : ((sourcesA G x y).card : ℤ) + (sourcesC G x y).card = G.degree x := by omega
    have hbZ : ((targetsB G x y).card : ℤ) + (sourcesC G x y).card = G.degree y := by omega
    norm_num at hpositive
    rw [← haZ] at hpositive h2
    rw [← hbZ] at hpositive h1 h2
    nlinarith
  refine ⟨hcard, ?_⟩
  apply Classical.byContradiction
  intro hn
  have hzero : (excluded G (G.neighborFinset x) S).card = 0 :=
    Finset.card_eq_zero.mpr (Finset.not_nonempty_iff_eq_empty.mp hn)
  have hsplit := excluded_partition G x y S
  have hp : (excluded G (sourcesA G x y) S).card = 0 := by omega
  have hq : (excluded G (sourcesC G x y) S).card = 0 := by omega
  rw [hp,hq] at hpositive
  norm_num at hpositive
  have hsb := Finset.card_le_card hS
  have hprod : 0 ≤ (((targetsB G x y).card : ℤ) - S.card) * G.degree x :=
    mul_nonneg (by omega) (by omega)
  nlinarith

/-- Sharp order bound with only graph inputs, a specified target set and its
positive Hall inequality. No separate counting hypotheses are assumed. -/
theorem graph_negative_slope_cutoff (k : ℕ) (hk : 2 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hx : x ∉ S)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card) (hpositive : positiveDefect G x y S) :
    Fintype.card V ≤ k*k+k+1 := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  exact graph_negative_slope_cutoff_of_witness_bounds G k hk hcode x y hxy S hS hx
    hs hU hnegative hpositive

theorem positive_defect_excludes_endpoint (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S) : x ∉ S := by
  obtain ⟨_, z, hz⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  obtain ⟨hzx,hzS⟩ := Finset.mem_filter.mp hz
  intro hx
  have hzadj : G.Adj x z := by simpa using hzx
  exact hzS x hx hzadj.symm

/-- The all-order scalar consequence, now applied directly to graph sets. -/
theorem graph_positive_defect_small_side (k : ℕ) (hk : 2 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S) :
    ((targetsB G x y).card : ℤ) < 2 * Curvature.SparseFilter.bk k ∨
      (G.degree x : ℤ) < 2 * ((k : ℤ) - 1) := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G k hcode x y S hS hx hU
  have hex := excluded_sources_count G k hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpair := two_excluded_exclusive_sources G k hcode x y S hS hne
  have hdiff := exclusive_target_difference G x y
  apply Curvature.SparseFilter.positive_hall_small_side (k : ℤ) (G.degree x : ℤ)
    ((targetsB G x y).card : ℤ) ((G.degree y : ℤ) - G.degree x)
    (S.card : ℤ) ((excluded G (sourcesA G x y) S).card : ℤ)
    ((excluded G (sourcesC G x y) S).card : ℤ)
  · omega
  · omega
  · omega
  · omega
  · omega
  · intro hp
    have hh := hpair (by omega)
    omega
  · omega
  · unfold Curvature.SparseFilter.hallNumerator
    unfold positiveDefect at hpositive
    nlinarith

/-- Above the sharp cutoff, every positive witness has nonnegative slope,
and therefore bounds the entire target set. -/
theorem graph_persistent_target_bound (k : ℕ) (hk : 2 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S)
    (hlarge : k*k+k+1 < Fintype.card V) :
    ((targetsB G x y).card : ℤ) ≤ Curvature.SparseFilter.bk k := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G k hcode x y S hS hx hU
  have hex := excluded_sources_count G k hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpair := two_excluded_exclusive_sources G k hcode x y S hS hne
  have hnonnegative : (targetsB G x y).card ≤
      S.card + (excluded G (sourcesA G x y) S).card := by
    by_contra hn
    have hh := graph_negative_slope_cutoff G k hk hcode x y hxy hdegree S hS hx
      (by omega) hpositive
    omega
  have hsum := Curvature.SparseFilter.sum_bound (k : ℤ) (S.card : ℤ)
    ((excluded G (sourcesA G x y) S).card : ℤ) (by omega) (by omega)
    (by intro hp; have hh := hpair (by omega); omega)
  omega

#print axioms neighborhood_partition
#print axioms excluded_partition
#print axioms positive_defect_witness_bounds
#print axioms graph_negative_slope_cutoff
#print axioms graph_positive_defect_small_side
#print axioms graph_persistent_target_bound
end CurvatureGraph
