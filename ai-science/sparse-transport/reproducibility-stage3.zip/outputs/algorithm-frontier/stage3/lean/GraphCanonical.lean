import CanonicalHall
import GraphWeightedHall
import GraphQuantitative

/-!
# Canonical weighted Hall sets from actual graph inputs

The exclusive-source relation is adjacency between the subtypes `A` and `B`.
The lower-order excluded count uses adjacency from all of `N(x)` to `B`.
The positive-competitor bound is derived from the complement-codegree condition,
not assumed.  This does not formalize computing the set by maximum matching,
the row-star transport identity, or curvature itself.
-/

namespace CurvatureGraph

open Finset

variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def canonicalRelation (U : Finset V) (x y : V)
    (j : ResidualTarget G x y) (i : ↥U) : Prop := G.Adj i.val j.val

theorem canonical_neighbor_image (U : Finset V) (x y : V)
    (K : Finset (ResidualTarget G x y)) :
    (CurvatureCanonicalHall.neighbors (canonicalRelation G U x y) K).image Subtype.val =
      U.filter (fun v => ∃ s ∈ targetVertices G x y K, G.Adj v s) := by
  classical
  ext v
  constructor
  · intro hv
    obtain ⟨i, hi, rfl⟩ := mem_image.mp hv
    obtain ⟨j, hj, hij⟩ := (CurvatureCanonicalHall.mem_neighbors _ _ _).mp hi
    exact mem_filter.mpr ⟨i.property, j.val, mem_image_of_mem _ hj, hij⟩
  · intro hv
    obtain ⟨hvU, s, hs, hvs⟩ := mem_filter.mp hv
    obtain ⟨j, hj, rfl⟩ := mem_image.mp hs
    apply mem_image.mpr
    refine ⟨⟨v, hvU⟩, ?_, rfl⟩
    exact (CurvatureCanonicalHall.mem_neighbors _ _ _).mpr ⟨j, hj, hvs⟩

theorem canonical_excluded_image (U : Finset V) (x y : V)
    (K : Finset (ResidualTarget G x y)) :
    (CurvatureCanonicalHall.excluded (canonicalRelation G U x y) K).image Subtype.val =
      excluded G U (targetVertices G x y K) := by
  classical
  ext v
  constructor
  · intro hv
    obtain ⟨i, hi, rfl⟩ := mem_image.mp hv
    have hi' : ∀ j ∈ K, ¬G.Adj i.val j.val := by
      simpa only [CurvatureCanonicalHall.excluded, mem_filter, mem_univ, true_and,
        canonicalRelation] using hi
    apply mem_filter.mpr
    refine ⟨i.property, ?_⟩
    intro s hs
    obtain ⟨j, hj, rfl⟩ := mem_image.mp hs
    exact hi' j hj
  · intro hv
    obtain ⟨hvU, hvS⟩ := mem_filter.mp hv
    apply mem_image.mpr
    refine ⟨⟨v, hvU⟩, ?_, rfl⟩
    simp only [CurvatureCanonicalHall.excluded, mem_filter, mem_univ, true_and,
      canonicalRelation]
    intro j hj
    exact hvS j.val (mem_image_of_mem _ hj)

theorem canonical_excluded_card (U : Finset V) (x y : V)
    (K : Finset (ResidualTarget G x y)) :
    (CurvatureCanonicalHall.excluded (canonicalRelation G U x y) K).card =
      (excluded G U (targetVertices G x y K)).card := by
  rw [← canonical_excluded_image]
  exact (card_image_of_injective _ Subtype.val_injective).symm

theorem canonical_neighbor_partition (U : Finset V) (x y : V)
    (K : Finset (ResidualTarget G x y)) :
    (CurvatureCanonicalHall.neighbors (canonicalRelation G U x y) K).card +
      (excluded G U (targetVertices G x y K)).card = U.card := by
  classical
  have hcard := congrArg Finset.card (canonical_neighbor_image G U x y K)
  rw [card_image_of_injective _ Subtype.val_injective] at hcard
  rw [hcard]
  have hex : excluded G U (targetVertices G x y K) =
      U.filter (fun v => ¬∃ s ∈ targetVertices G x y K, G.Adj v s) := by
    ext v
    simp [excluded]
  rw [hex]
  exact filter_card_add_filter_neg_card_eq_card _

theorem canonical_objective_eq_numerator (x y : V)
    (K : Finset (ResidualTarget G x y)) :
    (G.degree x : ℤ) * CurvatureCanonicalHall.slope
      (canonicalRelation G (sourcesA G x y) x y) ((G.degree y : ℤ) - G.degree x) K +
      ((G.degree y : ℤ) - G.degree x) *
        (CurvatureCanonicalHall.excluded
          (canonicalRelation G (G.neighborFinset x) x y) K).card =
      scaledHallNumerator G x y (targetVertices G x y K) := by
  have hn := canonical_neighbor_partition G (sourcesA G x y) x y K
  have hd := exclusive_target_difference G x y
  have he := excluded_partition G x y (targetVertices G x y K)
  have ht : (targetVertices G x y K).card = K.card :=
    card_image_of_injective _ Subtype.val_injective
  rw [canonical_excluded_card]
  unfold CurvatureCanonicalHall.slope scaledHallNumerator
  have hnZ : ((CurvatureCanonicalHall.neighbors
      (canonicalRelation G (sourcesA G x y) x y) K).card : ℤ) =
      (sourcesA G x y).card - (excluded G (sourcesA G x y)
        (targetVertices G x y K)).card := by omega
  have hdZ : ((sourcesA G x y).card : ℤ) =
      (targetsB G x y).card + G.degree x - G.degree y := by omega
  have heZ : ((excluded G (G.neighborFinset x) (targetVertices G x y K)).card : ℤ) =
      (excluded G (sourcesA G x y) (targetVertices G x y K)).card +
      (excluded G (sourcesC G x y) (targetVertices G x y K)).card := by omega
  rw [hnZ, hdZ, heZ, ht]
  ring

theorem positive_numerator_iff_positive_defect (x y : V) (S : Finset V) :
    0 < scaledHallNumerator G x y S ↔ positiveDefect G x y S := by
  unfold scaledHallNumerator positiveDefect
  constructor <;> intro h <;> nlinarith

/-- The required positive-competitor count bound follows from actual graph
codegrees, using the endpoint exclusion and the two-target witness lemma. -/
theorem canonical_positive_excluded_bound (k : ℕ) (hcode : CodegreeBound G k)
    (x y : V) (hxy : G.Adj x y) (hdegree : G.degree x ≤ G.degree y)
    (K : Finset (ResidualTarget G x y))
    (hpos : 0 < (G.degree x : ℤ) * CurvatureCanonicalHall.slope
      (canonicalRelation G (sourcesA G x y) x y) ((G.degree y : ℤ) - G.degree x) K +
      ((G.degree y : ℤ) - G.degree x) *
        (CurvatureCanonicalHall.excluded
          (canonicalRelation G (G.neighborFinset x) x y) K).card) :
    ((CurvatureCanonicalHall.excluded
      (canonicalRelation G (G.neighborFinset x) x y) K).card : ℤ) ≤ (k : ℤ) - 1 := by
  rw [canonical_objective_eq_numerator] at hpos
  have hpositive := (positive_numerator_iff_positive_defect G x y _).mp hpos
  have hS := target_vertices_subset G x y K
  have hs := (positive_defect_witness_bounds G x y hxy hdegree _ hS hpositive).1
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree _ hS hpositive
  have hcount := excluded_sources_count G k hcode x y _ hS hx hs
  rw [canonical_excluded_card]
  omega

/-- An actual graph under strict priority has a least slope-maximizing target
set which also maximizes its denominator-cleared Hall numerator. -/
theorem graph_canonical_weighted_max (k : ℕ) (hk : 1 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y)
    (hpriority : ((G.degree y : ℤ) - G.degree x) * ((k : ℤ) - 1) < G.degree x) :
    ∃ K₀ : Finset (ResidualTarget G x y),
      CurvatureCanonicalHall.IsSlopeMax (canonicalRelation G (sourcesA G x y) x y)
        ((G.degree y : ℤ) - G.degree x) K₀ ∧
      (∀ T, CurvatureCanonicalHall.IsSlopeMax
        (canonicalRelation G (sourcesA G x y) x y) ((G.degree y : ℤ) - G.degree x) T →
        K₀ ⊆ T) ∧
      ∀ S : Finset V, S ⊆ targetsB G x y →
        scaledHallNumerator G x y S ≤
          scaledHallNumerator G x y (targetVertices G x y K₀) := by
  have hbalance : (Fintype.card ↥(sourcesA G x y) : ℤ) +
      ((G.degree y : ℤ) - G.degree x) ≤ Fintype.card (ResidualTarget G x y) := by
    have hh := exclusive_target_difference G x y
    simp only [ResidualTarget, Fintype.card_coe]
    omega
  obtain ⟨K₀, hmax, hleast, hweighted⟩ :=
    CurvatureCanonicalHall.exists_canonical_excluded_weighted_max
      (canonicalRelation G (sourcesA G x y) x y)
      (canonicalRelation G (G.neighborFinset x) x y)
      (G.degree x : ℤ) ((G.degree y : ℤ) - G.degree x) ((k : ℤ) - 1)
      (by omega) (by omega) hpriority hbalance
      (canonical_positive_excluded_bound G k hcode x y hxy hdegree)
  refine ⟨K₀, hmax, hleast, ?_⟩
  intro S hS
  have hh := hweighted (S.subtype (fun v => v ∈ targetsB G x y))
  rw [canonical_objective_eq_numerator, canonical_objective_eq_numerator,
    target_vertices_subtype G x y S hS] at hh
  exact hh

#print axioms canonical_objective_eq_numerator
#print axioms canonical_positive_excluded_bound
#print axioms graph_canonical_weighted_max

end CurvatureGraph
