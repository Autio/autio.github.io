import Mathlib.Tactic

/-! Equality analysis for the sharp negative-slope Hall cutoff.

This is conditional integer arithmetic. Graph neighborhoods, weighted Hall,
curvature, and extremal graph constructions are not formalized in this file.
Here e=p+q, u=a-e, h=beta-s-p, and F=e*(s+p-alpha)-h*u.
-/

namespace CurvatureCutoffEquality

set_option maxHeartbeats 1000000

/-- Exact decomposition of the order-deficiency slack. -/
theorem order_deficiency_identity (k e s p r alpha u h : ℤ) :
    (k*k+k+2) - (u+h+e+s+p+r) - (e*(s+p-alpha)-h*u) =
    (k*k+k+1-((e+1)*s+p+r)) + e*(alpha-p-1) + (u-1)*(h-1) := by
  ring

/-- The transient Hall numerator is bounded by distance below the cutoff.
Strict positivity of the numerator is not needed for this inequality. -/
theorem order_deficiency_bound
    (k e s p r alpha u h : ℤ)
    (hk : 2 ≤ k) (hp : 0 ≤ p) (hpe : p ≤ e) (he : e ≤ k-1)
    (hs : 2 ≤ s) (hsk : s ≤ k) (hr : r ≤ k)
    (halpha : p+1 ≤ alpha) (hu : 1 ≤ u) (hh : 1 ≤ h)
    (hpair : 2 ≤ p → s+1 ≤ k) :
    e*(s+p-alpha)-h*u ≤ k*k+k+2-(u+h+e+s+p+r) := by
  have he0 : 0 ≤ e := by omega
  have h0 : 0 ≤ e*(alpha-p-1) := mul_nonneg he0 (by omega)
  have h1 : 0 ≤ (u-1)*(h-1) := mul_nonneg (by omega) (by omega)
  have h2 : 0 ≤ (k-e-1)*s := mul_nonneg (by omega) (by omega)
  have hcap : (e+1)*s+p+r ≤ k*k+k+1 := by
    by_cases hp1 : p ≤ 1
    · have h3 : 0 ≤ k*(k-s) := mul_nonneg (by omega) (by omega)
      nlinarith
    · have hp2 : 2 ≤ p := by omega
      have hpair' := hpair hp2
      have h3 : 0 ≤ k*(k-1-s) := mul_nonneg (by omega) (by omega)
      nlinarith
  nlinarith only [h0, h1, hcap]

/-- Two excluded exclusive sources improve the order-deficiency bound by two. -/
theorem order_deficiency_bound_two_exclusive
    (k e s p r alpha u h : ℤ)
    (hk : 2 ≤ k) (hp : 2 ≤ p) (hpe : p ≤ e) (he : e ≤ k-1)
    (hs : 2 ≤ s) (hsk : s+1 ≤ k) (hr : r ≤ k)
    (halpha : p+1 ≤ alpha) (hu : 1 ≤ u) (hh : 1 ≤ h) :
    e*(s+p-alpha)-h*u ≤ k*k+k-(u+h+e+s+p+r) := by
  have h0 : 0 ≤ e*(alpha-p-1) := mul_nonneg (by omega) (by omega)
  have h1 : 0 ≤ (u-1)*(h-1) := mul_nonneg (by omega) (by omega)
  have h2 : 0 ≤ (k-e-1)*s := mul_nonneg (by omega) (by omega)
  have h3 : 0 ≤ k*(k-1-s) := mul_nonneg (by omega) (by omega)
  have hcap : (e+1)*s+p+r ≤ k*k+k-1 := by nlinarith
  nlinarith only [h0, h1, hcap]

/-- Codegree two admits no negative-slope deficient numerical Hall witness. -/
theorem no_negative_slope_at_two
    (e s p alpha u h : ℤ)
    (he : 0 ≤ e) (he1 : e ≤ 1)
    (hs : s ≤ 2) (halpha : p + 1 ≤ alpha)
    (hu : 1 ≤ u) (hh : 1 ≤ h) :
    ¬ (0 < e * (s + p - alpha) - h * u) := by
  have h0 : 0 ≤ e * (alpha - p - 1) := mul_nonneg he (by omega)
  have h1 : 0 ≤ e * (2 - s) := mul_nonneg he (by omega)
  have h2 : 0 ≤ (u - 1) * (h - 1) := mul_nonneg (by omega) (by omega)
  intro hdef
  nlinarith

/-- At maximum possible order, all numerical cutoff inequalities are tight.
The two alternatives classify the values of u and h, not the graph itself. -/
theorem boundary_parameters
    (k e s p r alpha u h : ℤ)
    (hk : 3 ≤ k) (hp : 0 ≤ p) (hpe : p ≤ e) (he : e ≤ k - 1)
    (hs : 2 ≤ s) (hsk : s ≤ k) (hr : r ≤ k)
    (halpha : p + 1 ≤ alpha) (hu : 1 ≤ u) (hh : 1 ≤ h)
    (hpair : 2 ≤ p → s + 1 ≤ k)
    (hdef : 0 < e * (s + p - alpha) - h * u)
    (horder : u + h + e + s + p + r = k*k+k+1) :
    p = 1 ∧ e = k - 1 ∧ s = k ∧ r = k ∧ alpha = 2 ∧
    e * (s + p - alpha) - h * u = 1 ∧
    ((u = 1 ∧ h = k*(k-2)) ∨ (h = 1 ∧ u = k*(k-2))) := by
  have he0 : 0 ≤ e := by omega
  have h0 : 0 ≤ e * (alpha - p - 1) := mul_nonneg he0 (by omega)
  have hprod : h*u+1 ≤ e*(s-1) := by nlinarith
  have h1 : 0 ≤ (u-1)*(h-1) := mul_nonneg (by omega) (by omega)
  have hsum : u+h+e+s+p ≤ (e+1)*s+p := by nlinarith
  have h2 : 0 ≤ (k-e-1)*s := mul_nonneg (by omega) (by omega)
  have hp1 : p ≤ 1 := by
    by_contra hn
    have hpair' := hpair (by omega)
    have h3 : 0 ≤ k*(k-1-s) := mul_nonneg (by omega) (by omega)
    nlinarith
  have h3 : 0 ≤ k*(k-s) := mul_nonneg (by omega) (by omega)
  have hp_eq : p = 1 := by nlinarith
  have hr_eq : r = k := by nlinarith
  have hs_zero : k*(k-s) = 0 := by nlinarith
  have hs_eq : s = k := by
    rcases mul_eq_zero.mp hs_zero with hzero | hzero <;> omega
  have he_zero : (k-e-1)*s = 0 := by nlinarith
  have he_eq : e = k-1 := by
    rcases mul_eq_zero.mp he_zero with hzero | hzero <;> omega
  subst p
  subst r
  subst s
  subst e
  have hprod_eq : h*u = k*(k-2) := by nlinarith
  have halpha_zero : (alpha-2)*(k-1) = 0 := by nlinarith
  have halpha_eq : alpha = 2 := by
    rcases mul_eq_zero.mp halpha_zero with hzero | hzero <;> omega
  have hF : (k-1)*(k+1-alpha)-h*u = 1 := by
    rw [halpha_eq, hprod_eq]
    ring
  have huv_zero : (u-1)*(h-1) = 0 := by nlinarith
  refine ⟨rfl, rfl, rfl, rfl, halpha_eq, hF, ?_⟩
  rcases mul_eq_zero.mp huv_zero with hu1 | hh1
  · left
    have hu_eq : u = 1 := by omega
    exact ⟨hu_eq, by simpa [hu_eq] using hprod_eq⟩
  · right
    have hh_eq : h = 1 := by omega
    exact ⟨hh_eq, by simpa [hh_eq] using hprod_eq⟩

/-- The equality theorem stated in the original neighborhood-count variables.
The input deficiency is a denominator-cleared weighted Hall inequality. -/
theorem boundary_neighborhood_counts
    (k a alpha beta d p q s r : ℤ)
    (hk : 3 ≤ k) (hp : 0 ≤ p) (hq : 0 ≤ q)
    (hs : 2 ≤ s) (hsk : s ≤ k) (htotal : p+q ≤ k-1)
    (ha : alpha+q ≤ a) (halpha : p+1 ≤ alpha)
    (hd : d = beta-alpha) (hr : r ≤ k)
    (hpair : 2 ≤ p → s+1 ≤ k)
    (hnegative : s+p < beta)
    (hdef : beta*a < s*a+p*(a+d)+q*d)
    (hboundary : a+beta+r = k*k+k+1) :
    p = 1 ∧ q = k-2 ∧ s = k ∧ r = k ∧ alpha = 2 ∧
    (s+p-beta)*a+d*(p+q) = 1 ∧ a+d = k*k-1 ∧
    ((a = k ∧ beta = k*k-k+1) ∨
     (a = k*k-k-1 ∧ beta = k+2)) := by
  have hdef' : 0 < (p+q)*(s+p-alpha)-(beta-s-p)*(a-p-q) := by
    rw [hd] at hdef
    nlinarith
  have hc := boundary_parameters k (p+q) s p r alpha (a-p-q) (beta-s-p)
    hk hp (by omega) htotal hs hsk hr halpha (by omega) (by omega)
    hpair hdef' (by nlinarith)
  rcases hc with ⟨hp1, he1, hs1, hr1, halpha1, hF, hcases⟩
  have hq1 : q = k-2 := by omega
  have hF' : (s+p-beta)*a+d*(p+q) = 1 := by
    rw [hd]
    nlinarith only [hF]
  have hb : a+d = k*k-1 := by nlinarith only [hd, hboundary, hr1, halpha1]
  refine ⟨hp1, hq1, hs1, hr1, halpha1, hF', hb, ?_⟩
  rcases hcases with ⟨hu, hh⟩ | ⟨hh, hu⟩
  · left
    exact ⟨by omega, by nlinarith only [hh, hp1, hs1]⟩
  · right
    exact ⟨by nlinarith only [hu, hp1, hq1], by omega⟩

#print axioms no_negative_slope_at_two
#print axioms order_deficiency_identity
#print axioms order_deficiency_bound
#print axioms order_deficiency_bound_two_exclusive
#print axioms boundary_parameters
#print axioms boundary_neighborhood_counts

end CurvatureCutoffEquality
