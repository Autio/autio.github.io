import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Tactic

/-!
A finite-graph counting bridge for the cost-three star observation.
Two disjoint pairs whose open neighborhoods each cover the whole graph
force the order to be at most four times the maximum pair codegree.
The complement bridge uses nonadjacency and absence of a common neighbor,
not a metric distance API. No curvature or transport theorem is formalized.
-/

namespace Curvature.DistanceThreeStar

variable {V : Type*} [Fintype V] [DecidableEq V]

theorem four_intersections_bound (A B C D : Finset V) (k : ℕ)
    (hAB : A ∪ B = Finset.univ) (hCD : C ∪ D = Finset.univ)
    (hAC : (A ∩ C).card ≤ k) (hAD : (A ∩ D).card ≤ k)
    (hBC : (B ∩ C).card ≤ k) (hBD : (B ∩ D).card ≤ k) :
    Fintype.card V ≤ 4 * k := by
  have hcover : (Finset.univ : Finset V) ⊆
      ((A ∩ C) ∪ (A ∩ D)) ∪ ((B ∩ C) ∪ (B ∩ D)) := by
    intro z hz
    have hab : z ∈ A ∪ B := by rw [hAB]; exact hz
    have hcd : z ∈ C ∪ D := by rw [hCD]; exact hz
    simp only [Finset.mem_union, Finset.mem_inter] at *
    tauto
  have hcard := Finset.card_le_card hcover
  have htop := Finset.card_union_le ((A ∩ C) ∪ (A ∩ D))
    ((B ∩ C) ∪ (B ∩ D))
  have hleft := Finset.card_union_le (A ∩ C) (A ∩ D)
  have hright := Finset.card_union_le (B ∩ C) (B ∩ D)
  simp only [Finset.card_univ] at hcard
  omega

variable (H : SimpleGraph V) [DecidableRel H.Adj]

def CodegreeBound (k : ℕ) : Prop :=
  ∀ a b : V, a ≠ b →
    (H.neighborFinset a ∩ H.neighborFinset b).card ≤ k

/-- Only cross-pair distinctness is needed for the cardinality argument. -/
theorem two_disjoint_dominating_pairs (k : ℕ) (hcode : CodegreeBound H k)
    (u t v w : V)
    (huv : u ≠ v) (huw : u ≠ w) (htv : t ≠ v) (htw : t ≠ w)
    (hut : H.neighborFinset u ∪ H.neighborFinset t = Finset.univ)
    (hvw : H.neighborFinset v ∪ H.neighborFinset w = Finset.univ) :
    Fintype.card V ≤ 4 * k := by
  exact four_intersections_bound _ _ _ _ k hut hvw
    (hcode u v huv) (hcode u w huw) (hcode t v htv) (hcode t w htw)

/-- Above 4k, any two total dominating pairs share an endpoint. -/
theorem dominating_pairs_intersect (k : ℕ) (hcode : CodegreeBound H k)
    (hlarge : 4 * k < Fintype.card V) (u t v w : V)
    (hut : H.neighborFinset u ∪ H.neighborFinset t = Finset.univ)
    (hvw : H.neighborFinset v ∪ H.neighborFinset w = Finset.univ) :
    u = v ∨ u = w ∨ t = v ∨ t = w := by
  by_contra hn
  push_neg at hn
  have hbound := two_disjoint_dominating_pairs H k hcode u t v w
    hn.1 hn.2.1 hn.2.2.1 hn.2.2.2 hut hvw
  omega

variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Distinct nonadjacent vertices with no common G-neighbor form a
total dominating pair in the complement, including the two endpoints. -/
theorem far_pair_complement_cover (u t : V) (hne : u ≠ t)
    (hnadj : ¬G.Adj u t) (hncommon : ∀ z, ¬(G.Adj u z ∧ G.Adj t z)) :
    Gᶜ.neighborFinset u ∪ Gᶜ.neighborFinset t = Finset.univ := by
  apply Finset.eq_univ_of_forall
  intro z
  simp only [Finset.mem_union, SimpleGraph.mem_neighborFinset,
    SimpleGraph.compl_adj]
  by_cases huz : u = z
  · subst z
    exact Or.inr ⟨Ne.symm hne, fun h => hnadj h.symm⟩
  by_cases htz : t = z
  · subst z
    exact Or.inl ⟨hne, hnadj⟩
  have h := hncommon z
  tauto

theorem far_pairs_intersect (k : ℕ) (hcode : CodegreeBound Gᶜ k)
    (hlarge : 4 * k < Fintype.card V) (u t v w : V)
    (hut : u ≠ t) (hvw : v ≠ w)
    (hnut : ¬G.Adj u t) (hnvw : ¬G.Adj v w)
    (hcut : ∀ z, ¬(G.Adj u z ∧ G.Adj t z))
    (hcvw : ∀ z, ¬(G.Adj v z ∧ G.Adj w z)) :
    u = v ∨ u = w ∨ t = v ∨ t = w := by
  exact dominating_pairs_intersect Gᶜ k hcode hlarge u t v w
    (far_pair_complement_cover G u t hut hnut hcut)
    (far_pair_complement_cover G v w hvw hnvw hcvw)

/-- A nonempty bipartite relation with no two disjoint edges is a star.
This final combinatorial step does not use matching or metric APIs. -/
theorem bipartite_relation_star {L R : Type*} (E : L → R → Prop)
    (hne : ∃ a b, E a b)
    (hintersect : ∀ a b c d, E a b → E c d → a = c ∨ b = d) :
    (∃ a, ∀ c d, E c d → c = a) ∨
      (∃ b, ∀ c d, E c d → d = b) := by
  classical
  obtain ⟨a, b, hab⟩ := hne
  by_cases hrow : ∀ c d, E c d → c = a
  · exact Or.inl ⟨a, hrow⟩
  push_neg at hrow
  obtain ⟨c, d, hcd, hca⟩ := hrow
  have hbd : b = d := (hintersect a b c d hab hcd).resolve_left (Ne.symm hca)
  subst d
  right
  refine ⟨b, ?_⟩
  intro e f hef
  have hfirst := hintersect a b e f hab hef
  have hsecond := hintersect c b e f hcd hef
  rcases hfirst with hae | hbf
  · rcases hsecond with hce | hbf
    · exact False.elim (hca (hce.trans hae.symm))
    · exact hbf.symm
  · exact hbf.symm

#print axioms four_intersections_bound
#print axioms two_disjoint_dominating_pairs
#print axioms dominating_pairs_intersect
#print axioms far_pair_complement_cover
#print axioms far_pairs_intersect
#print axioms bipartite_relation_star

end Curvature.DistanceThreeStar
