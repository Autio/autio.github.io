import GraphCutoff
import CutoffEquality

/-! Boundary numerical classification from actual finite graph neighborhoods.
The target set and its positive scaled Hall inequality are explicit inputs.
No numerical Hall-count inequalities are assumed; GraphHall derives them.
This file does not formalize optimal transport or existence of a Hall witness.
-/

namespace CurvatureGraph

variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two boundary types for an actual graph-valued transient Hall witness.
All subtraction in the conclusion is over integers. -/
theorem graph_boundary_parameters (k : ℕ) (hk : 3 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card)
    (hboundary : Fintype.card V = k*k+k+1) :
    ((excluded G (sourcesA G x y) S).card : ℤ) = 1 ∧
    ((excluded G (sourcesC G x y) S).card : ℤ) = (k : ℤ)-2 ∧
    (S.card : ℤ) = k ∧ ((remainder G x y).card : ℤ) = k ∧
    ((sourcesA G x y).card : ℤ) = 2 ∧
    ((S.card : ℤ) + (excluded G (sourcesA G x y) S).card -
      (targetsB G x y).card) * G.degree x +
      ((G.degree y : ℤ) - G.degree x) *
        ((excluded G (sourcesA G x y) S).card +
          (excluded G (sourcesC G x y) S).card) = 1 ∧
    (G.degree y : ℤ) = (k : ℤ)*k-1 ∧
    (((G.degree x : ℤ) = k ∧
        ((targetsB G x y).card : ℤ) = (k : ℤ)*k-k+1) ∨
     ((G.degree x : ℤ) = (k : ℤ)*k-k-1 ∧
        ((targetsB G x y).card : ℤ) = (k : ℤ)+2)) := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G k hcode x y S hS hx hU
  have hex := excluded_sources_count G k hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hqc : (excluded G (sourcesC G x y) S).card ≤ (sourcesC G x y).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  have hpart := exclusive_common_partition G x y
  have hdiff := exclusive_target_difference G x y
  have horder := neighborhood_partition G x y hxy
  have hr : (remainder G x y).card ≤ k := hcode x y hxy.ne
  have hpair := two_excluded_exclusive_sources G k hcode x y S hS hne
  have hc := CurvatureCutoffEquality.boundary_neighborhood_counts
    (k : ℤ) (G.degree x : ℤ) ((sourcesA G x y).card : ℤ)
    ((targetsB G x y).card : ℤ) ((G.degree y : ℤ)-G.degree x)
    ((excluded G (sourcesA G x y) S).card : ℤ)
    ((excluded G (sourcesC G x y) S).card : ℤ) (S.card : ℤ)
    ((remainder G x y).card : ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by intro hp; have hh := hpair (by omega); omega)
    (by omega) (by unfold positiveDefect at hpositive; convert hpositive using 1; ring)
    (by exact_mod_cast (show G.degree x + (targetsB G x y).card +
        (remainder G x y).card = k*k+k+1 by omega))
  simpa using hc

/-- An excluded source and x saturate their complement-codegree on S. -/
theorem saturated_excluded_targets (k : ℕ) (hcode : CodegreeBound G k)
    (x y z : V) (S : Finset V) (hS : S ⊆ targetsB G x y)
    (hx : x ∉ S) (hs : S.card = k)
    (hz : z ∈ excluded G (G.neighborFinset x) S) :
    S = Gᶜ.neighborFinset x ∩ Gᶜ.neighborFinset z := by
  obtain ⟨hzx,hzS⟩ := Finset.mem_filter.mp hz
  have hxz : x ≠ z := by intro he; subst z; simp at hzx
  have hi : S ⊆ Gᶜ.neighborFinset x ∩ Gᶜ.neighborFinset z := by
    intro s hsS
    simp only [Finset.mem_inter, SimpleGraph.mem_neighborFinset]
    exact ⟨(SimpleGraph.compl_adj G x s).2
      ⟨(fun he => hx (he ▸ hsS)), (target_in_ny_not_nx G hS hsS).2⟩,
      source_target_compl G hS hzx hsS (hzS s hsS)⟩
  exact Finset.eq_of_subset_of_card_le hi (by rw [hs]; exact hcode x z hxz)

/-- Saturation forces the excluded source to see every remainder vertex in G. -/
theorem saturated_source_adj_remainder (k : ℕ) (hcode : CodegreeBound G k)
    (x y z : V) (S : Finset V) (hS : S ⊆ targetsB G x y)
    (hx : x ∉ S) (hs : S.card = k)
    (hz : z ∈ excluded G (G.neighborFinset x) S)
    (v : V) (hv : v ∈ remainder G x y) : G.Adj z v := by
  have heq := saturated_excluded_targets G k hcode x y z S hS hx hs hz
  obtain ⟨hvx,hvy⟩ := Finset.mem_inter.mp hv
  have hvx' : Gᶜ.Adj x v := by simpa using hvx
  have hvy' : Gᶜ.Adj y v := by simpa using hvy
  have hzx : G.Adj x z := by simpa using (Finset.mem_filter.mp hz).1
  by_contra hn
  have hzv : z ≠ v := by
    intro he; subst v
    exact ((SimpleGraph.compl_adj G x z).1 hvx').2 hzx
  have hcomp : Gᶜ.Adj z v := (SimpleGraph.compl_adj G z v).2 ⟨hzv,hn⟩
  have hvS : v ∈ S := by
    rw [heq]
    simpa using (show Gᶜ.Adj x v ∧ Gᶜ.Adj z v from ⟨hvx',hcomp⟩)
  exact ((SimpleGraph.compl_adj G y v).1 hvy').2 (target_in_ny_not_nx G hS hvS).1

/-- At saturated target and remainder sizes, every missing transfer from an
excluded exclusive source has an actual two-edge path through the remainder. -/
theorem saturated_source_two_step (k : ℕ) (hcode : CodegreeBound G k)
    (x y z : V) (S : Finset V) (hS : S ⊆ targetsB G x y)
    (hx : x ∉ S) (hs : S.card = k) (hr : (remainder G x y).card = k)
    (hz : z ∈ excluded G (sourcesA G x y) S)
    (s : V) (hsS : s ∈ S) :
    ∃ v ∈ remainder G x y, G.Adj z v ∧ G.Adj v s := by
  obtain ⟨hzA,hzS⟩ := Finset.mem_filter.mp hz
  obtain ⟨hzx,hzy⟩ := Finset.mem_sdiff.mp hzA
  have hzex : z ∈ excluded G (G.neighborFinset x) S :=
    Finset.mem_filter.mpr ⟨hzx,hzS⟩
  have hzR : z ∉ remainder G x y := by
    intro hzR
    have hc : Gᶜ.Adj x z := by simpa using (Finset.mem_inter.mp hzR).1
    exact ((SimpleGraph.compl_adj G x z).1 hc).2 (by simpa using hzx)
  have hzy_ne : z ≠ y := by
    intro he; subst z
    exact hzS s hsS (target_in_ny_not_nx G hS hsS).1
  have hzy_comp : Gᶜ.Adj z y := (SimpleGraph.compl_adj G z y).2
    ⟨hzy_ne, by simpa [G.adj_comm] using hzy⟩
  have hzs_comp : Gᶜ.Adj z s := source_target_compl G hS hzx hsS (hzS s hsS)
  have hys : y ≠ s := (target_in_ny_not_nx G hS hsS).1.ne
  by_contra hn
  have hno : ∀ v ∈ remainder G x y, ¬G.Adj v s := by
    intro v hv hvs
    exact hn ⟨v,hv,saturated_source_adj_remainder G k hcode x y z S hS hx hs hzex v hv,hvs⟩
  have hi : insert z (remainder G x y) ⊆
      Gᶜ.neighborFinset y ∩ Gᶜ.neighborFinset s := by
    intro v hv
    simp only [Finset.mem_inter, SimpleGraph.mem_neighborFinset]
    rcases Finset.mem_insert.mp hv with he | hv
    · subst v
      exact ⟨hzy_comp.symm,hzs_comp.symm⟩
    · have hcy : Gᶜ.Adj y v := by simpa using (Finset.mem_inter.mp hv).2
      have hvs : v ≠ s := by
        intro he; subst v
        exact ((SimpleGraph.compl_adj G y s).1 hcy).2 (target_in_ny_not_nx G hS hsS).1
      exact ⟨hcy, ((SimpleGraph.compl_adj G v s).2 ⟨hvs,hno v hv⟩).symm⟩
  have hc := le_trans (Finset.card_le_card hi) (hcode y s hys)
  rw [Finset.card_insert_of_not_mem hzR,hr] at hc
  omega

/-- An actual boundary Hall witness has an excluded exclusive source whose
missing witness transfers all have two-edge paths through the remainder. -/
theorem graph_boundary_two_step (k : ℕ) (hk : 3 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card)
    (hboundary : Fintype.card V = k*k+k+1) :
    ∃ z ∈ excluded G (sourcesA G x y) S,
      ∀ s ∈ S, ∃ v ∈ remainder G x y, G.Adj z v ∧ G.Adj v s := by
  obtain ⟨hp,_,hs,hr,_⟩ := graph_boundary_parameters G k hk hcode x y hxy
    hdegree S hS hpositive hnegative hboundary
  have hne : (excluded G (sourcesA G x y) S).Nonempty :=
    Finset.card_pos.mp (by omega)
  obtain ⟨z,hz⟩ := hne
  refine ⟨z,hz,?_⟩
  intro s hsS
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  exact saturated_source_two_step G k hcode x y z S hS hx (by omega) (by omega)
    hz s hsS

#print axioms graph_boundary_parameters
#print axioms saturated_excluded_targets
#print axioms saturated_source_adj_remainder
#print axioms saturated_source_two_step
#print axioms graph_boundary_two_step

end CurvatureGraph
