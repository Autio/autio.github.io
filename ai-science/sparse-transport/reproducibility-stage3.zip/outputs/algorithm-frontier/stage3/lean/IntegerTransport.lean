import WeightedHall
import GraphWeightedHall

/-! Cost-one optimality for balanced integer residual mass.
The transport representation is a bijection of unit clones, not real matrices.
Metric common-mass cancellation and rational/real integrality are not asserted.
-/
namespace CurvatureWeightedHall
open Finset Function
variable {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

theorem clone_cost_lower_bound (v : J → ℕ) (u : I → ℕ) (cost : J → I → ℕ)
    (hpos : ∀ j i, 1 ≤ cost j i)
    (f : (Σ j, Fin (v j)) → (Σ i, Fin (u i))) :
    (∑ j, v j) ≤ ∑ t, cost t.1 (f t).1 := by
  have hcard : (∑ _t : Σ j, Fin (v j), 1) = ∑ j, v j := by
    simp
  rw [← hcard]
  exact Finset.sum_le_sum (fun t _ => hpos t.1 (f t).1)

theorem clone_cost_eq_mass_iff (v : J → ℕ) (u : I → ℕ) (cost : J → I → ℕ)
    (hpos : ∀ j i, 1 ≤ cost j i)
    (f : (Σ j, Fin (v j)) → (Σ i, Fin (u i))) :
    (∑ t, cost t.1 (f t).1) = (∑ j, v j) ↔
      ∀ t, cost t.1 (f t).1 = 1 := by
  have hcard : (∑ _t : Σ j, Fin (v j), 1) = ∑ j, v j := by simp
  have hsum := Finset.sum_eq_sum_iff_of_le
    (fun (t : Σ j, Fin (v j)) (_ : t ∈ Finset.univ) => hpos t.1 (f t).1)
  constructor
  · intro hh t
    have heq : (∑ _t : Σ j, Fin (v j), 1) = ∑ t, cost t.1 (f t).1 :=
      hcard.trans hh.symm
    exact (hsum.mp heq t (Finset.mem_univ _)).symm
  · intro hh
    calc
      (∑ t, cost t.1 (f t).1) = (∑ _t : Σ j, Fin (v j), 1) :=
        Finset.sum_congr rfl (fun t _ => hh t)
      _ = ∑ j, v j := hcard

/-- Weighted Hall exactly characterizes attaining the universal unit-cost
lower bound in integral clone transport. The background Hall theorem is prior art. -/
theorem weighted_hall_iff_unit_cost_optimum (u : I → ℕ) (v : J → ℕ)
    (cost : J → I → ℕ) (hpos : ∀ j i, 1 ≤ cost j i)
    (hbalance : ∑ j, v j = ∑ i, u i) :
    (∀ S : Finset J, (∑ j ∈ S, v j) ≤
      ∑ i ∈ neighbors (fun j i => cost j i = 1) S, u i) ↔
      ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
        Bijective f ∧ (∑ t, cost t.1 (f t).1) = ∑ j, v j := by
  constructor
  · intro hHall
    obtain ⟨f,hf,hr⟩ :=
      (balanced_weighted_hall_iff_clone_bijection u v (fun j i => cost j i = 1)
        hbalance).mp hHall
    exact ⟨f,hf,(clone_cost_eq_mass_iff v u cost hpos f).mpr hr⟩
  · rintro ⟨f,hf,hcost⟩
    exact (balanced_weighted_hall_iff_clone_bijection u v
      (fun j i => cost j i = 1) hbalance).mpr
        ⟨f,hf,(clone_cost_eq_mass_iff v u cost hpos f).mp hcost⟩

#print axioms clone_cost_eq_mass_iff
#print axioms weighted_hall_iff_unit_cost_optimum
end CurvatureWeightedHall

namespace CurvatureGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Actual graph residual counts characterize the unit lower bound for any
positive integer pair cost whose cost-one pairs are exactly graph edges. -/
theorem graph_no_defect_iff_integer_cost_baseline (x y : V)
    (hdegree : G.degree x ≤ G.degree y)
    (cost : ResidualTarget G x y → ResidualSource G x → ℕ)
    (hpos : ∀ j i, 1 ≤ cost j i)
    (hunit : ∀ j i, cost j i = 1 ↔ G.Adj i.val j.val) :
    (∀ S : Finset V, S ⊆ targetsB G x y → ¬positiveDefect G x y S) ↔
      ∃ f : (Σ j : ResidualTarget G x y, Fin (residualTargetDemand G x y j)) →
          (Σ i : ResidualSource G x, Fin (residualSourceSupply G x y i)),
        Function.Bijective f ∧ (∑ t, cost t.1 (f t).1) =
          ∑ j, residualTargetDemand G x y j := by
  have hclone := graph_no_positive_defect_iff_clone_bijection G x y hdegree
  constructor
  · intro hh
    obtain ⟨f,hf,hr⟩ := hclone.mp hh
    refine ⟨f,hf,?_⟩
    apply (CurvatureWeightedHall.clone_cost_eq_mass_iff _ _ cost hpos f).mpr
    intro t
    exact (hunit t.1 (f t).1).mpr (hr t)
  · rintro ⟨f,hf,hcost⟩
    apply hclone.mpr
    refine ⟨f,hf,?_⟩
    have hr := (CurvatureWeightedHall.clone_cost_eq_mass_iff _ _ cost hpos f).mp hcost
    intro t
    exact (hunit t.1 (f t).1).mp (hr t)

#print axioms graph_no_defect_iff_integer_cost_baseline
end CurvatureGraph
