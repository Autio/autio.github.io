import Mathlib.Combinatorics.Hall.Finite
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic

/-! Classical integer weighted Hall by cloning, using Mathlib's Hall theorem.
This file contributes formal coverage, not a new marriage theorem or algorithm.
An allowed clone matching is an integral transport assignment of unit masses.
-/
namespace CurvatureWeightedHall
open Finset Function

variable {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

theorem finite_relation_hall {A B : Type*} [Fintype A] [Fintype B]
    [DecidableEq A] [DecidableEq B] (r : A → B → Prop) [DecidableRel r] :
    (∀ K : Finset A, K.card ≤ (Finset.univ.filter (fun b => ∃ a ∈ K, r a b)).card) ↔
      ∃ f : A → B, Injective f ∧ ∀ a, r a (f a) := by
  classical
  have heq (K : Finset A) :
      K.biUnion (fun a => Finset.univ.filter (r a)) =
        Finset.univ.filter (fun b => ∃ a ∈ K, r a b) := by
    ext b
    simp
  simpa only [heq, Finset.mem_filter, Finset.mem_univ, true_and] using
    (Finset.all_card_le_biUnion_card_iff_existsInjective'
      (fun a => Finset.univ.filter (r a)))

def clones (w : I → ℕ) (S : Finset I) : Finset (Σ i, Fin (w i)) :=
  S.sigma (fun _ => Finset.univ)

noncomputable def neighbors (r : J → I → Prop) (S : Finset J) : Finset I := by
  classical
  exact Finset.univ.filter (fun i => ∃ j ∈ S, r j i)

@[simp] theorem card_clones (w : I → ℕ) (S : Finset I) :
    (clones w S).card = ∑ i ∈ S, w i := by
  simp [clones, Finset.card_sigma]

theorem clone_hall_of_weighted_hall (u : I → ℕ) (v : J → ℕ)
    (r : J → I → Prop)
    (hHall : ∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i) :
    ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
      Injective f ∧ ∀ t, r t.1 (f t).1 := by
  classical
  apply (finite_relation_hall
    (fun (t : Σ j, Fin (v j)) (s : Σ i, Fin (u i)) => r t.1 s.1)).mp
  intro K
  let S : Finset J := K.image Sigma.fst
  have hsub : K ⊆ clones v S := by
    intro t ht
    exact Finset.mem_sigma.mpr ⟨Finset.mem_image_of_mem _ ht, Finset.mem_univ _⟩
  have heq : (Finset.univ.filter (fun s : Σ i, Fin (u i) =>
        ∃ t ∈ K, r t.1 s.1)) = clones u (neighbors r S) := by
    ext s
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, clones,
      Finset.mem_sigma, and_true, neighbors]
    constructor
    · rintro ⟨t,ht,hr⟩
      exact ⟨t.1,Finset.mem_image_of_mem _ ht,hr⟩
    · intro hh
      obtain ⟨j,hj,hr⟩ := hh
      obtain ⟨t,ht,he⟩ := Finset.mem_image.mp hj
      exact ⟨t,ht,by simpa only [he] using hr⟩
  calc
    K.card ≤ (clones v S).card := Finset.card_le_card hsub
    _ = ∑ j ∈ S, v j := card_clones _ _
    _ ≤ ∑ i ∈ neighbors r S, u i := hHall S
    _ = (Finset.univ.filter (fun s : Σ i, Fin (u i) =>
        ∃ t ∈ K, r t.1 s.1)).card := by rw [heq,card_clones]

theorem weighted_hall_of_clone_matching (u : I → ℕ) (v : J → ℕ)
    (r : J → I → Prop)
    (f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)))
    (hf : Injective f) (hr : ∀ t, r t.1 (f t).1) :
    ∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i := by
  classical
  intro S
  have hsub : (clones v S).image f ⊆ clones u (neighbors r S) := by
    intro s hs
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hs
    have htS := (Finset.mem_sigma.mp ht).1
    apply Finset.mem_sigma.mpr
    refine ⟨?_, Finset.mem_univ _⟩
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,t.1,htS,hr t⟩
  have hc := Finset.card_le_card hsub
  simpa only [Finset.card_image_of_injective _ hf, card_clones] using hc

theorem weighted_hall_iff_clone_matching (u : I → ℕ) (v : J → ℕ)
    (r : J → I → Prop) :
    (∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i) ↔
      ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
        Injective f ∧ ∀ t, r t.1 (f t).1 := by
  constructor
  · exact clone_hall_of_weighted_hall u v r
  · rintro ⟨f,hf,hr⟩
    exact weighted_hall_of_clone_matching u v r f hf hr

theorem balanced_weighted_hall_iff_clone_bijection (u : I → ℕ) (v : J → ℕ)
    (r : J → I → Prop) (hbalance : ∑ j, v j = ∑ i, u i) :
    (∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i) ↔
      ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
        Bijective f ∧ ∀ t, r t.1 (f t).1 := by
  classical
  constructor
  · intro hHall
    obtain ⟨f,hf,hr⟩ := clone_hall_of_weighted_hall u v r hHall
    have hc : Fintype.card (Σ j, Fin (v j)) = Fintype.card (Σ i, Fin (u i)) := by
      simpa only [Fintype.card_sigma, Fintype.card_fin] using hbalance
    have he : (Σ j, Fin (v j)) ≃ (Σ i, Fin (u i)) := Fintype.equivOfCardEq hc
    exact ⟨f,⟨hf,(Finite.injective_iff_surjective_of_equiv he).mp hf⟩,hr⟩
  · rintro ⟨f,hf,hr⟩
    exact weighted_hall_of_clone_matching u v r f hf.1 hr

#print axioms weighted_hall_iff_clone_matching
#print axioms balanced_weighted_hall_iff_clone_bijection
end CurvatureWeightedHall
