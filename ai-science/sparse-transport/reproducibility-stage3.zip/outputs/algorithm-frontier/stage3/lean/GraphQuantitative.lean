import GraphBoundary

/-! Quantitative Hall-cutoff inequality from actual graph neighborhood sets.
This bridges the conditional slack arithmetic to graph inputs. It does not
formalize extremal realization, metric cancellation or curvature itself. -/
namespace CurvatureGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def scaledHallNumerator (x y : V) (S : Finset V) : ℤ :=
  ((S.card : ℤ) + (excluded G (sourcesA G x y) S).card -
    (targetsB G x y).card) * G.degree x +
  ((G.degree y : ℤ) - G.degree x) *
    ((excluded G (sourcesA G x y) S).card +
      (excluded G (sourcesC G x y) S).card)

theorem graph_transient_numerator_bound (k : ℕ) (hk : 2 ≤ k)
    (hcode : CodegreeBound G k) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card) :
    scaledHallNumerator G x y S ≤ (k : ℤ)*k+k+2-(Fintype.card V : ℤ) := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G k hcode x y S hS hx hU
  have hex := excluded_sources_count G k hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hqc : (excluded G (sourcesC G x y) S).card ≤ (sourcesC G x y).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  have hpart := exclusive_common_partition G x y
  have hdiff := exclusive_target_difference G x y
  have horder := neighborhood_partition G x y hxy
  have hr : (remainder G x y).card ≤ k := hcode x y hxy.ne
  have hpair := two_excluded_exclusive_sources G k hcode x y S hS hne
  have hc := CurvatureCutoffEquality.order_deficiency_bound
    (k : ℤ)
    (((excluded G (sourcesA G x y) S).card : ℤ) +
      (excluded G (sourcesC G x y) S).card)
    (S.card : ℤ) ((excluded G (sourcesA G x y) S).card : ℤ)
    ((remainder G x y).card : ℤ) ((sourcesA G x y).card : ℤ)
    ((G.degree x : ℤ) - (excluded G (sourcesA G x y) S).card -
      (excluded G (sourcesC G x y) S).card)
    (((targetsB G x y).card : ℤ) - S.card - (excluded G (sourcesA G x y) S).card)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega)
    (by intro hp; have hh := hpair (by omega); omega)
  have hd : (G.degree y : ℤ) - G.degree x =
      ((targetsB G x y).card : ℤ) - (sourcesA G x y).card := by omega
  have hn : (Fintype.card V : ℤ) = (G.degree x : ℤ) +
      (targetsB G x y).card + (remainder G x y).card := by omega
  unfold scaledHallNumerator
  rw [hd,hn]
  convert hc using 1 <;> ring

#print axioms graph_transient_numerator_bound

theorem positive_defect_iff_positive_numerator (x y : V) (S : Finset V) :
    positiveDefect G x y S ↔ 0 < scaledHallNumerator G x y S := by
  unfold positiveDefect scaledHallNumerator
  constructor <;> intro h <;> nlinarith

/-- The codegree-two exception is a graph theorem, not just a numerical test. -/
theorem graph_no_transient_defect_at_two
    (hcode : CodegreeBound G 2) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y)
    (hnegative : S.card + (excluded G (sourcesA G x y) S).card <
      (targetsB G x y).card) : ¬positiveDefect G x y S := by
  intro hpositive
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G 2 hcode x y S hS hx hU
  have hex := excluded_sources_count G 2 hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hqc : (excluded G (sourcesC G x y) S).card ≤ (sourcesC G x y).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  have hpart := exclusive_common_partition G x y
  have hdiff := exclusive_target_difference G x y
  have hd : (G.degree y : ℤ) - G.degree x =
      ((targetsB G x y).card : ℤ) - (sourcesA G x y).card := by omega
  have hc := CurvatureCutoffEquality.no_negative_slope_at_two
    (((excluded G (sourcesA G x y) S).card : ℤ) +
      (excluded G (sourcesC G x y) S).card)
    (S.card : ℤ) ((excluded G (sourcesA G x y) S).card : ℤ)
    ((sourcesA G x y).card : ℤ)
    ((G.degree x : ℤ) - (excluded G (sourcesA G x y) S).card -
      (excluded G (sourcesC G x y) S).card)
    (((targetsB G x y).card : ℤ) - S.card - (excluded G (sourcesA G x y) S).card)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
  apply hc
  have hp := (positive_defect_iff_positive_numerator G x y S).mp hpositive
  unfold scaledHallNumerator at hp
  rw [hd] at hp
  convert hp using 1 <;> ring

#print axioms positive_defect_iff_positive_numerator
#print axioms graph_no_transient_defect_at_two

/-- Every positive Hall witness at codegree two has the same numerical type,
at every graph order. The corresponding curvature evaluation is separate. -/
theorem graph_codegree_two_positive_witness
    (hcode : CodegreeBound G 2) (x y : V) (hxy : G.Adj x y)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V)
    (hS : S ⊆ targetsB G x y) (hpositive : positiveDefect G x y S) :
    S.card = 2 ∧ (excluded G (sourcesA G x y) S).card = 1 ∧
      (excluded G (sourcesC G x y) S).card = 0 ∧
      (sourcesA G x y).card = 2 ∧ (targetsB G x y).card = 3 ∧
      (G.degree y : ℤ) - G.degree x = 1 ∧ scaledHallNumerator G x y S = 1 := by
  obtain ⟨hs,hU⟩ := positive_defect_witness_bounds G x y hxy hdegree S hS hpositive
  have hx := positive_defect_excludes_endpoint G x y hxy hdegree S hS hpositive
  have hsk := excluded_set_card G 2 hcode x y S hS hx hU
  have hex := excluded_sources_count G 2 hcode x y S hS hx hs
  have hsplit := excluded_partition G x y S
  have hne : S.Nonempty := Finset.card_pos.mp (by omega)
  have hpa := excluded_exclusive_card G x y hxy S hS hne
  have hsb := target_subset_card G x y hxy S hS hx
  have hdiff := exclusive_target_difference G x y
  have hnonneg : (targetsB G x y).card ≤
      S.card + (excluded G (sourcesA G x y) S).card := by
    by_contra hn
    exact (graph_no_transient_defect_at_two G hcode x y hxy hdegree S hS (by omega)) hpositive
  have hs2 : S.card = 2 := by omega
  have hp1 : (excluded G (sourcesA G x y) S).card = 1 := by omega
  have hq0 : (excluded G (sourcesC G x y) S).card = 0 := by omega
  have hb3 : (targetsB G x y).card = 3 := by omega
  have hnum := (positive_defect_iff_positive_numerator G x y S).mp hpositive
  unfold scaledHallNumerator at hnum
  rw [hs2,hp1,hq0,hb3] at hnum
  norm_num at hnum
  have halpha : (sourcesA G x y).card = 2 := by omega
  have hd : (G.degree y : ℤ) - G.degree x = 1 := by omega
  refine ⟨hs2,hp1,hq0,halpha,hb3,hd,?_⟩
  unfold scaledHallNumerator
  rw [hs2,hp1,hq0,hb3,hd]
  norm_num

#print axioms graph_codegree_two_positive_witness
end CurvatureGraph
