# Partial Lean formalization

Checked with Lean 4.19.0 and Mathlib v4.19.0 on 21 October 2026.
The compiler log records successful kernel checking of ten modules. The printed
axiom dependencies are `propext`, `Classical.choice` and `Quot.sound` only.
Unused-variable linter warnings do not affect proof acceptance. There is no
`sorry`, `admit` or `native_decide` in these proof sources.

The first three modules preserve the previous-stage sources. `GraphCutoff`
connects actual finite graph neighborhood sets to Hall-witness counting and
the cutoff/scalar consequences. `CutoffEquality` checks conditional arithmetic;
`GraphBoundary` checks graph-level boundary counts, saturation and two-step
paths. `WeightedHall` proves classical weighted Hall via unit clones using
Mathlib's finite Hall theorem. `GraphWeightedHall` specializes this to the
residual supplies and targets of an actual graph. `IntegerTransport` connects
these inequalities to a unit-clone transport bijection attaining its unit-cost
lower bound. `DistanceThreeStar` proves the four-codegree covering bound and
the bipartite-star consequence.

This is **not an end-to-end formal proof of the paper**. Metric common-mass
cancellation, the real/rational-to-integer transport bridge, full extremal
realizations and repair, nested transport duality, canonical matching algorithm
and asymptotic runtime remain outside the formal coverage.

## Recheck

A portable Lake project is supplied. With elan installed, from this directory:

```text
lake update
lake exe cache get
lake build
```

The pinned project files are supplied for reproducibility; a fresh network
dependency install was not tested in this run. The actual recorded checks used
the existing workspace Mathlib cache and direct `lean -o` invocations, in the
module order shown in `HallLocalization.lean`. The workspace-specific
`check.ps1` reproduces that route when the documented workspace layout exists.
It adds the official Mathlib Hall/Finite object if it is absent from the cache.
No compiled objects, executables or dependency caches are included here.
