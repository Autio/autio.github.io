# Partial Lean formalization

Checked with Lean 4.19.0 and Mathlib v4.19.0 on 21 October 2026.
The compiler log records successful kernel checking of fifteen substantive modules. The printed
axiom dependencies are `propext`, `Classical.choice` and `Quot.sound` only.
Unused-variable linter warnings do not affect proof acceptance. There is no
`sorry`, `admit` or `native_decide` in these proof sources.

The first three modules preserve the previous-stage sources. `GraphCutoff`
connects actual finite graph neighborhood sets to Hall-witness counting and
the cutoff/scalar consequences. `CutoffEquality` checks conditional arithmetic;
`GraphBoundary` checks graph-level boundary counts, saturation and two-step
paths. `WeightedHall` proves classical weighted Hall via unit clones using
Mathlib's finite Hall theorem. `GraphWeightedHall` specializes this to the
residual supplies and targets of an actual graph. `IntegerTransport` connects
these inequalities to a unit-clone transport bijection attaining its unit-cost
lower bound. `DistanceThreeStar` proves the four-codegree covering bound and
the bipartite-star consequence.

`CanonicalHall` proves supermodularity and the unique least maximum-slope set
on actual finite relations, plus weighted priority under the stated antitone
excluded-count bound for positive competitors. Graph-subtype instantiation,
derivation of that codegree bound in this module, and correctness of the
alternating-path implementation are not checked by this file.

`RealTransportHall` builds actual nonnegative real matrices from clone
bijections and proves the converse weighted Hall necessity. It checks the real
unit-cost lower bound, equality support, and the graph-specific equivalence
between no positive residual Hall defect and a real residual transport matrix
attaining the unit baseline, for supplied costs at least one whose unit pairs
are exactly graph edges. This closes the real/integer *unit-baseline feasibility*
bridge; it is not arbitrary-cost minimum-transport integrality.

`GraphQuantitative` derives the quantitative numerator bound from actual graph
sets, not assumed numerical witness counts. It also proves the graph-level
codegree-two exception and the unique numerical type of every positive
codegree-two witness at any order. The complete pendant/nonpendant transport
formula remains handwritten. `GraphCanonical` instantiates the finite relations with
actual graph exclusive-source/target and full-source subtypes, derives the
positive excluded-count bound from codegree, and obtains the canonical weighted
maximizer under the stated degree orientation and dominance hypothesis.
`CostStarCriterion` checks the restricted finite-set maximum and the scalar
correction under an explicit margin; the graph-derived row margin and transport
duality are outside that module.

This is **not an end-to-end formal proof of the paper**. Metric common-mass
cancellation, general higher-cost transport integrality, full extremal
realizations and repair, nested transport duality, canonical matching algorithm
and asymptotic runtime remain outside the formal coverage.

## Recheck

A portable Lake project is supplied. With elan installed, from this directory:

```text
lake update
lake exe cache get
lake build
```

The pinned project files are supplied for reproducibility; a fresh network
dependency install was not tested in this run. The actual recorded checks used
the existing workspace Mathlib cache and direct `lean -o` invocations, in the
module order shown in `HallLocalization.lean`. The workspace-specific
`check.ps1` reproduces that route when the documented workspace layout exists.
It adds the official Mathlib Hall/Finite object if it is absent from the cache.
No compiled objects, executables or dependency caches are included here.
