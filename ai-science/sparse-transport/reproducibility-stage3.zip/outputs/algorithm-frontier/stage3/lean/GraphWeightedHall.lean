import GraphCutoff
import WeightedHall

/-! The classical weighted Hall theorem specialized to graph residual masses.
Supplies are b on exclusive sources and b-a on common sources; every target
has demand a. These are integer masses after multiplying by a*b.
Metric optimal transport and common-mass cancellation are not formalized here.
-/
namespace CurvatureGraph
open Finset

variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def residualSupply (x y v : V) : ℕ :=
  if v ∈ G.neighborFinset y then G.degree y - G.degree x else G.degree y

def availableSources (x : V) (S : Finset V) : Finset V :=
  (G.neighborFinset x).filter (fun v => ∃ s ∈ S, G.Adj v s)

/-- Sum the residual supplies after applying any source predicate. -/
theorem residual_supply_filter (x y : V) (P : V → Prop) [DecidablePred P] :
    (∑ v ∈ (G.neighborFinset x).filter P, residualSupply G x y v) =
      ((sourcesA G x y).filter P).card * G.degree y +
      ((sourcesC G x y).filter P).card * (G.degree y-G.degree x) := by
  have hC : ((G.neighborFinset x).filter P).filter
      (fun v => v ∈ G.neighborFinset y) = (sourcesC G x y).filter P := by
    ext v; simp [sourcesC]; tauto
  have hA : ((G.neighborFinset x).filter P).filter
      (fun v => v ∉ G.neighborFinset y) = (sourcesA G x y).filter P := by
    ext v; simp [sourcesA]; tauto
  simp only [residualSupply, Finset.sum_ite, hC, hA, Finset.sum_const,
    smul_eq_mul]
  omega

/-- Integer residual source mass equals integer residual target mass. -/
theorem residual_mass_balance (x y : V) (hdegree : G.degree x ≤ G.degree y) :
    (∑ v ∈ G.neighborFinset x, residualSupply G x y v) =
      (targetsB G x y).card * G.degree x := by
  have hsum := residual_supply_filter G x y (fun _ => True)
  simp only [Finset.filter_true_of_mem (fun _ _ => True.intro)] at hsum
  rw [hsum]
  have ha := exclusive_common_partition G x y
  have hd := exclusive_target_difference G x y
  have hsub := Nat.sub_add_cancel hdegree
  nlinarith

/-- The excluded integer source weight is exactly b*p+(b-a)*q. -/
theorem residual_excluded_weight (x y : V) (S : Finset V) :
    (∑ v ∈ excluded G (G.neighborFinset x) S, residualSupply G x y v) =
      (excluded G (sourcesA G x y) S).card * G.degree y +
      (excluded G (sourcesC G x y) S).card * (G.degree y-G.degree x) := by
  exact residual_supply_filter G x y (fun v => ∀ s ∈ S, ¬G.Adj v s)

/-- Available and excluded source weights partition the full source mass. -/
theorem residual_available_add_excluded (x y : V) (S : Finset V) :
    (∑ v ∈ availableSources G x S, residualSupply G x y v) +
      (∑ v ∈ excluded G (G.neighborFinset x) S, residualSupply G x y v) =
      ∑ v ∈ G.neighborFinset x, residualSupply G x y v := by
  classical
  have heq : excluded G (G.neighborFinset x) S =
      (G.neighborFinset x).filter (fun v => ¬∃ s ∈ S, G.Adj v s) := by
    ext v; simp [excluded]
  rw [heq]
  exact Finset.sum_filter_add_sum_filter_not _ _ _

/-- The graph Hall numerator is positive exactly when the target set's
integer demand exceeds the available integer source supply. -/
theorem positive_defect_iff_weighted_hall_violation (x y : V)
    (hdegree : G.degree x ≤ G.degree y) (S : Finset V) :
    positiveDefect G x y S ↔
      (∑ v ∈ availableSources G x S, residualSupply G x y v) <
        S.card * G.degree x := by
  have hb := residual_mass_balance G x y hdegree
  have he := residual_excluded_weight G x y S
  have hp := residual_available_add_excluded G x y S
  have hsub : ((G.degree y-G.degree x : ℕ) : ℤ) =
      (G.degree y : ℤ)-G.degree x := Int.ofNat_sub hdegree
  have hpZ := congrArg (fun n : ℕ => (n : ℤ)) hp
  rw [he,hb] at hpZ
  push_cast at hpZ
  rw [hsub] at hpZ
  unfold positiveDefect
  constructor <;> intro hh
  · exact_mod_cast (show ((∑ v ∈ availableSources G x S,
        residualSupply G x y v) : ℤ) < (S.card : ℤ)*G.degree x by omega)
  · have hhZ : ((∑ v ∈ availableSources G x S, residualSupply G x y v) : ℤ) <
        (S.card : ℤ)*G.degree x := by exact_mod_cast hh
    omega

abbrev ResidualSource (x : V) := ↥(G.neighborFinset x)
abbrev ResidualTarget (x y : V) := ↥(targetsB G x y)

def residualSourceSupply (x y : V) (i : ResidualSource G x) : ℕ :=
  residualSupply G x y i.val

def residualTargetDemand (x y : V) (_ : ResidualTarget G x y) : ℕ := G.degree x

def residualAllowed (x y : V) (j : ResidualTarget G x y)
    (i : ResidualSource G x) : Prop := G.Adj i.val j.val

def targetVertices (x y : V) (K : Finset (ResidualTarget G x y)) : Finset V :=
  K.image Subtype.val

theorem target_vertices_subset (x y : V) (K : Finset (ResidualTarget G x y)) :
    targetVertices G x y K ⊆ targetsB G x y := by
  intro v hv
  obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp hv
  exact j.property

theorem residual_neighbor_image (x y : V) (K : Finset (ResidualTarget G x y)) :
    (CurvatureWeightedHall.neighbors (residualAllowed G x y) K).image Subtype.val =
      availableSources G x (targetVertices G x y K) := by
  classical
  ext v
  constructor
  · intro hv
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hv
    obtain ⟨_,j,hj,hij⟩ := Finset.mem_filter.mp hi
    exact Finset.mem_filter.mpr ⟨i.property,j.val,
      Finset.mem_image_of_mem _ hj,hij⟩
  · intro hv
    obtain ⟨hvx,s,hs,hvs⟩ := Finset.mem_filter.mp hv
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hs
    apply Finset.mem_image.mpr
    refine ⟨⟨v,hvx⟩,?_,rfl⟩
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,j,hj,hvs⟩

theorem residual_neighbor_weight (x y : V) (K : Finset (ResidualTarget G x y)) :
    (∑ i ∈ CurvatureWeightedHall.neighbors (residualAllowed G x y) K,
      residualSourceSupply G x y i) =
      ∑ v ∈ availableSources G x (targetVertices G x y K), residualSupply G x y v := by
  classical
  rw [← residual_neighbor_image]
  rw [Finset.sum_image]
  · rfl
  · intro i _ j _ he
    exact Subtype.ext he

theorem residual_target_weight (x y : V) (K : Finset (ResidualTarget G x y)) :
    (∑ j ∈ K, residualTargetDemand G x y j) =
      (targetVertices G x y K).card * G.degree x := by
  simp [residualTargetDemand,targetVertices,
    Finset.card_image_of_injective _ Subtype.val_injective]

theorem residual_subtype_mass_balance (x y : V)
    (hdegree : G.degree x ≤ G.degree y) :
    (∑ j, residualTargetDemand G x y j) = ∑ i, residualSourceSupply G x y i := by
  have hb := residual_mass_balance G x y hdegree
  simpa [residualTargetDemand,residualSourceSupply,Finset.sum_coe_sort,
    Finset.sum_attach] using hb.symm

theorem graph_weighted_hall_iff_subtype (x y : V)
    (hdegree : G.degree x ≤ G.degree y) :
    (∀ K : Finset (ResidualTarget G x y),
      ¬positiveDefect G x y (targetVertices G x y K)) ↔
    (∀ K : Finset (ResidualTarget G x y),
      (∑ j ∈ K, residualTargetDemand G x y j) ≤
        ∑ i ∈ CurvatureWeightedHall.neighbors (residualAllowed G x y) K,
          residualSourceSupply G x y i) := by
  simp only [positive_defect_iff_weighted_hall_violation G x y hdegree,
    residual_neighbor_weight,residual_target_weight,not_lt]

theorem target_vertices_subtype (x y : V) (S : Finset V)
    (hS : S ⊆ targetsB G x y) :
    targetVertices G x y (S.subtype (fun v => v ∈ targetsB G x y)) = S := by
  ext v
  simp only [targetVertices,Finset.mem_image,Finset.mem_subtype]
  constructor
  · rintro ⟨j,hj,rfl⟩
    exact hj
  · intro hv
    exact ⟨⟨v,hS hv⟩,hv,rfl⟩

/-- Absence of a positive graph Hall witness is equivalent to a balanced
allowed bijection of integer residual mass clones. This is an exact finite
combinatorial feasibility theorem, not a metric optimal-transport theorem. -/
theorem graph_no_positive_defect_iff_clone_bijection (x y : V)
    (hdegree : G.degree x ≤ G.degree y) :
    (∀ S : Finset V, S ⊆ targetsB G x y → ¬positiveDefect G x y S) ↔
      ∃ f : (Σ j : ResidualTarget G x y, Fin (residualTargetDemand G x y j)) →
          (Σ i : ResidualSource G x, Fin (residualSourceSupply G x y i)),
        Function.Bijective f ∧ ∀ t, G.Adj (f t).1.val t.1.val := by
  have hsets :
      (∀ S : Finset V, S ⊆ targetsB G x y → ¬positiveDefect G x y S) ↔
      (∀ K : Finset (ResidualTarget G x y),
        ¬positiveDefect G x y (targetVertices G x y K)) := by
    constructor
    · intro h K
      exact h _ (target_vertices_subset G x y K)
    · intro h S hS
      have hh := h (S.subtype (fun v => v ∈ targetsB G x y))
      simpa only [target_vertices_subtype G x y S hS] using hh
  have hclones := CurvatureWeightedHall.balanced_weighted_hall_iff_clone_bijection
    (residualSourceSupply G x y) (residualTargetDemand G x y)
    (residualAllowed G x y) (residual_subtype_mass_balance G x y hdegree)
  exact hsets.trans ((graph_weighted_hall_iff_subtype G x y hdegree).trans hclones)

#print axioms residual_mass_balance
#print axioms residual_excluded_weight
#print axioms positive_defect_iff_weighted_hall_violation
#print axioms residual_subtype_mass_balance
#print axioms graph_weighted_hall_iff_subtype
#print axioms graph_no_positive_defect_iff_clone_bijection
end CurvatureGraph
