import Mathlib.Tactic

/-!
# Canonical Hall sets on a finite bipartite relation

This file proves the set-theoretic canonical-set and weighted-priority steps.
It does not verify an alternating-path implementation, maximum matching, or
metric optimal transport.  The weighted theorem explicitly assumes its
lower-order bound only for positive competitors; no global bound on the
excluded count at the empty set is required.

For the manuscript, take `I = A`, `J = B`, `U = N(x)`, use adjacency
for both relations, and set `K = k - 1`.  Then the balance is
`|B| = |A| + d` and the excluded count of the second relation is `p + q`.
This file does not formally instantiate those graph subtypes or derive the
positive-witness count bound from the complement-codegree assumption.

Replay from the repository root:
`powershell -File outputs/algorithm-frontier/stage3/lean/check-canonical-hall.ps1`.
-/

namespace CurvatureCanonicalHall

open Finset

variable {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

noncomputable def neighbors (r : J → I → Prop) (S : Finset J) : Finset I := by
  classical
  exact univ.filter (fun i => ∃ j ∈ S, r j i)

omit [Fintype J] [DecidableEq I] [DecidableEq J] in
@[simp] theorem mem_neighbors (r : J → I → Prop) (S : Finset J) (i : I) :
    i ∈ neighbors r S ↔ ∃ j ∈ S, r j i := by
  classical
  simp [neighbors]

omit [Fintype J] [DecidableEq I] [DecidableEq J] in
theorem neighbors_mono (r : J → I → Prop) {S T : Finset J} (h : S ⊆ T) :
    neighbors r S ⊆ neighbors r T := by
  intro i hi
  obtain ⟨j, hj, hr⟩ := (mem_neighbors r S i).mp hi
  exact (mem_neighbors r T i).mpr ⟨j, h hj, hr⟩

omit [Fintype J] in
theorem neighbors_union (r : J → I → Prop) (S T : Finset J) :
    neighbors r (S ∪ T) = neighbors r S ∪ neighbors r T := by
  classical
  ext i
  simp only [mem_neighbors, mem_union]
  constructor
  · rintro ⟨j, hj | hj, hr⟩
    · exact Or.inl ⟨j, hj, hr⟩
    · exact Or.inr ⟨j, hj, hr⟩
  · rintro (⟨j, hj, hr⟩ | ⟨j, hj, hr⟩)
    · exact ⟨j, Or.inl hj, hr⟩
    · exact ⟨j, Or.inr hj, hr⟩

theorem neighbors_inter_subset (r : J → I → Prop) (S T : Finset J) :
    neighbors r (S ∩ T) ⊆ neighbors r S ∩ neighbors r T := by
  intro i hi
  exact mem_inter.mpr
    ⟨neighbors_mono r inter_subset_left hi, neighbors_mono r inter_subset_right hi⟩

noncomputable def slope (r : J → I → Prop) (d : ℤ) (S : Finset J) : ℤ :=
  (S.card : ℤ) - (neighbors r S).card - d

/-- Hall deficiency, shifted by any fixed integer, is supermodular. -/
theorem slope_supermodular (r : J → I → Prop) (d : ℤ) (S T : Finset J) :
    slope r d S + slope r d T ≤ slope r d (S ∪ T) + slope r d (S ∩ T) := by
  have hS := card_union_add_card_inter S T
  have hN := card_union_add_card_inter (neighbors r S) (neighbors r T)
  have hI := card_le_card (neighbors_inter_subset r S T)
  rw [← neighbors_union r S T] at hN
  unfold slope
  omega

def IsSlopeMax (r : J → I → Prop) (d : ℤ) (S : Finset J) : Prop :=
  ∀ T : Finset J, slope r d T ≤ slope r d S

omit [Fintype J] [DecidableEq I] [DecidableEq J] in
theorem max_slopes_equal (r : J → I → Prop) (d : ℤ) {S T : Finset J}
    (hS : IsSlopeMax r d S) (hT : IsSlopeMax r d T) :
    slope r d S = slope r d T :=
  le_antisymm (hT S) (hS T)

theorem slope_max_union_inter (r : J → I → Prop) (d : ℤ) {S T : Finset J}
    (hS : IsSlopeMax r d S) (hT : IsSlopeMax r d T) :
    IsSlopeMax r d (S ∪ T) ∧ IsSlopeMax r d (S ∩ T) := by
  have heq := max_slopes_equal r d hS hT
  have hsuper := slope_supermodular r d S T
  have hU := hS (S ∪ T)
  have hI := hS (S ∩ T)
  constructor <;> intro K
  · have hK := hS K
    omega
  · have hK := hS K
    omega

/-- Finite bipartite relations have a least, hence unique minimal, Hall maximizer. -/
theorem exists_least_slope_max (r : J → I → Prop) (d : ℤ) :
    ∃ S₀ : Finset J, IsSlopeMax r d S₀ ∧
      ∀ T : Finset J, IsSlopeMax r d T → S₀ ⊆ T := by
  classical
  obtain ⟨S, _, hS⟩ :=
    (univ : Finset (Finset J)).exists_max_image (slope r d) (by simp)
  have hSm : IsSlopeMax r d S := fun T => hS T (mem_univ T)
  let maxima : Finset (Finset J) := univ.filter (IsSlopeMax r d)
  have hne : maxima.Nonempty := ⟨S, by simp [maxima, hSm]⟩
  obtain ⟨S₀, hS₀, hmin⟩ := maxima.exists_min_image Finset.card hne
  have hS₀m : IsSlopeMax r d S₀ := (mem_filter.mp hS₀).2
  refine ⟨S₀, hS₀m, ?_⟩
  intro T hTm
  have hinter : IsSlopeMax r d (S₀ ∩ T) := (slope_max_union_inter r d hS₀m hTm).2
  have hcard : S₀.card ≤ (S₀ ∩ T).card := hmin (S₀ ∩ T) (by simp [maxima, hinter])
  have heq : S₀ ∩ T = S₀ := eq_of_subset_of_card_le inter_subset_left hcard
  rw [← heq]
  exact inter_subset_right

omit [Fintype J] [DecidableEq I] [DecidableEq J] in
theorem least_slope_max_unique (r : J → I → Prop) (d : ℤ)
    {S T : Finset J} (hS : IsSlopeMax r d S)
    (hSleast : ∀ U, IsSlopeMax r d U → S ⊆ U)
    (hT : IsSlopeMax r d T)
    (hTleast : ∀ U, IsSlopeMax r d U → T ⊆ U) : S = T :=
  Subset.antisymm (hSleast T hT) (hTleast S hS)

/-- Closure under intersection makes every inclusion-minimal maximizer least. -/
theorem minimal_slope_max_iff_least (r : J → I → Prop) (d : ℤ)
    {S : Finset J} (hmax : IsSlopeMax r d S) :
    (∀ T, T ⊆ S → IsSlopeMax r d T → T = S) ↔
      (∀ T, IsSlopeMax r d T → S ⊆ T) := by
  constructor
  · intro hmin T hT
    have heq : S ∩ T = S :=
      hmin (S ∩ T) inter_subset_left (slope_max_union_inter r d hmax hT).2
    rw [← heq]
    exact inter_subset_right
  · intro hleast T hsub hT
    exact Subset.antisymm hsub (hleast T hT)

theorem exists_unique_minimal_slope_max (r : J → I → Prop) (d : ℤ) :
    ∃! S : Finset J, IsSlopeMax r d S ∧
      ∀ T, T ⊆ S → IsSlopeMax r d T → T = S := by
  obtain ⟨S, hmax, hleast⟩ := exists_least_slope_max r d
  refine ⟨S, ⟨hmax, (minimal_slope_max_iff_least r d hmax).mpr hleast⟩, ?_⟩
  intro T hT
  exact least_slope_max_unique r d hT.1
    ((minimal_slope_max_iff_least r d hT.1).mp hT.2) hmax hleast

omit [DecidableEq I] [DecidableEq J] in
/-- In the graph application, `|J| = |I| + d`, so the maximum slope is nonnegative. -/
theorem max_slope_nonnegative_of_balance (r : J → I → Prop) (d : ℤ)
    (hbalance : (Fintype.card I : ℤ) + d ≤ Fintype.card J)
    {S₀ : Finset J} (hmax : IsSlopeMax r d S₀) : 0 ≤ slope r d S₀ := by
  have hN : (neighbors r (univ : Finset J)).card ≤ Fintype.card I := card_le_univ _
  have hU := hmax (univ : Finset J)
  simp only [slope, card_univ] at hU
  unfold slope
  omega

/-- All sources excluded by a target set, for an arbitrary finite relation. -/
noncomputable def excluded (r : J → I → Prop) (S : Finset J) : Finset I := by
  classical
  exact univ.filter (fun i => ∀ j ∈ S, ¬ r j i)

omit [DecidableEq I] in
theorem excluded_antitone (r : J → I → Prop) {S T : Finset J} (h : S ⊆ T) :
    excluded r T ⊆ excluded r S := by
  classical
  intro i hi
  simp only [excluded, mem_filter, mem_univ, true_and] at hi ⊢
  exact fun j hj => hi j (h hj)

omit [DecidableEq I] in
theorem excluded_count_antitone (r : J → I → Prop) {S T : Finset J} (h : S ⊆ T) :
    ((excluded r T).card : ℤ) ≤ (excluded r S).card := by
  exact_mod_cast card_le_card (excluded_antitone r h)

omit [Fintype J] [DecidableEq I] [DecidableEq J] in
/--
The least slope maximizer also maximizes a weighted objective when one slope
unit outweighs every lower-order contribution of a positive competitor.
`e` may count a larger source set than the relation used to define the slope.
-/
theorem least_slope_max_weighted (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (he : ∀ S, 0 ≤ e S)
    (hanti : ∀ {S T : Finset J}, S ⊆ T → e T ≤ e S)
    (hbound : ∀ S, 0 < a * slope r d S + d * e S → e S ≤ K)
    {S₀ : Finset J} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ T, IsSlopeMax r d T → S₀ ⊆ T)
    (hell : 0 ≤ slope r d S₀) :
    ∀ S, a * slope r d S + d * e S ≤ a * slope r d S₀ + d * e S₀ := by
  have hdK : 0 ≤ d * K := mul_nonneg hd hK
  have ha : 0 < a := lt_of_le_of_lt hdK hpriority
  have he₀ : 0 ≤ d * e S₀ := mul_nonneg hd (he S₀)
  have hF₀ : 0 ≤ a * slope r d S₀ + d * e S₀ := by
    exact add_nonneg (mul_nonneg ha.le hell) he₀
  intro S
  by_cases hpos : 0 < a * slope r d S + d * e S
  · by_cases heq : slope r d S = slope r d S₀
    · have hSm : IsSlopeMax r d S := by
        intro T
        rw [heq]
        exact hmax T
      have heS : e S ≤ e S₀ := hanti (hleast S hSm)
      have hprod := mul_le_mul_of_nonneg_left heS hd
      rw [heq]
      linarith
    · have hgap : slope r d S ≤ slope r d S₀ - 1 := by
        have := hmax S
        omega
      have hmajor := mul_le_mul_of_nonneg_left hgap ha.le
      have hminor := mul_le_mul_of_nonneg_left (hbound S hpos) hd
      nlinarith
  · have hnonpos : a * slope r d S + d * e S ≤ 0 := le_of_not_gt hpos
    exact le_trans hnonpos hF₀

/-- The weighted maximizer exists on every balanced finite relation satisfying
the stated positive-witness bound.  The witness is also the least slope maximizer. -/
theorem exists_canonical_weighted_max (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (hbalance : (Fintype.card I : ℤ) + d ≤ Fintype.card J)
    (he : ∀ S, 0 ≤ e S)
    (hanti : ∀ {S T : Finset J}, S ⊆ T → e T ≤ e S)
    (hbound : ∀ S, 0 < a * slope r d S + d * e S → e S ≤ K) :
    ∃ S₀ : Finset J, IsSlopeMax r d S₀ ∧
      (∀ T, IsSlopeMax r d T → S₀ ⊆ T) ∧
      ∀ S, a * slope r d S + d * e S ≤ a * slope r d S₀ + d * e S₀ := by
  obtain ⟨S₀, hmax, hleast⟩ := exists_least_slope_max r d
  refine ⟨S₀, hmax, hleast, ?_⟩
  exact least_slope_max_weighted r a d K e hd hK hpriority he hanti hbound hmax hleast
    (max_slope_nonnegative_of_balance r d hbalance hmax)

/-- Direct finite-relation specialization: the lower-order term counts all
excluded sources of a second relation, possibly on a larger source type. -/
theorem exists_canonical_excluded_weighted_max
    {U : Type*} [Fintype U] [DecidableEq U]
    (r : J → I → Prop) (q : J → U → Prop) (a d K : ℤ)
    (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (hbalance : (Fintype.card I : ℤ) + d ≤ Fintype.card J)
    (hbound : ∀ S, 0 < a * slope r d S + d * (excluded q S).card →
      ((excluded q S).card : ℤ) ≤ K) :
    ∃ S₀ : Finset J, IsSlopeMax r d S₀ ∧
      (∀ T, IsSlopeMax r d T → S₀ ⊆ T) ∧
      ∀ S, a * slope r d S + d * (excluded q S).card ≤
        a * slope r d S₀ + d * (excluded q S₀).card := by
  apply exists_canonical_weighted_max r a d K
    (fun S => ((excluded q S).card : ℤ)) hd hK hpriority hbalance
  · intro S
    exact_mod_cast Nat.zero_le (excluded q S).card
  · intro S T hST
    exact excluded_count_antitone q hST
  · exact hbound

#print axioms slope_supermodular
#print axioms slope_max_union_inter
#print axioms exists_least_slope_max
#print axioms least_slope_max_unique
#print axioms exists_unique_minimal_slope_max
#print axioms max_slope_nonnegative_of_balance
#print axioms excluded_count_antitone
#print axioms least_slope_max_weighted
#print axioms exists_canonical_weighted_max
#print axioms exists_canonical_excluded_weighted_max

end CurvatureCanonicalHall
