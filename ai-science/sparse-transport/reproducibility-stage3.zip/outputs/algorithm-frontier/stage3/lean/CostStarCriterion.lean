import CanonicalHall

/-!
# Restricting canonical Hall sets and the scalar row-star correction

This file proves the finite-subset restriction argument.  The final correction
uses the explicit extra lower bound `F(S₀) ≥ a L(S₀) + d`; proving that lower
bound from a particular cost-three row is outside this file.  Likewise, the
identification of the scalar maximum with optimal metric transport is not
assumed or proved here.  All maxima below are genuine maxima over finite
powersets, with an additional zero candidate.

Replay: powershell -File
outputs/algorithm-frontier/stage3/lean/check-cost-star-criterion.ps1
-/

namespace CurvatureCostStarCriterion

open Finset CurvatureCanonicalHall

variable {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

noncomputable def objective (r : J → I → Prop) (a d : ℤ)
    (e : Finset J → ℤ) (S : Finset J) : ℤ :=
  a * slope r d S + d * e S

/-- The value of `max (0, max_{T ⊆ Z} F(T))`, stated without a chosen maximizer. -/
def IsRestrictedDefect (F : Finset J → ℤ) (Z : Finset J) (δZ : ℤ) : Prop :=
  0 ≤ δZ ∧ (∀ T, T ⊆ Z → F T ≤ δZ) ∧
    (0 < δZ → ∃ T, T ⊆ Z ∧ F T = δZ)

theorem exists_restricted_defect (F : Finset J → ℤ) (Z : Finset J) :
    ∃ δZ, IsRestrictedDefect F Z δZ := by
  obtain ⟨T, hT, hmax⟩ := Z.powerset.exists_max_image F (powerset_nonempty Z)
  refine ⟨max 0 (F T), le_max_left _ _, ?_, ?_⟩
  · intro S hS
    exact le_trans (hmax S (mem_powerset.mpr hS)) (le_max_right _ _)
  · intro hpos
    rcases le_total 0 (F T) with h | h
    · exact ⟨T, mem_powerset.mp hT, (max_eq_right h).symm⟩
    · rw [max_eq_left h] at hpos
      omega

theorem restricted_defect_unique (F : Finset J → ℤ) (Z : Finset J)
    {δ₁ δ₂ : ℤ} (h₁ : IsRestrictedDefect F Z δ₁)
    (h₂ : IsRestrictedDefect F Z δ₂) : δ₁ = δ₂ := by
  have hle : ∀ {u v}, IsRestrictedDefect F Z u → IsRestrictedDefect F Z v → u ≤ v := by
    intro u v hu hv
    by_cases hpos : 0 < u
    · obtain ⟨T, hT, heq⟩ := hu.2.2 hpos
      rw [← heq]
      exact hv.2.1 T hT
    · exact le_trans (le_of_not_gt hpos) hv.1
  exact le_antisymm (hle h₁ h₂) (hle h₂ h₁)

/-- Omitting the least maximizer loses at least one whole integer slope unit. -/
theorem restricted_slope_drop (r : J → I → Prop) (d : ℤ)
    {S₀ Z T : Finset J} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hnot : ¬ S₀ ⊆ Z) (hT : T ⊆ Z) :
    slope r d T ≤ slope r d S₀ - 1 := by
  have hle := hmax T
  have hne : slope r d T ≠ slope r d S₀ := by
    intro heq
    have hTm : IsSlopeMax r d T := by
      intro S
      rw [heq]
      exact hmax S
    exact hnot (Subset.trans (hleast T hTm) hT)
  omega

theorem restricted_positive_bound (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z T : Finset J} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hnot : ¬ S₀ ⊆ Z) (hT : T ⊆ Z)
    (hpos : 0 < objective r a d e T) :
    objective r a d e T ≤ a * (slope r d S₀ - 1) + d * K := by
  have hmajor := mul_le_mul_of_nonneg_left
    (restricted_slope_drop r d hmax hleast hnot hT) ha
  have hminor := mul_le_mul_of_nonneg_left (hbound T hpos) hd
  unfold objective
  linarith

theorem restricted_value_eq_global (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (he : ∀ S, 0 ≤ e S)
    (hanti : ∀ {S T : Finset J}, S ⊆ T → e T ≤ e S)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z : Finset J} {δZ : ℤ} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hell : 0 ≤ slope r d S₀)
    (hrestricted : IsRestrictedDefect (objective r a d e) Z δZ)
    (hsub : S₀ ⊆ Z) : δZ = objective r a d e S₀ := by
  have ha : 0 ≤ a := (lt_of_le_of_lt (mul_nonneg hd hK) hpriority).le
  have hglobal := least_slope_max_weighted r a d K e hd hK hpriority he hanti
    hbound hmax hleast hell
  have hnonneg : 0 ≤ objective r a d e S₀ :=
    add_nonneg (mul_nonneg ha hell) (mul_nonneg hd (he S₀))
  apply le_antisymm
  · by_cases hpos : 0 < δZ
    · obtain ⟨T, _, heq⟩ := hrestricted.2.2 hpos
      rw [← heq]
      exact hglobal T
    · exact le_trans (le_of_not_gt hpos) hnonneg
  · exact hrestricted.2.1 S₀ hsub

/-- If the canonical set is omitted, a positive restricted optimum obeys the
same strict-priority slope-loss bound as every positive restricted witness. -/
theorem positive_restricted_value_bound (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z : Finset J} {δZ : ℤ} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hrestricted : IsRestrictedDefect (objective r a d e) Z δZ)
    (hnot : ¬ S₀ ⊆ Z) (hpos : 0 < δZ) :
    δZ ≤ a * (slope r d S₀ - 1) + d * K := by
  obtain ⟨T, hT, heq⟩ := hrestricted.2.2 hpos
  have hTpos : 0 < objective r a d e T := by omega
  rw [← heq]
  exact restricted_positive_bound r a d K e ha hd hbound hmax hleast hnot hT hTpos

theorem correction_eq_global_of_not_subset (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z : Finset J} {δZ : ℤ} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hell : 0 ≤ slope r d S₀)
    (hmargin : a * slope r d S₀ + d ≤ objective r a d e S₀)
    (hrestricted : IsRestrictedDefect (objective r a d e) Z δZ)
    (hnot : ¬ S₀ ⊆ Z) :
    max (objective r a d e S₀) (d + δZ) = objective r a d e S₀ := by
  have ha : 0 ≤ a := (lt_of_le_of_lt (mul_nonneg hd hK) hpriority).le
  apply max_eq_left
  by_cases hpos : 0 < δZ
  · have hb := positive_restricted_value_bound r a d K e ha hd hbound hmax
      hleast hrestricted hnot hpos
    nlinarith
  · have hzero : δZ = 0 := by have := hrestricted.1; omega
    have := mul_nonneg ha hell
    rw [hzero]
    linarith

/-- Exact scalar correction, including the degenerate case `d = 0`. -/
theorem correction_value (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (he : ∀ S, 0 ≤ e S)
    (hanti : ∀ {S T : Finset J}, S ⊆ T → e T ≤ e S)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z : Finset J} {δZ : ℤ} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hell : 0 ≤ slope r d S₀)
    (hmargin : a * slope r d S₀ + d ≤ objective r a d e S₀)
    (hrestricted : IsRestrictedDefect (objective r a d e) Z δZ) :
    max (objective r a d e S₀) (d + δZ) =
      objective r a d e S₀ + if S₀ ⊆ Z then d else 0 := by
  by_cases hsub : S₀ ⊆ Z
  · have heq := restricted_value_eq_global r a d K e hd hK hpriority he hanti
      hbound hmax hleast hell hrestricted hsub
    rw [if_pos hsub, heq]
    have hle : objective r a d e S₀ ≤ d + objective r a d e S₀ := by omega
    rw [max_eq_right hle]
    ring
  · have heq := correction_eq_global_of_not_subset r a d K e hd hK hpriority
      hbound hmax hleast hell hmargin hrestricted hsub
    simp only [if_neg hsub, add_zero, heq]

/-- The scalar correction is strict exactly when `d > 0` and the canonical
set is contained in the permitted bad-target set.  This is not a transport theorem. -/
theorem strict_correction_iff (r : J → I → Prop) (a d K : ℤ)
    (e : Finset J → ℤ) (hd : 0 ≤ d) (hK : 0 ≤ K) (hpriority : d * K < a)
    (he : ∀ S, 0 ≤ e S)
    (hanti : ∀ {S T : Finset J}, S ⊆ T → e T ≤ e S)
    (hbound : ∀ S, 0 < objective r a d e S → e S ≤ K)
    {S₀ Z : Finset J} {δZ : ℤ} (hmax : IsSlopeMax r d S₀)
    (hleast : ∀ S, IsSlopeMax r d S → S₀ ⊆ S)
    (hell : 0 ≤ slope r d S₀)
    (hmargin : a * slope r d S₀ + d ≤ objective r a d e S₀)
    (hrestricted : IsRestrictedDefect (objective r a d e) Z δZ) :
    objective r a d e S₀ < max (objective r a d e S₀) (d + δZ) ↔
      0 < d ∧ S₀ ⊆ Z := by
  by_cases hsub : S₀ ⊆ Z
  · have heq := restricted_value_eq_global r a d K e hd hK hpriority he hanti
      hbound hmax hleast hell hrestricted hsub
    rw [heq]
    have hle : objective r a d e S₀ ≤ d + objective r a d e S₀ := by omega
    rw [max_eq_right hle]
    constructor
    · intro h
      exact ⟨by omega, hsub⟩
    · rintro ⟨h, _⟩
      omega
  · have heq := correction_eq_global_of_not_subset r a d K e hd hK hpriority
      hbound hmax hleast hell hmargin hrestricted hsub
    rw [heq]
    simp [hsub]

#print axioms exists_restricted_defect
#print axioms restricted_defect_unique
#print axioms restricted_slope_drop
#print axioms restricted_positive_bound
#print axioms restricted_value_eq_global
#print axioms positive_restricted_value_bound
#print axioms correction_eq_global_of_not_subset
#print axioms correction_value
#print axioms strict_correction_iff

end CurvatureCostStarCriterion
