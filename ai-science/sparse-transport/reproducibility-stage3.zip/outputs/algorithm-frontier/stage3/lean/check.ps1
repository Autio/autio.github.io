$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../../..')).Path
$taskLean = Join-Path $taskRoot 'work/lean-toolchain/lean-4.19.0-windows/bin/lean.exe'
$taskMathlib = Join-Path $taskRoot 'work/mathlib4'
$taskLibs = @((Join-Path $taskMathlib '.lake/build/lib/lean'), $PSScriptRoot)
Get-ChildItem (Join-Path $taskMathlib '.lake/packages') -Directory | ForEach-Object {
    $taskLib = Join-Path $_.FullName '.lake/build/lib/lean'
    if (Test-Path -LiteralPath $taskLib) { $taskLibs += $taskLib }
}
$taskOldLeanPath = $env:LEAN_PATH
try {
    $env:LEAN_PATH = $taskLibs -join ';'
    $taskLog = @(& $taskLean --version)
    $taskHallSource = Join-Path $taskMathlib 'Mathlib/Combinatorics/Hall/Finite.lean'
    $taskHallOutput = Join-Path $taskMathlib '.lake/build/lib/lean/Mathlib/Combinatorics/Hall/Finite.olean'
    if (-not (Test-Path -LiteralPath $taskHallOutput)) {
        New-Item -ItemType Directory -Force (Split-Path $taskHallOutput) | Out-Null
        & $taskLean "--root=$taskMathlib" -o $taskHallOutput $taskHallSource
        if ($LASTEXITCODE -ne 0) { throw 'Mathlib finite Hall dependency compilation failed.' }
    }
    foreach ($taskName in @('GraphHall','SharpLocalization','SparseFilter','CutoffEquality','GraphCutoff','GraphBoundary','WeightedHall','GraphWeightedHall','IntegerTransport','DistanceThreeStar','CanonicalHall','RealTransportHall','GraphQuantitative','CostStarCriterion','GraphCanonical')) {
        $taskResult = & $taskLean -o (Join-Path $PSScriptRoot "$taskName.olean") (Join-Path $PSScriptRoot "$taskName.lean") 2>&1
        $taskCode = $LASTEXITCODE
        $taskLog += $taskResult
        $taskResult
        if ($taskCode -ne 0) { throw "Lean compilation failed: $taskName" }
    }
    $taskLog | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'compiler.log') -Encoding utf8
} finally { $env:LEAN_PATH = $taskOldLeanPath }
