import IntegerTransport
import Mathlib.Data.Real.Basic

/-! A real feasible transport supported on an allowed finite relation satisfies
the integer weighted Hall inequalities. This checks a genuine necessity bridge,
not metric cancellation or arbitrary-cost transport integrality. -/
namespace CurvatureWeightedHall
open Finset Function
variable {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

theorem real_supported_plan_implies_weighted_hall
    (u : I → ℕ) (v : J → ℕ) (r : J → I → Prop)
    (plan : J → I → ℝ)
    (hnonneg : ∀ j i, 0 ≤ plan j i)
    (htarget : ∀ j, ∑ i, plan j i = (v j : ℝ))
    (hsource : ∀ i, ∑ j, plan j i = (u i : ℝ))
    (hsupport : ∀ j i, ¬r j i → plan j i = 0) :
    ∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i := by
  classical
  intro S
  have hpoint (i : I) :
      (∑ j ∈ S, plan j i) ≤ if i ∈ neighbors r S then (u i : ℝ) else 0 := by
    by_cases hi : i ∈ neighbors r S
    · rw [if_pos hi, ← hsource i]
      exact Finset.sum_le_univ_sum_of_nonneg (fun j => hnonneg j i)
    · rw [if_neg hi]
      have heq : (∑ j ∈ S, plan j i) = 0 := by
        apply Finset.sum_eq_zero
        intro j hj
        apply hsupport j i
        intro hr
        apply hi
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, j, hj, hr⟩
      exact le_of_eq heq
  have hreal : (∑ j ∈ S, (v j : ℝ)) ≤ ∑ i ∈ neighbors r S, (u i : ℝ) := by
    calc
      (∑ j ∈ S, (v j : ℝ)) = ∑ j ∈ S, ∑ i, plan j i :=
        Finset.sum_congr rfl (fun j _ => (htarget j).symm)
      _ = ∑ i, ∑ j ∈ S, plan j i := Finset.sum_comm
      _ ≤ ∑ i, if i ∈ neighbors r S then (u i : ℝ) else 0 :=
        Finset.sum_le_sum (fun i _ => hpoint i)
      _ = ∑ i ∈ neighbors r S, (u i : ℝ) := by
        simp only [← Finset.sum_filter, Finset.filter_mem_eq_inter, Finset.univ_inter]
  exact_mod_cast hreal

/-- A real allowed plan with integer marginals already implies an allowed
unit-clone bijection. This is a feasibility bridge, not general cost integrality. -/
theorem real_supported_plan_implies_clone_bijection
    (u : I → ℕ) (v : J → ℕ) (r : J → I → Prop)
    (hbalance : ∑ j, v j = ∑ i, u i)
    (plan : J → I → ℝ)
    (hnonneg : ∀ j i, 0 ≤ plan j i)
    (htarget : ∀ j, ∑ i, plan j i = (v j : ℝ))
    (hsource : ∀ i, ∑ j, plan j i = (u i : ℝ))
    (hsupport : ∀ j i, ¬r j i → plan j i = 0) :
    ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
      Bijective f ∧ ∀ t, r t.1 (f t).1 := by
  exact (balanced_weighted_hall_iff_clone_bijection u v r hbalance).mp
    (real_supported_plan_implies_weighted_hall u v r plan hnonneg htarget hsource hsupport)

#print axioms real_supported_plan_implies_weighted_hall
#print axioms real_supported_plan_implies_clone_bijection

theorem real_cost_lower_bound
    (v : J → ℕ) (cost : J → I → ℝ) (plan : J → I → ℝ)
    (hnonneg : ∀ j i, 0 ≤ plan j i)
    (hcost : ∀ j i, 1 ≤ cost j i)
    (htarget : ∀ j, ∑ i, plan j i = (v j : ℝ)) :
    (∑ j, (v j : ℝ)) ≤ ∑ j, ∑ i, cost j i * plan j i := by
  calc
    (∑ j, (v j : ℝ)) = ∑ j, ∑ i, plan j i :=
      Finset.sum_congr rfl (fun j _ => (htarget j).symm)
    _ ≤ ∑ j, ∑ i, cost j i * plan j i := by
      apply Finset.sum_le_sum
      intro j hj
      apply Finset.sum_le_sum
      intro i hi
      nlinarith [hnonneg j i,hcost j i]

/-- Attaining the real unit-cost lower bound forces support on cost-one pairs. -/
theorem real_cost_baseline_forces_unit_support
    (v : J → ℕ) (cost : J → I → ℝ) (plan : J → I → ℝ)
    (hnonneg : ∀ j i, 0 ≤ plan j i)
    (hcost : ∀ j i, 1 ≤ cost j i)
    (htarget : ∀ j, ∑ i, plan j i = (v j : ℝ))
    (hoptimal : (∑ j, ∑ i, cost j i * plan j i) = ∑ j, (v j : ℝ)) :
    ∀ j i, cost j i ≠ 1 → plan j i = 0 := by
  classical
  have hpoint (j : J) (i : I) : plan j i ≤ cost j i * plan j i := by
    nlinarith [hnonneg j i, hcost j i]
  have hrow (j : J) : (∑ i, plan j i) ≤ ∑ i, cost j i * plan j i :=
    Finset.sum_le_sum (fun i _ => hpoint j i)
  have hsum : (∑ j, ∑ i, plan j i) = ∑ j, ∑ i, cost j i * plan j i := by
    rw [hoptimal]
    exact Finset.sum_congr rfl (fun j _ => htarget j)
  have hrows := (Finset.sum_eq_sum_iff_of_le (fun j _ => hrow j)).mp hsum
  intro j i hne
  have he := (Finset.sum_eq_sum_iff_of_le (fun i _ => hpoint j i)).mp
    (hrows j (Finset.mem_univ _)) i (Finset.mem_univ _)
  have hz : (cost j i - 1) * plan j i = 0 := by nlinarith [he]
  exact (mul_eq_zero.mp hz).resolve_left (sub_ne_zero.mpr hne)

/-- A real unit-cost optimum with integer marginals implies an integral allowed
clone bijection. No generic minimum-cost-flow integrality is assumed. -/
theorem real_unit_optimum_implies_clone_bijection
    (u : I → ℕ) (v : J → ℕ) (cost : J → I → ℝ)
    (hbalance : ∑ j, v j = ∑ i, u i)
    (plan : J → I → ℝ)
    (hnonneg : ∀ j i, 0 ≤ plan j i)
    (hcost : ∀ j i, 1 ≤ cost j i)
    (htarget : ∀ j, ∑ i, plan j i = (v j : ℝ))
    (hsource : ∀ i, ∑ j, plan j i = (u i : ℝ))
    (hoptimal : (∑ j, ∑ i, cost j i * plan j i) = ∑ j, (v j : ℝ)) :
    ∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
      Bijective f ∧ ∀ t, cost t.1 (f t).1 = 1 := by
  apply real_supported_plan_implies_clone_bijection u v (fun j i => cost j i = 1)
    hbalance plan hnonneg htarget hsource
  exact real_cost_baseline_forces_unit_support v cost plan hnonneg hcost htarget hoptimal

#print axioms real_cost_baseline_forces_unit_support
#print axioms real_cost_lower_bound
#print axioms real_unit_optimum_implies_clone_bijection

/-- Aggregate an allowed unit-clone bijection into an actual nonnegative real
matrix with the prescribed integer marginals. -/
theorem clone_bijection_implies_real_supported_plan
    (u : I → ℕ) (v : J → ℕ) (r : J → I → Prop)
    (f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)))
    (hf : Bijective f) (hallowed : ∀ t, r t.1 (f t).1) :
    ∃ plan : J → I → ℝ,
      (∀ j i, 0 ≤ plan j i) ∧
      (∀ j, ∑ i, plan j i = (v j : ℝ)) ∧
      (∀ i, ∑ j, plan j i = (u i : ℝ)) ∧
      (∀ j i, ¬r j i → plan j i = 0) := by
  classical
  let plan : J → I → ℝ := fun j i =>
    ∑ t : Fin (v j), if (f ⟨j,t⟩).1 = i then 1 else 0
  refine ⟨plan, ?_, ?_, ?_, ?_⟩
  · intro j i
    exact Finset.sum_nonneg (fun t _ => by split_ifs <;> norm_num)
  · intro j
    dsimp [plan]
    rw [Finset.sum_comm]
    simp
  · intro i
    calc
      (∑ j, plan j i) = ∑ t : (Σ j, Fin (v j)),
          if (f t).1 = i then (1 : ℝ) else 0 := by
        exact (Fintype.sum_sigma (fun t : (Σ j, Fin (v j)) =>
          if (f t).1 = i then (1 : ℝ) else 0)).symm
      _ = ∑ s : (Σ i, Fin (u i)), if s.1 = i then (1 : ℝ) else 0 :=
        hf.sum_comp (fun s => if s.1 = i then (1 : ℝ) else 0)
      _ = (u i : ℝ) := by
        rw [Fintype.sum_sigma]
        change (∑ x, ∑ _t : Fin (u x), if x = i then (1 : ℝ) else 0) = (u i : ℝ)
        calc
          _ = ∑ x, if x = i then (u x : ℝ) else 0 := by
            apply Finset.sum_congr rfl
            intro x hx
            by_cases he : x = i <;> simp [he]
          _ = (u i : ℝ) := by simp
  · intro j i hnot
    apply Finset.sum_eq_zero
    intro t ht
    have hne : (f ⟨j,t⟩).1 ≠ i := by
      intro he
      have hr := hallowed ⟨j,t⟩
      exact hnot (he ▸ hr)
    exact if_neg hne

theorem real_supported_plan_iff_weighted_hall
    (u : I → ℕ) (v : J → ℕ) (r : J → I → Prop)
    (hbalance : ∑ j, v j = ∑ i, u i) :
    (∃ plan : J → I → ℝ,
      (∀ j i, 0 ≤ plan j i) ∧
      (∀ j, ∑ i, plan j i = (v j : ℝ)) ∧
      (∀ i, ∑ j, plan j i = (u i : ℝ)) ∧
      (∀ j i, ¬r j i → plan j i = 0)) ↔
      (∀ S : Finset J, (∑ j ∈ S, v j) ≤ ∑ i ∈ neighbors r S, u i) := by
  constructor
  · rintro ⟨plan,hn,ht,hs,ha⟩
    exact real_supported_plan_implies_weighted_hall u v r plan hn ht hs ha
  · intro hHall
    obtain ⟨f,hf,ha⟩ :=
      (balanced_weighted_hall_iff_clone_bijection u v r hbalance).mp hHall
    exact clone_bijection_implies_real_supported_plan u v r f hf ha

#print axioms clone_bijection_implies_real_supported_plan
#print axioms real_supported_plan_iff_weighted_hall

theorem real_unit_optimum_iff_clone_bijection
    (u : I → ℕ) (v : J → ℕ) (cost : J → I → ℝ)
    (hbalance : ∑ j, v j = ∑ i, u i)
    (hcost : ∀ j i, 1 ≤ cost j i) :
    (∃ plan : J → I → ℝ,
      (∀ j i, 0 ≤ plan j i) ∧
      (∀ j, ∑ i, plan j i = (v j : ℝ)) ∧
      (∀ i, ∑ j, plan j i = (u i : ℝ)) ∧
      (∑ j, ∑ i, cost j i * plan j i) = ∑ j, (v j : ℝ)) ↔
      (∃ f : (Σ j, Fin (v j)) → (Σ i, Fin (u i)),
        Bijective f ∧ ∀ t, cost t.1 (f t).1 = 1) := by
  constructor
  · rintro ⟨plan,hn,ht,hs,ho⟩
    exact real_unit_optimum_implies_clone_bijection u v cost hbalance plan hn hcost ht hs ho
  · rintro ⟨f,hf,ha⟩
    obtain ⟨plan,hn,ht,hs,hallow⟩ := clone_bijection_implies_real_supported_plan
      u v (fun j i => cost j i = 1) f hf ha
    refine ⟨plan,hn,ht,hs,?_⟩
    have he (j : J) (i : I) : cost j i * plan j i = plan j i := by
      by_cases hc : cost j i = 1
      · rw [hc,one_mul]
      · rw [hallow j i hc,mul_zero]
    simp_rw [he]
    exact Finset.sum_congr rfl (fun j _ => ht j)

#print axioms real_unit_optimum_iff_clone_bijection
end CurvatureWeightedHall

namespace CurvatureGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Absence of a graph Hall defect is equivalent to a real residual transport
matrix attaining its unit-cost lower bound. Costs are supplied explicitly;
metric common-mass cancellation is not part of this statement. -/
theorem graph_no_defect_iff_real_cost_baseline (x y : V)
    (hdegree : G.degree x ≤ G.degree y)
    (cost : ResidualTarget G x y → ResidualSource G x → ℝ)
    (hpos : ∀ j i, 1 ≤ cost j i)
    (hunit : ∀ j i, cost j i = 1 ↔ G.Adj i.val j.val) :
    (∀ S : Finset V, S ⊆ targetsB G x y → ¬positiveDefect G x y S) ↔
      (∃ plan : ResidualTarget G x y → ResidualSource G x → ℝ,
        (∀ j i, 0 ≤ plan j i) ∧
        (∀ j, ∑ i, plan j i = (residualTargetDemand G x y j : ℝ)) ∧
        (∀ i, ∑ j, plan j i = (residualSourceSupply G x y i : ℝ)) ∧
        (∑ j, ∑ i, cost j i * plan j i) =
          ∑ j, (residualTargetDemand G x y j : ℝ)) := by
  have hclone := graph_no_positive_defect_iff_clone_bijection G x y hdegree
  have hreal := CurvatureWeightedHall.real_unit_optimum_iff_clone_bijection
    (residualSourceSupply G x y) (residualTargetDemand G x y) cost
    (residual_subtype_mass_balance G x y hdegree) hpos
  refine hclone.trans ?_
  constructor
  · rintro ⟨f,hf,ha⟩
    exact hreal.mpr ⟨f,hf,fun t => (hunit t.1 (f t).1).mpr (ha t)⟩
  · intro hh
    obtain ⟨f,hf,ha⟩ := hreal.mp hh
    exact ⟨f,hf,fun t => (hunit t.1 (f t).1).mp (ha t)⟩

#print axioms graph_no_defect_iff_real_cost_baseline
end CurvatureGraph
