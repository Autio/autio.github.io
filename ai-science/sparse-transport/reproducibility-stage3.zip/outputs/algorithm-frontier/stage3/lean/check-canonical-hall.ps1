$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../../..')).Path
$taskLean = Join-Path $taskRoot 'work/lean-toolchain/lean-4.19.0-windows/bin/lean.exe'
$taskMathlib = Join-Path $taskRoot 'work/mathlib4'
$taskLibs = @((Join-Path $taskMathlib '.lake/build/lib/lean'), $PSScriptRoot)
Get-ChildItem (Join-Path $taskMathlib '.lake/packages') -Directory | ForEach-Object {
  $taskLib = Join-Path $_.FullName '.lake/build/lib/lean'
  if (Test-Path -LiteralPath $taskLib) { $taskLibs += $taskLib }
}
$taskOldLeanPath = $env:LEAN_PATH
try {
  $env:LEAN_PATH = $taskLibs -join ';'
  $taskLog = @(& $taskLean --version)
  $taskResult = & $taskLean -o (Join-Path $PSScriptRoot 'CanonicalHall.olean') (Join-Path $PSScriptRoot 'CanonicalHall.lean') 2>&1
  $taskCode = $LASTEXITCODE
  $taskLog += $taskResult
  $taskLog | Set-Content (Join-Path $PSScriptRoot 'canonical-compiler.log') -Encoding utf8
  $taskResult
  if ($taskCode -ne 0) { throw 'Lean compilation failed: CanonicalHall' }
} finally {
  $env:LEAN_PATH = $taskOldLeanPath
}
