"""Independent exact checks of the optional star backend; prior files untouched."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from collections import Counter
import json,time,platform,sys
from star_transport import edge_curvature,preprocess
from curvature_probe import complement,connected,transport

root=Path(__file__).resolve().parent;start=time.perf_counter()
counts=Counter();graphs=0
for n in range(2,7):
    pairs=list(combinations(range(n),2))
    for mask in range(1<<len(pairs)):
        adj=complement(n,[e for j,e in enumerate(pairs) if mask>>j&1])
        if not connected(adj):continue
        graphs+=1;h=[set(range(n))-{u}-adj[u] for u in range(n)]
        k=max(1,max((len(h[u]&h[v]) for u,v in pairs),default=0))
        data=preprocess(adj,k)
        for x,y in pairs:
            if y not in adj[x]:continue
            result=edge_curvature(adj,x,y,k,data,allow_small_order=True)
            if result is None:counts['ineligible']+=1;continue
            got,meta=result;expected=transport(adj,x,y)
            assert got==expected,(n,mask,k,x,y,got,expected,meta)
            counts['eligible']+=1
            if meta['shortcut']:counts['shortcut']+=1
            else:
                counts[meta['case']]+=1
                if meta['scaled_extra_cost']>meta['scaled_hall_deficit']:
                    counts['strict_distance_three_correction']+=1
    print(json.dumps({'order':n,'counts':dict(counts)}),flush=True)

gpu=json.loads((root.parent/'gpu_random_n9.json').read_text());n=gpu['n']
pairs=[e for e in combinations(range(n),2) if e!=(0,1)]
for row in gpu['records']:
    adj=complement(n,[e for j,e in enumerate(pairs) if row['mask']>>j&1])
    h=[set(range(n))-{u}-adj[u] for u in range(n)]
    k=max(1,max(len(h[u]&h[v]) for u,v in combinations(range(n),2)))
    result=edge_curvature(adj,0,1,k,preprocess(adj,k),allow_small_order=True)
    if result is None:counts['gpu_ineligible']+=1;continue
    got,meta=result;expected=Fraction(row['numerator'],row['denominator'])
    assert got==expected,(row,k,got,expected,meta)
    counts['gpu_eligible']+=1

families=[]
for c in (3,10,50,200):
    S=[3,4];C=list(range(5,5+c));n=5+c
    adj=complement(n,[(2,v) for v in [1]+S+C]+[(0,v) for v in S])
    got,meta=edge_curvature(adj,0,1,2,preprocess(adj,2))
    expected=Fraction(c,c+3)-Fraction(2,(c+2)*(c+3))
    assert got==expected==transport(adj,0,1)
    assert meta['case']=='cost_three_row_star' and meta['scaled_extra_cost']==2
    families.append({'n':n,'value':str(got),'proof':meta})

result={'passed':True,'graphs':graphs,'counts':dict(counts),'large_row_stars':families,
    'seconds':time.perf_counter()-start,'python':sys.version,'platform':platform.platform(),
    'scope':'All connected labeled graphs through6 for eligible backend regime; eligible replay of overlapping stored GPU records; four large pendant-row controls. No counts imply new distinct graph coverage beyond stated protocols.'}
(root/'star-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2),flush=True)
