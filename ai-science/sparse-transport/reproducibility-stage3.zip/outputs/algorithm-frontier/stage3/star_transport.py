"""Optional exact matching backend, including row/column stars of cost three.

Uses the proved graph Hall dominance a>d(k-1). It does not construct common
source rows. None means the caller must use the general transport backend.
For all large-order candidates n>k²+k+1, costs-three form a star when n>4k;
the only possible large-order exception is k=2,n=8, handled by fallback.
The final row-star test reuses the one unrestricted canonical matching.
Matching machinery is classical; see stage3-star-priority.md and the single-matching audit for proof.
"""
from collections import deque
from fractions import Fraction
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from adaptive_curvature import edge_curvature as general_edge,preprocess


def _matching(edges,alpha):
    beta=len(edges);mate_A=[-1]*alpha;mate_B=[-1]*beta;matching=0
    for first in range(beta):
        if mate_B[first]>=0:continue
        queue=deque([first]);seen={first};parent_A={};last=None
        while queue and last is None:
            j=queue.popleft()
            for i in edges[j]:
                if i in parent_A:continue
                parent_A[i]=j
                if mate_A[i]<0:last=i;break
                nxt=mate_A[i]
                if nxt not in seen:seen.add(nxt);queue.append(nxt)
        if last is not None:
            i=last
            while True:
                j=parent_A[i];previous=mate_B[j];mate_B[j]=i;mate_A[i]=j
                if previous<0:break
                i=previous
            matching+=1
    reached_B={j for j in range(beta) if mate_B[j]<0}
    reached_A=set();queue=deque(reached_B)
    while queue:
        j=queue.popleft()
        for i in edges[j]:
            if i in reached_A:continue
            reached_A.add(i);nxt=mate_A[i]
            assert nxt>=0
            if nxt not in reached_B:reached_B.add(nxt);queue.append(nxt)
    return matching,reached_A,reached_B


def edge_curvature(adj,x,y,k,data,allow_small_order=False):
    h,common,_=data;n=len(adj)
    if len(adj[x])>len(adj[y]):x,y=y,x
    a,b=len(adj[x]),len(adj[y]);d=b-a;R=set(common[x][y])
    beta=1+len(h[x])-len(R);alpha=1+len(h[y])-len(R);c=a-alpha
    large=n>=k*k+k+2;bk=max(k+1,2*k-2)
    if not large and not allow_small_order:return None
    hall_upper=(bk-beta)*a+d*(k-1)
    if k==1 or hall_upper<=0 or (large and (beta>bk or d>=k)):
        return Fraction(c,b),{'shortcut':True,'large_order':large,
            'common_rows_materialized':0,'solver':'star_matching'}
    if a<=d*(k-1):return None
    A=sorted({y}|(h[y]-h[x]));B=sorted({x}|(h[x]-h[y]));Bset=set(B)
    masks={};bad=[]
    for u in A:
        masks[u]=set(t for t in common[x][u] if t in Bset)
        for t in masks[u]:
            if n-len(h[u])-len(h[t])+len(common[u][t])==0:bad.append((u,t))
    rows={u for u,t in bad};cols={t for u,t in bad}
    if len(rows)>1 and len(cols)>1:return None
    outside=set(A)|Bset|R

    def deficiency(targets):
        targets=sorted(targets)
        edges=[[i for i,u in enumerate(A) if u in adj[t]] for t in targets]
        nu,reached_A,reached_B=_matching(edges,alpha)
        ell=len(targets)-nu-d
        if ell<0:
            return 0,{'matching_size':nu,'ell':ell,'S0':[],
                'delta':0,'negative_max_slope':True}
        S0={targets[j] for j in reached_B};p0=alpha-len(reached_A);q0=0
        assert len(S0)-len(reached_A)-d==ell
        if d and S0 and x not in S0:
            assert len(S0)>=2
            s,t=sorted(S0)[:2]
            q0=sum(u not in outside and all(v in h[u] for v in S0)
                for u in common[s][t])
        if x in S0:assert S0==Bset and p0==0 and ell==0
        delta=a*ell+d*(p0+q0)
        assert delta>=0
        return delta,{'matching_size':nu,'ell':ell,'S0':sorted(S0),
            'p0':p0,'q0':q0,'delta':delta,'negative_max_slope':False}

    delta,full=deficiency(B)
    gap=delta;kind='one_two_cost';restricted=None;baseline=None
    if bad and len(cols)==1:
        kind='cost_three_column_star'
    elif bad:
        kind='cost_three_row_star';z=next(iter(rows));Z={t for u,t in bad}
        baseline=b-a*(beta-len(masks[z]))
        correction=d if (d>0 and len(masks[z])==beta-1 and set(full['S0'])<=Z) else 0
        gap=delta+correction
        restricted={'computed':False,'single_matching_criterion':True,
            'canonical_set_inside_cost_three_targets':set(full['S0'])<=Z,
            'sole_cost_one_target_is_anchor':len(masks[z])==beta-1,
            'extra_correction':correction}
    return Fraction(c,b)-Fraction(gap,a*b),{
        'shortcut':False,'large_order':large,'solver':'star_matching',
        'case':kind,'exclusive_sources':alpha,'targets':beta,
        'cost_three_pairs':sorted(bad),'unrestricted':full,
        'restricted':restricted,'row_star_baseline':baseline,
        'scaled_extra_cost':gap,'scaled_hall_deficit':delta,
        'common_rows_materialized':0,'dominance_margin':a-d*(k-1),
        'certificate_scope':'matching and counted Hall witnesses; no materialized full transport plan'}


def all_curvatures(adj,k):
    data=preprocess(adj,k);values={};stats=[]
    for x in range(len(adj)):
        for y in range(x+1,len(adj)):
            if y not in adj[x]:continue
            result=edge_curvature(adj,x,y,k,data)
            if result is None:
                value,meta=general_edge(adj,x,y,k,data)
                meta['star_fallback']=True
            else:value,meta=result
            values[x,y]=value;stats.append(meta)
    return values,{'edges':len(values),'shortcuts':sum(s['shortcut'] for s in stats),
        'star_fallbacks':sum(s.get('star_fallback',False) for s in stats),
        'star_solves':sum(not s['shortcut'] and s.get('solver')=='star_matching' for s in stats),
        'neighbor_pair_updates':data[2]}
