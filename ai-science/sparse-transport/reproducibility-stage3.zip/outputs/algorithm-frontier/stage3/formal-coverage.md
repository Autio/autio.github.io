# What the Lean checks establish

Lean 4.19.0 / Mathlib v4.19.0. Each accepted declaration has only standard
`propext`, `Classical.choice` and `Quot.sound` dependencies. These formalizations
corroborate portions of the handwritten argument; they are not new Hall,
matching, transport-duality or order-theory results in isolation.

| Layer | Checked statement | Remaining boundary |
|---|---|---|
| Graph witness counts | Actual finite graph neighborhood sets satisfy the target/excluded-source/codegree constraints | Curvature is not an input to those counting theorems |
| Localization | Actual graph positive Hall witnesses give the scalar/small-side/order consequences | Runtime of constructing those sets is a separate argument |
| Quantitative cutoff | GraphQuantitative derives F≤k²+k+2−n from actual graph sets and negative slope | Extremal graph realization is still handwritten |
| Codegree two | Every actual positive witness has size two, p=1,q=0,alpha=2,beta=3,d=1 and numerator one, at every graph order | The pendant/nonpendant curvature value and explicit optimal plan are handwritten |
| Boundary | Numerical types, graph saturation and two-step paths at the cutoff | Complete curvature deficit and universal-vertex repair are not end-to-end formalized |
| Weighted Hall | Integer weighted Hall is equivalent to an allowed unit-clone bijection | This is classical background using Mathlib's finite Hall theorem |
| Real transport | A real supported matrix with integer marginals exists iff weighted Hall holds; attaining the real unit baseline is equivalent to an allowed clone bijection | General higher-cost minimum-transport integrality is not proved |
| Actual graph baseline | No positive graph Hall defect iff a real residual matrix attains its unit baseline, for supplied positive costs whose cost-one pairs are graph edges | Actual graph-distance cost hypotheses and metric common-mass cancellation are not instantiated |
| Canonical set | Finite-relation slope supermodularity and least maximum-slope set; GraphCanonical derives the positive-competitor bound and weighted maximizer from actual graph codegree/orientation/dominance assumptions | Alternating-path program correctness is not proved |
| Restricted star criterion | Restricted maximum and the conditional row correction from the least maximizer, dominance and an explicit margin | The graph-derived margin and nested transport duality are not assumed proved by that module |
| Distance-three structure | Four-codegree cover and bipartite star consequence | Its complete transport evaluation remains a handwritten proof |

The separate Python dual verifier checks full actual graph distances, every
residual dual inequality and the exact reported objective on its finite suite.
It deliberately scans full common neighborhoods and is outside the fast
algorithm and its benchmark clock. A feasible dual alone is a lower bound on
transport cost; it does not supply a full primal plan. Independent full
transport supplies an optimum comparison for the tested instances.

The paper's universal matching implementation, graph-distance metric reduction,
complete boundary realization/repair, nested dual identity and complexity
theorem remain outside a single end-to-end Lean theorem. Neither partial formal
proofs nor finite checks establish priority, significance or expert acceptance.
