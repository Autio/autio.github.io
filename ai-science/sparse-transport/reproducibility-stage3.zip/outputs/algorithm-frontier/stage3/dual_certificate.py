"""Independent, deliberately full-size dual checks for star-transport outputs.

This optional verifier scans the actual common neighborhood and computes graph
distances by BFS. It is NOT part of the parameterized fast algorithm, its runtime
bound, or a materialized primal certificate. A feasible dual proves a lower bound
on transport cost; the test runner separately compares with full exact transport.

Run directly to write ../stage3-dual-certificate-check.json. No solver, benchmark,
manuscript, or release-package files are modified. Python standard library only.
"""
from collections import Counter, deque
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import hashlib
import json
import platform
import sys
import time


HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def residual(adj, x, y):
    """Compute actual open-neighborhood marginals, without production indexes."""
    require(y in adj[x] and x in adj[y], "The marked pair must be an edge")
    if len(adj[x]) > len(adj[y]):
        x, y = y, x
    a, b = len(adj[x]), len(adj[y])
    A = set(adj[x]) - set(adj[y])
    B = set(adj[y]) - set(adj[x])
    C = set(adj[x]) & set(adj[y])
    weights = {u: b if u in A else b-a for u in A | C}
    costs = {}
    for u in weights:
        distance = {u: 0}
        queue = deque([u])
        while queue:
            v = queue.popleft()
            for t in adj[v]:
                if t not in distance:
                    distance[t] = distance[v] + 1
                    queue.append(t)
        require(B <= distance.keys(), "Unreachable residual target")
        for t in B:
            costs[u, t] = distance[t]
    M = a * len(B)
    require(sum(weights.values()) == M, "Residual marginal mass mismatch")
    return {"x": x, "y": y, "a": a, "b": b, "A": A, "B": B,
            "C": C, "weights": weights, "costs": costs, "M": M}


def check_labels(problem, source_labels, target_labels, expected_objective):
    """Check every actual residual constraint and the exact integer objective."""
    require(set(source_labels) == set(problem["weights"]), "Wrong source domain")
    require(set(target_labels) == problem["B"], "Wrong target domain")
    require(all(type(v) is int for v in [*source_labels.values(),
                                       *target_labels.values()]),
            "Labels must be integers")
    require(target_labels[problem["x"]] == 0, "Anchor target must have label zero")
    minimum_slack = None
    for (u, t), cost in problem["costs"].items():
        slack = cost - source_labels[u] + target_labels[t]
        require(slack >= 0, f"Dual constraint violated at {(u, t)}")
        minimum_slack = slack if minimum_slack is None else min(minimum_slack, slack)
    objective = sum(problem["weights"][u] * f for u, f in source_labels.items())
    objective -= problem["a"] * sum(target_labels.values())
    require(objective == expected_objective,
            f"Objective {objective} differs from claimed {expected_objective}")
    return {"objective": objective, "constraints_checked": len(problem["costs"]),
            "minimum_slack": minimum_slack,
            "zero_supply_sources_checked": sum(w == 0 for w in problem["weights"].values())}


def certify(adj, x, y, metadata, reported_curvature=None):
    """Build labels from S0 and check them against full actual graph distances.

    Shortcut outputs have no S0; their baseline lower-bound certificate uses the
    empty set. No claim that this alone proves a shortcut's equality is made.
    """
    problem = residual(adj, x, y)
    A, B, costs = problem["A"], problem["B"], problem["costs"]
    sources = set(problem["weights"])
    shortcut = bool(metadata.get("shortcut", False))
    S0 = set() if shortcut else set(metadata["unrestricted"]["S0"])
    require(S0 <= B, "S0 is not a target subset")
    gap = 0 if shortcut else metadata["scaled_extra_cost"]
    delta = 0 if shortcut else metadata["scaled_hall_deficit"]
    require(type(gap) is int and gap >= 0, "Expected nonnegative integer excess")
    excluded = {u for u in sources if all(costs[u, t] > 1 for t in S0)}
    center = None
    if gap > delta:
        require(bool(S0), "Strict correction requires nonempty S0")
        bad = {(u, t) for (u, t), cost in costs.items() if cost == 3}
        centers = {u for u, t in bad}
        require(len(centers) == 1, "Strict correction requires a single cost-three row")
        center = next(iter(centers))
        require(center in A, "Strict row center must be exclusive")
        Z = {t for u, t in bad if u == center}
        require(S0 <= Z, "S0 is not inside the center's cost-three targets")
        Q = B - {problem["x"]}
        require(all(costs[center, t] > 1 for t in Q),
                "Strict center has a second cost-one target")
        g = {t: -2 if t in S0 else (-1 if t in Q else 0) for t in B}
        f = {u: -1 + int(u in excluded) + int(u == center) for u in sources}
        construction = "strict_row_nested_labels"
    else:
        g = {t: -1 if t in S0 else 0 for t in B}
        f = {u: int(u in excluded) for u in sources}
        construction = "ordinary_hall_labels" if not shortcut else "shortcut_baseline_only"
    # S0=B gives g_x=-1 in the ordinary construction. A simultaneous shift
    # preserves every difference and the objective because marginals balance.
    shift = -g[problem["x"]]
    f = {u: label+shift for u, label in f.items()}
    g = {t: label+shift for t, label in g.items()}
    expected = problem["M"] + gap
    checked = check_labels(problem, f, g, expected)
    if reported_curvature is not None:
        require(Fraction(problem["a"] * problem["b"]) * (1-reported_curvature) == expected,
                "Reported curvature and dual objective disagree")
    return {**checked, "construction": construction, "oriented_edge": [problem["x"], problem["y"]],
            "a": problem["a"], "b": problem["b"], "M": problem["M"],
            "extra_cost": gap, "S0": sorted(S0), "row_center": center,
            "anchor_normalization_shift": shift,
            "source_labels": f, "target_labels": g,
            "common_sources_scanned": len(problem["C"])}


def run():
    # Import production only for outputs under test. Certificate construction
    # above does not call its matching, masks, pair tables, or distance formula.
    import star_transport as star
    sys.path.insert(0, str(HERE.parent.parent / "frontier-scan"))
    from curvature_probe import complement, connected, transport

    start = time.perf_counter()
    counts = Counter()
    examples = {}
    by_order = []
    tamper_example = None
    for n in range(2, 6):
        order_counts = Counter()
        pairs = list(combinations(range(n), 2))
        for mask in range(1 << len(pairs)):
            adj = complement(n, [edge for j, edge in enumerate(pairs) if mask >> j & 1])
            if not connected(adj):
                continue
            counts["connected_graphs"] += 1
            order_counts["connected_graphs"] += 1
            h = [set(range(n)) - {u} - adj[u] for u in range(n)]
            k = max(1, max(len(h[u] & h[v]) for u, v in pairs))
            data = star.preprocess(adj, k)
            for x, y in pairs:
                if y not in adj[x]:
                    continue
                result = star.edge_curvature(adj, x, y, k, data, allow_small_order=True)
                if result is None:
                    counts["ineligible_edges"] += 1
                    order_counts["ineligible_edges"] += 1
                    continue
                value, meta = result
                certificate = certify(adj, x, y, meta, value)
                require(value == transport(adj, x, y), "Independent full transport disagreement")
                counts["certified_edges"] += 1
                order_counts["certified_edges"] += 1
                counts["dual_constraints"] += certificate["constraints_checked"]
                counts["common_sources_scanned"] += certificate["common_sources_scanned"]
                counts[certificate["construction"]] += 1
                counts["empty_S0"] += not certificate["S0"]
                counts["anchor_normalized"] += bool(certificate["anchor_normalization_shift"])
                if not meta["shortcut"]:
                    counts[meta["case"]] += 1
                key = certificate["construction"] if meta["shortcut"] else meta["case"]
                if certificate["construction"] == "strict_row_nested_labels":
                    key = "strict_row_nested_labels"
                examples.setdefault(key, {"n": n, "complement_mask": mask, "k": k,
                                          "curvature": str(value), "certificate": certificate})
                if tamper_example is None and certificate["S0"]:
                    tamper_example = (adj, x, y, certificate)
        by_order.append({"n": n, **order_counts})
        print(json.dumps(by_order[-1]), flush=True)

    large = []
    for c in (3, 10, 50, 200):
        S = [3, 4]
        C = list(range(5, 5+c))
        n = 5+c
        adj = complement(n, [(2, v) for v in [1]+S+C] + [(0, v) for v in S])
        value, meta = star.edge_curvature(adj, 0, 1, 2, star.preprocess(adj, 2))
        certificate = certify(adj, 0, 1, meta, value)
        require(certificate["construction"] == "strict_row_nested_labels", "Expected strict row case")
        require(value == transport(adj, 0, 1), "Large full transport disagreement")
        large.append({"n": n, "curvature": str(value), "certificate": certificate})
        print(json.dumps({"large_row_n": n, "verified": True}), flush=True)

    # Exercise the ordinary construction at a strictly positive Hall deficit,
    # rather than relying only on the baseline/strict-row cases of tiny graphs.
    from verify import cubic_family
    ordinary_large = []
    for k in (5, 8):
        adj, _ = cubic_family(k)
        value, meta = star.edge_curvature(adj, 0, 1, k, star.preprocess(adj, k))
        certificate = certify(adj, 0, 1, meta, value)
        require(certificate["construction"] == "ordinary_hall_labels" and
                certificate["extra_cost"] == k-1, "Expected positive ordinary deficit")
        require(value == transport(adj, 0, 1), "Ordinary large full transport disagreement")
        ordinary_large.append({"n": len(adj), "k": k, "curvature": str(value),
                               "certificate": certificate})

    # Negative controls test verifier sensitivity, not the solver implementation.
    adj, x, y, cert = tamper_example
    problem = residual(adj, x, y)
    rejected = []
    for name in ("wrong_objective", "violated_constraint", "missing_source"):
        f, g, objective = dict(cert["source_labels"]), dict(cert["target_labels"]), cert["objective"]
        if name == "wrong_objective":
            objective += 1
        elif name == "violated_constraint":
            f[next(iter(f))] += len(adj)+3
        else:
            del f[next(iter(f))]
        try:
            check_labels(problem, f, g, objective)
        except ValueError as error:
            rejected.append({"mutation": name, "rejection": str(error)})
        else:
            raise RuntimeError(f"Verifier accepted negative control: {name}")

    result = {"passed": True, "counts": dict(counts), "by_order": by_order,
              "examples": examples, "large_row_controls": large,
              "large_ordinary_controls": ordinary_large, "negative_controls": rejected,
              "seconds": time.perf_counter()-start, "python": platform.python_version(),
              "platform": platform.platform(),
              "source_sha256": {str(path.relative_to(HERE.parent.parent)): hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in (Path(__file__), HERE / "star_transport.py",
                                             HERE.parent.parent / "frontier-scan" / "curvature_probe.py")},
              "scope": "All connected labeled graphs of orders 2 through 5: every edge eligible for the optional star backend, including equality shortcuts, checked by full actual residual dual constraints and independent original-measure exact transport. Ineligible edges skipped. Four pendant-row controls of orders 8,15,55,205 and two positive-deficit cubic controls (k=5,8) also compared with independent full transport. Coverage overlaps earlier suites; no new benchmark or independent human review.",
              "limitations": "The certificate alone gives a lower bound on residual transport cost (upper bound on curvature). No primal plan is constructed by this verifier. Independent full transport supplies an optimum comparison for these tests only. The verifier scans all common sources and runs BFS; its work is excluded from the claimed fast algorithm and runtime. Production code, benchmarks, manuscript and release packages are unchanged."}
    destination = HERE.parent / "stage3-dual-certificate-check.json"
    destination.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"passed": True, "counts": dict(counts), "seconds": result["seconds"],
                      "output": str(destination)}), flush=True)


if __name__ == "__main__":
    run()
