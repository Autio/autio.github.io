"""Build a stage-three revision without altering the approved stage-two ZIP."""
from pathlib import Path
root=Path(__file__).resolve().parent
previous=root.parent/'manuscript/main.tex'
out=root/'manuscript';out.mkdir(exist_ok=True)
s=previous.read_text(encoding='utf-8')
s=s.replace('A weighted Hall obstruction with negative leading coefficient exists only when $n\\le k^2+k+1$; this cutoff is sharp.', 'A weighted Hall obstruction with negative leading coefficient has numerator at most $k^2+k+2-n$, so it exists only when $n\\le k^2+k+1$; the bound is sharp for $k\\ge3$. At the boundary there are exactly two numerical witness types, the curvature deficit is $1/(ab)$, and one universal vertex restores equality.')
s=s.replace('The order cutoff and, for $k\\ge3$, the persistent bound $\\beta\\le2k-2$ are sharp.', 'For $k\\ge3$, the order cutoff and the persistent bound $\\beta\\le2k-2$ are sharp. For $k=2$ no negative-slope deficient witness exists.')
s=s.replace('The triangle bound is $\\kappa_0(x,y)\\le c/b$.', 'The established triangle bound is $\\kappa_0(x,y)\\le c/b$~\\cite{jostliu}.')
marker='Successive shortest-path min-cost flow, feasible potentials, blocking flows, unbalanced-network analysis'
addition=r'''Li and Lu~\cite{lilu}, Corollaries 2--3, already characterize equality in an LLY upper bound by unequal-degree weighted Hall conditions. Relative to our scaled residual, their LLY problem removes target $x$ of demand $a$ and reduces source $y$ from $b$ to $d$; for each nonempty $S\subseteq B\setminus\{x\}$ its Hall numerator is $F(S)+a$, rather than $F(S)$. Weighted Hall and this two-weight pattern are established machinery. Asai and Yamada~\cite{asaiyamada} directly study zero-idleness triangle equality for complements of matchings, stars under their size condition, and cycles $C_m$ with $3\le m\le n-1$. These special-family results are relevant predecessors, not the general cutoff claimed here.

The extremal constructions also need explicit attribution: the persistent example is exactly a member of the four-block family in Chen--Liu--You, Section~6~\cite{chen}; the finite-cutoff example modifies that template. The unmodified family already gives a transient zero-idleness defect at $n=k^2+k-1$, as calculated in the accompanying priority audit. The proposed sharp inequality and boundary analysis must be assessed against that close overlap.

'''
assert marker in s;s=s.replace(marker,addition+marker)
s=s.replace('A deficient Hall set with $L<0$ can occur only if\n\\[\n n\\le k^2+k+1.\n\\]', 'Every deficient Hall set with $L<0$ satisfies\n\\[\n F\\le k^2+k+2-n,\\qquad n\\le k^2+k+1.\n\\]\nFor $k=2$ no such set exists.')
marker='Adding $r\\le k$ proves the order bound.'
addition=r'''Adding $r\le k$ proves the order bound. More precisely, with $N=k^2+k+1$, direct expansion gives the slack identity
\begin{equation}\label{eq:slack}
 N+1-n-F=\bigl[N-((e+1)s+p+r)\bigr]
 +e(\alpha-p-1)+(u-1)(h-1).
\end{equation}
All terms on the right are nonnegative. This proves $F\le N+1-n$; for $p\ge2$ the first term is at least two, giving $F\le N-1-n$. If $k=2$, the earlier inequality $hu\le e(s-1)-1\le0$ contradicts $h,u\ge1$.'''
assert marker in s;s=s.replace(marker,addition)
marker='For sharpness of the order cutoff, take'
boundary=r'''\begin{proposition}[Numerical boundary types and one-vertex repair]\label{prop:boundary}
Let $k\ge3$, $n=k^2+k+1$, and suppose an edge has a deficient Hall set with $L<0$. Then
\[
 r=s=k,\quad p=1,\quad q=k-2,\quad\alpha=2,\quad F=1,\quad b=k^2-1,
\]
and exactly one of the following numerical types holds:
\[
 (a,\beta,L)=(k,k^2-k+1,-k(k-2)),\qquad
 (k^2-k-1,k+2,-1).
\]
The deficient target set is unique. All residual costs are at most two,
$\kappa_0(x,y)=c/b-1/(ab)$, and adjoining one universal vertex restores triangle equality at the marked edge. This is not a uniqueness assertion about the whole graph.
\end{proposition}
\begin{proof}
At $n=N$, equation~\eqref{eq:slack} and the integer inequality $F\ge1$ force $F=1$ and all three nonnegative slack terms to vanish. The branch $p\ge2$ is impossible. In the other branch, equality in $(e+1)s+p+r\le k^2+k+1$ forces $p=1$, $e=k-1$, $s=r=k$. Since $e>0$, we get $\alpha=2$. Also $(u-1)(h-1)=0$ and $uh=k(k-2)$, so either $u=1,h=k(k-2)$ or $h=1,u=k(k-2)$. Substitution gives the two types and $b=k^2-1$.

Write $A=\{y,z\}$. The pair $x,z$ already has all $k$ vertices of $S$ as common $H$-neighbors. Hence $z$ sees every vertex of $R$ and every target outside $S$ in $G$. For $t\in S$, the pair $y,t$ has $z$ as a common $H$-neighbor, and cannot also have all $k$ vertices of $R$. Some $r_t\in R$ therefore gives a length-two $G$-path $z,r_t,t$. Common-source exceptions have distance two through $y$, and $y$ sees every target. Thus every residual cost is at most two.

Any positive Hall witness has $p\le1$ and $s\le k$, while $\beta\ge k+2$, so it too has negative slope and numerator one by the same argument. Its excluded exclusive source must be $z$ and its $k$ targets must be exactly $N_H(z)\cap B=S$. This proves witness uniqueness. The maximum cost-one flow leaves exactly one unit, which can be sent at cost two, giving the curvature formula.

Adjoin one universal vertex. For a nonempty fixed target set, the old counts $\alpha,\beta,d,p,q$ stay fixed, while $a$ increases by one, so its new numerator is $F+L$. Positive old numerators become $1+L\le0$. Every nonempty target set has $L\le0$: sets containing $x$ exclude no source; for other sets of size at most $k$ use $p\le1$ and $\beta\ge k+2$; larger sets exclude no source by codegree. Old nonpositive numerators therefore cannot increase. For the empty set the added common source is excluded too, and the deficit remains zero. Weighted Hall proves the asserted repair.
\end{proof}

'''
assert marker in s;s=s.replace(marker,boundary+marker)
s=s.replace('For sharpness of the order cutoff, take', 'For sharpness of the order cutoff, adapt the four-block template of Chen--Liu--You, Section~6~\\cite{chen}, as follows. Take')
marker='For persistent sharpness take disjoint sets'
addition=r'''The second boundary type is realized by the same complement edge pattern, with $|T|=1$ and $k(k-2)-1$ additional isolated $H$-vertices. More generally, taking $|T|=h$ and no padding, for $1\le h\le k(k-2)$, realizes equality $F=k^2+k+2-n$ at every integer order $3k+2\le n\le k^2+k+1$. The missing residual pairs have distance two through the nonempty set $T$, and the maximum Hall numerator occurs at $S$. Adding an $H$-edge inside $T$ in the first boundary type, or inside the isolated padding set in the second, preserves the boundary parameters and gives different graph edge counts. Proposition~\ref{prop:boundary} does not classify all extremal graphs up to isomorphism.

For persistent sharpness, use an exact member of Chen--Liu--You's Section~6 family~\cite{chen}. Take disjoint sets'''
assert marker in s;s=s.replace(marker,addition)
s=s.replace('No public artifact URL is claimed in this draft.', 'The previous-stage public review draft is available at \\url{https://github.com/Autio/autio.github.io/pull/2}; the separately versioned stage-three materials record the current corrections and checks. A draft pull request is not an arXiv submission or independent review.')
s=s.replace('and the new scalar-filter arithmetic. The latter was checked by the Lean kernel without', 'the scalar-filter arithmetic, and the new graph-valued bridge from actual neighborhood sets to the cutoff, small-side and persistent consequences. Separate files check conditional boundary and slack arithmetic. These were checked by the Lean kernel without')
s=s.replace('The complete graph interpretation of the scalar filter, curvature-to-transport reduction, primal-network construction, runtime analysis, and manuscript have not been formalized end to end.', 'The curvature-to-transport/Hall reduction, extremal graph realization, exact boundary transport and one-vertex repair, primal-network construction, runtime analysis, and manuscript have not been formalized end to end.')
references=r'''\bibitem{jostliu}
J.~Jost and S.~Liu.
\emph{Ollivier's Ricci curvature, local clustering and curvature dimension inequalities on graphs}.
Discrete Comput. Geom. 51 (2014), 300--322; arXiv:1103.4037v3.
\url{https://arxiv.org/abs/1103.4037v3}.

\bibitem{lilu}
Y.~Li and L.~Lu.
\emph{Ricci Curvature Formula: Applications to Bonnet--Myers Sharp Irregular Graphs}.
arXiv:2409.15667v2, 2024.
\url{https://arxiv.org/abs/2409.15667v2}.

\bibitem{asaiyamada}
Y.~Asai and T.~Yamada.
\emph{Ollivier Ricci curvature on graphs obtained by removing edges from complete graphs}.
arXiv:2605.30830v2, 2026.
\url{https://arxiv.org/abs/2605.30830v2}.

'''
s=s.replace('\\bibitem{kelly}',references+'\\bibitem{kelly}')
# Distinguish the retained general network design from the stronger final hybrid.
s=s.replace('{thm:main}','{thm:network}')
old_abstract=s[s.index('\\begin{abstract}')+len('\\begin{abstract}'):s.index('\\end{abstract}')]
new_abstract=r'''
Let $G$ be a connected simple graph whose complement has pair codegree at most $k$. We study equality in the triangle upper bound for zero-idleness Ollivier curvature. A negative-slope weighted Hall obstruction has numerator at most $k^2+k+2-n$, giving a sharp cutoff at $n=k^2+k+1$ for $k\ge3$. At the boundary there are two numerical witness types, exact curvature deficit $1/(ab)$, and repair by one universal vertex. Above the cutoff, every defective edge has $\Oh(k)$ exclusive targets. Two disjoint distance-three pairs would force $n\le4k$, so the large-order residual cost-three support is a star. A canonical maximum-slope Hall set, obtained from one ordinary matching, evaluates the full weighted deficit and its distance-three correction without constructing common-source rows. This gives $\Oh(k^3)$ work per large-order candidate after indexed preprocessing. An implemented all-orders hybrid uses $\Oh(k^5n^2)$ word-RAM operations; a classical small-vertex-cover flow substitution gives the theoretical bound $\Oh(k^4n^2)$. The counting, Hall, matching and flow machinery receive explicit prior-art credit. Exact checks and partial Lean formalization corroborate the arguments. Native transport wins the generic solver benchmarks, while structural reductions help selected dense all-edge workloads; cold indexing can lose badly for small query batches. Priority and independent human review remain unresolved.
'''
s=s.replace(old_abstract,new_abstract)
marker='\\begin{corollary}[Exact all-edge computation]'
intro=r'''\begin{corollary}[Matching hybrid]\label{thm:main}
For $k\ge2$, under condition~\eqref{eq:codegree}, all edge values can be computed exactly in $\Oh(k^5n^2)$ word operations by the implemented matching/dense-Dinic hybrid. For $n\ge k^2+k+2$, the matching branch, together with a fixed-size fallback at $k=2,n=8$, takes $\Oh(k^3n^2)$ including preprocessing. Replacing only the small-order flow backend by the classical AOST specialized algorithm gives the theoretical all-orders bound $\Oh(k^4n^2)$, with $\Oh(kn^2)$ words of space and unreduced output. The latter backend is unimplemented. The proof is in Section~\ref{sec:star}; no optimal or best-known $k$ exponent is claimed. The $k=1$ triangle-equality case takes $\Oh(n^2)$.
\end{corollary}

The direct network design below remains a separately verified baseline and fallback. The final matching reduction avoids its common-source rows at large order.

'''
assert marker in s;s=s.replace(marker,intro+'\\begin{corollary}[Direct network design]')
s=s.replace('This specialization does not extend to the distance-three example above and is not needed for the general all-edge bound.', 'Using the Hall deficit alone fails on the distance-three example above. Section~\\ref{sec:star} supplies the exact star correction and extends matching to every large-order candidate.')
marker='\\section{Cubic row counts on defective edges}'
assert marker in s;s=s.replace(marker,(root/'star-section.tex').read_text(encoding='utf-8')+'\n'+marker)
s=s.replace('Ahuja--Orlin--Stein--Tarjan\'s specialized FIFO', 'the specialized FIFO algorithm of Ahuja, Orlin, Stein and Tarjan, namely the')
s=s.replace('The theorem uses only ordinary Dinic, as does the current implementation. Specialized flow solvers for unbalanced networks may further improve the dependence on $k$ or remove the representation logarithm. The published abstract of~\\cite{aost} gives relevant stronger bounds, but their complete applicability is not audited here and no stronger headline bound is claimed.', 'This direct-network baseline uses ordinary Dinic. The final hybrid in Section~\\ref{sec:star} replaces large-order networks by matching and audits the classical AOST small-vertex-cover bound for a theoretical small-order substitution. The AOST backend remains unimplemented; neither its bound nor ordinary Dinic is a new general flow method.')
bench=(root/'benchmark-section.tex').read_text(encoding='utf-8')
s=s.replace('\\section{Research status and AI assistance}',bench+'\n\\section{Research status and AI assistance}')
docs=r'''\bibitem{nxdoc}
NetworkX developers. \emph{network\_simplex documentation}, accessed 21 October 2026.
\url{https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.flow.network_simplex.html}.

\bibitem{scipydoc}
SciPy developers. \emph{HiGHS linear programming and linear\_sum\_assignment documentation}, accessed 21 October 2026.
\url{https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html};
\url{https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linear_sum_assignment.html}.

\bibitem{potdoc}
POT developers. \emph{Python Optimal Transport: ot.emd documentation}, accessed 21 October 2026.
\url{https://pythonot.github.io/all.html#ot.emd}.

'''
s=s.replace('\\bibitem{kelly}',docs+'\\bibitem{kelly}')
s=s.replace('The order cutoff, the bound', 'The order cutoff, the bound')
s=s.replace('the resulting endpoint bound $d_H(x),d_H(y)\\le3k-3$ are sharp.', 'the common endpoint bound $d_H(x),d_H(y)\\le3k-3$ are sharp, with the endpoint bound attained at $x$.')
s=s.replace('The curvature-to-transport/Hall reduction, extremal graph realization, exact boundary transport and one-vertex repair, primal-network construction, runtime analysis, and manuscript have not been formalized end to end.', 'New files also check weighted Hall by cloning, its specialization to actual graph residual masses, boundary neighborhood types and two-step paths, and the four-codegree cover. Integer clone transport attains its unit-cost lower bound exactly when the graph Hall inequalities hold. The metric common-mass cancellation, real/rational integrality bridge, complete boundary transport and repair, nested dual identity, full matching algorithm, runtime analysis, and manuscript remain outside an end-to-end formal proof.')
s=s.replace('Test success and partial formalization must not be described as a machine-checked proof of Corollary~\\ref{thm:network}.', 'Test success and partial formalization must not be described as a machine-checked proof of Corollary~\\ref{thm:main} or the complete manuscript.')
s=s.replace('Author-institution record:', 'Theorem~5.2 and Section~8; primary report:\n\\url{https://www.cs.princeton.edu/techreports/1991/338.pdf}.\nAuthor-institution record:')
(out/'main.tex').write_text(s,encoding='utf-8')
print(out/'main.tex')
