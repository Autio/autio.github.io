"""Independent target-subset cross-check of the sharp boundary claim.

Builds the forced complement core directly, randomly adds admissible edges,
and enumerates EVERY target subset before and after universal-vertex padding.
The old full-neighborhood transport solver supplies a separate curvature check.
This is finite corroboration, not exhaustive graph verification.
"""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'frontier-scan'))
from curvature_probe import transport


def core(k, large_target):
    n = k*k+k+1
    a = k if large_target else k*k-k-1
    beta = n-k-a
    # x,y,z; k targets; remaining targets; k outside vertices; common vertices.
    S = set(range(3, 3+k))
    T = set(range(3+k, 2+beta))
    R = set(range(2+beta, 2+beta+k))
    C = set(range(2+beta+k, n))
    W = set(sorted(C)[:k-2])
    assert len(C) == a-2 and len(T) == beta-k-1
    H = [set() for _ in range(n)]
    edges = {(0,t) for t in S|T|R} | {(1,t) for t in R|{2}}
    edges |= {(w,t) for w in W|{2} for t in S}
    for u,v in edges:
        H[u].add(v); H[v].add(u)
    return H, S


def hall_scan(G):
    a,b = len(G[0]),len(G[1])
    A,B,C = G[0]-G[1],G[1]-G[0],G[0]&G[1]
    targets = sorted(B)
    maximum,positive,scans,llymax = 0,[],0,0
    for mask in range(1 << len(targets)):
        S = {v for j,v in enumerate(targets) if mask & (1 << j)}
        # Direct neighbor-source sum; not the manuscript's expanded F formula.
        supplied = sum(b if u in A else b-a for u in G[0] if G[u]&S)
        deficiency = a*len(S)-supplied
        maximum = max(maximum,deficiency)
        if deficiency > 0:
            positive.append(sorted(S))
        if S and 0 not in S:
            lly_supply = sum(b if u in A-{1} else b-a
                             for u in G[0] if G[u]&S)
            lly_deficiency = a*len(S)-lly_supply
            assert lly_deficiency == deficiency+a
            llymax = max(llymax,lly_deficiency)
        scans += 1
    return maximum,positive,scans,llymax


def run():
    start = time.perf_counter()
    rng = random.Random(2026102108)
    records = []
    for k in (3,4):
        for large_target in (False,True):
            for trial in range(10):
                H,S = core(k,large_target)
                n = len(H)
                pairs = list(combinations(range(n),2))
                additions = [(u,v) for u,v in pairs if u>=2 and v>=2 and v not in H[u]]
                rng.shuffle(additions)
                accepted = 0
                for u,v in additions:
                    if rng.random() > .6:
                        continue
                    H[u].add(v); H[v].add(u)
                    if max(len(H[i]&H[j]) for i,j in pairs) > k:
                        H[u].remove(v); H[v].remove(u)
                    else:
                        accepted += 1
                G = [set(range(n))-{i}-H[i] for i in range(n)]
                a,b = len(G[0]),len(G[1])
                c = len(G[0]&G[1])
                before,positive,scans,llymax = hall_scan(G)
                assert before == 1 and positive == [sorted(S)]
                assert llymax == a+1
                for u in G[0]:
                    for t in G[1]-G[0]:
                        assert t in G[u] or G[u]&G[t]
                actual = transport(G,0,1)
                assert actual == Fraction(c,b)-Fraction(1,a*b)
                padded = [N|{n} for N in G]+[set(range(n))]
                after,positive_after,more_scans,_ = hall_scan(padded)
                assert after == 0 and not positive_after
                repaired = transport(padded,0,1)
                assert repaired == Fraction(c+1,b+1)
                records.append(dict(k=k,large_target=large_target,trial=trial,
                                    accepted_H_edges=accepted,a=a,b=b,
                                    target_subset_scans=scans+more_scans,
                                    unique_positive_target=positive[0],
                                    zero_idleness=str(actual),padded_zero_idleness=str(repaired),
                                    lly_from_Li_Lu_and_Hall=str(actual+Fraction(1,b))))
    result = dict(passed=True,seed=2026102108,graph_instances=len(records),
                  full_transport_comparisons=2*len(records),
                  target_subset_scans=sum(r['target_subset_scans'] for r in records),
                  seconds=time.perf_counter()-start,records=records,
                  scope='40 admissible boundary-core variations; exhaustive target subsets on each; not exhaustive graphs')
    path = HERE/'stage3-boundary-cross-checks.json'
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({key:value for key,value in result.items() if key!='records'}))


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Assertions must be enabled')
    run()
