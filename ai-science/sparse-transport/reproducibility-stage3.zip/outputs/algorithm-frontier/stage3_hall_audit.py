"""Independent bounded checks of sharp Hall-cutoff equality cases.

Run: python outputs/algorithm-frontier/stage3_hall_audit.py
Writes only stage3-hall-audit.json beside this script. Uses the original
full-neighborhood Bellman--Ford transport solver for numerical corroboration;
the arithmetic enumeration is a relaxation, not a graph-realizability test.
"""
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import platform
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'frontier-scan'))
from curvature_probe import transport, connected


def arithmetic_boundary(k):
    best = None
    maxima = []
    cases = 0
    for s in range(2, k + 1):
        for p in range(k):
            if p >= 2 and s == k:
                continue
            for q in range(k - p):
                e = p + q
                for alpha in range(p + 1, s + p):
                    # u=a-e >= alpha-p because c>=q.
                    u_min = alpha - p
                    budget = e * (s + p - alpha) - 1
                    for h in range(1, budget // u_min + 1):
                        u = budget // h
                        a = u + e
                        beta = s + p + h
                        F = (s + p - beta) * a + (beta - alpha) * e
                        assert F > 0 and a >= alpha + q and beta >= alpha
                        assert beta >= s + 1
                        n = a + beta + k
                        assert F <= k*k+k+2-n
                        if p >= 2:
                            assert F <= k*k+k-n
                        cases += 1
                        record = {'s': s, 'p': p, 'q': q, 'alpha': alpha,
                                  'a': a, 'beta': beta, 'u': u, 'h': h, 'F': F}
                        if best is None or n > best:
                            best, maxima = n, [record]
                        elif n == best:
                            maxima.append(record)
    if k == 2:
        assert best is None
    else:
        assert best == k * k + k + 1
        observed = {(r['a'], r['beta'], r['h']) for r in maxima}
        assert observed == {(k, k*k-k+1, k*(k-2)),
                            (k*k-k-1, k+2, 1)}
        assert len(maxima) == 2
        assert all(r['s'] == k and r['p'] == 1 and r['q'] == k-2
                   and r['alpha'] == 2 and r['F'] == 1 for r in maxima)
    return {'k': k, 'parameter_cases': cases, 'max_order': best,
            'boundary_types': maxima}


def boundary_family(k, kind, extra_isolate=False, add_internal_edge=False,
                    target_leaves=None):
    assert k >= 3 and kind in ('large_target', 'slope_minus_one')
    cursor = 3
    def vertices(count):
        nonlocal cursor
        answer = list(range(cursor, cursor + count))
        cursor += count
        return answer
    x, y, z = 0, 1, 2
    W = vertices(k - 2)
    S = vertices(k)
    T = vertices(target_leaves if target_leaves is not None else
                 (k * (k-2) if kind == 'large_target' else 1))
    R = vertices(k)
    P = vertices(0 if kind == 'large_target' else k * (k-2) - 1)
    if extra_isolate:
        vertices(1)
    h = [set() for _ in range(cursor)]
    def edge(u, v):
        h[u].add(v)
        h[v].add(u)
    for v in S + T:
        edge(x, v)
    for v in S + [y]:
        edge(z, v)
    for w in W:
        for s in S:
            edge(w, s)
    for r in R:
        edge(r, x)
        edge(r, y)
    if add_internal_edge:
        pool = T if kind == 'large_target' else P
        edge(pool[0], pool[1])
    adj = [set(range(cursor)) - {u} - h[u] for u in range(cursor)]
    return adj, h, set(S)


def check_quantitative_family(k, leaves):
    adj, h, S = boundary_family(k, 'large_target', target_leaves=leaves)
    n = len(adj)
    assert connected(adj)
    assert max(len(h[u] & h[v]) for u, v in combinations(range(n), 2)) == k
    a, b = len(adj[0]), len(adj[1])
    C = adj[0] & adj[1]
    B = adj[1] - adj[0]
    F = (len(S)+1-len(B))*a+(b-a)*(k-1)
    assert n == 3*k+1+leaves and a == k
    assert F == k*k+k+2-n and F > 0
    expected = Fraction(len(C), b)-Fraction(F, a*b)
    actual = transport(adj, 0, 1)
    assert actual == expected
    return {'k': k, 'target_leaves': leaves, 'n': n, 'a': a, 'b': b,
            'F': F, 'curvature': str(actual)}


def check_family(k, kind, padded, variant):
    adj, h, S = boundary_family(k, kind, padded, variant)
    n = len(adj)
    assert connected(adj)
    codegree = max(len(h[u] & h[v]) for u, v in combinations(range(n), 2))
    assert codegree == k
    A, B, C = adj[0] - adj[1], adj[1] - adj[0], adj[0] & adj[1]
    R = set(range(n)) - (adj[0] | adj[1])
    a, b, alpha, beta = len(adj[0]), len(adj[1]), len(A), len(B)
    p = sum(not (adj[u] & S) for u in A)
    q = sum(not (adj[u] & S) for u in C)
    L = len(S) + p - beta
    F = L * a + (b-a) * (p+q)
    assert alpha == 2 and p == 1 and q == k-2 and len(R) == k
    assert n == k*k+k+1+int(padded)
    assert F == (1+L if padded else 1)
    actual = transport(adj, 0, 1)
    expected = Fraction(len(C), b) - (Fraction(0) if padded else Fraction(1, a*b))
    assert actual == expected, (k, kind, padded, variant, actual, expected)
    return {'k': k, 'kind': kind, 'extra_isolate': padded,
            'internal_H_edge': variant, 'n': n, 'a': a, 'b': b,
            'beta': beta, 'L': L, 'F': F, 'max_codegree': codegree,
            'H_edges': sum(map(len, h)) // 2, 'curvature': str(actual)}


def check_random_modifications(k, kind, rng, trial):
    adj, h, S = boundary_family(k, kind)
    n = len(adj)
    original_a, original_b = len(adj[0]), len(adj[1])
    D = {u for u in range(n) if S <= h[u]}
    assert len(D) == k
    pairs = list(combinations(range(n), 2))
    allowed = [(u, v) for u, v in pairs if u not in (0, 1) and v not in (0, 1)
               and not ((u in D and v in S) or (v in D and u in S))]
    accepted = 0
    for _ in range(60):
        u, v = rng.choice(allowed)
        existed = v in h[u]
        if existed:
            h[u].remove(v); h[v].remove(u)
        else:
            h[u].add(v); h[v].add(u)
        valid = all(len(h[x] & h[y]) <= k for x, y in pairs)
        if valid:
            candidate = [set(range(n)) - {x} - h[x] for x in range(n)]
            valid = connected(candidate)
        if valid:
            accepted += 1
            adj = candidate
        elif existed:
            h[u].add(v); h[v].add(u)
        else:
            h[u].remove(v); h[v].remove(u)
    assert accepted > 0
    A, B, C = adj[0] - adj[1], adj[1] - adj[0], adj[0] & adj[1]
    a, b = len(adj[0]), len(adj[1])
    assert (a, b) == (original_a, original_b)
    p = sum(not (adj[u] & S) for u in A)
    q = sum(not (adj[u] & S) for u in C)
    assert p == 1 and q == k-2
    assert (len(S)+p-len(B))*a+(b-a)*(p+q) == 1
    # Independently verify the new distance-two conclusion on every row.
    for u in adj[0]:
        for target in B:
            assert target in adj[u] or (adj[u] & adj[target])
    expected = Fraction(len(C), b) - Fraction(1, a*b)
    actual = transport(adj, 0, 1)
    assert actual == expected
    padded = [neighbors | {n} for neighbors in adj] + [set(range(n))]
    repaired = transport(padded, 0, 1)
    assert repaired == Fraction(len(C)+1, b+1)
    return {'k': k, 'kind': kind, 'trial': trial,
            'accepted_toggles': accepted, 'H_edges': sum(map(len, h))//2,
            'curvature': str(actual), 'repaired_curvature': str(repaired)}


def run():
    start = time.perf_counter()
    arithmetic = [arithmetic_boundary(k) for k in range(2, 16)]
    families = []
    for k in range(3, 10):
        for kind in ('large_target', 'slope_minus_one'):
            for padded, variant in ((False, False), (True, False), (False, True)):
                families.append(check_family(k, kind, padded, variant))
        print(json.dumps({'k': k, 'full_transport_checks': len(families)}), flush=True)
    rng = random.Random(2026102106)
    modified = [check_random_modifications(k, kind, rng, trial)
                for k in range(3, 7)
                for kind in ('large_target', 'slope_minus_one')
                for trial in range(8)]
    quantitative = [check_quantitative_family(k, leaves)
                    for k in range(3, 10)
                    for leaves in range(1, k*(k-2)+1)]
    result = {'passed': True, 'python': platform.python_version(),
              'platform': platform.platform(),
              'arithmetic_relaxation': arithmetic,
              'family_checks': families,
              'random_modified_families': modified,
              'quantitative_families': quantitative,
              'random_seed': 2026102106,
              'full_transport_checks': len(families)+2*len(modified)+len(quantitative),
              'seconds': time.perf_counter() - start,
              'scope': 'integer Hall-constraint relaxation and two exact cutoff families; not exhaustive graph verification'}
    destination = HERE / 'stage3-hall-audit.json'
    destination.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'passed': True, 'full_transport_checks': result['full_transport_checks'],
                      'seconds': result['seconds'], 'output': str(destination)}), flush=True)


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Run without -O so verification assertions are enabled')
    run()
