"""Independent graph-realizable tests of the cost-three star formulas.

Run: python outputs/algorithm-frontier/stage3_cost_three_verify.py
Exhausts connected labeled graphs through order six, then seeded random
graphs and a large-common-neighborhood pendant family. Uses the original
full-neighborhood Bellman--Ford reference, not the proposed specialization.
Also checks the final single-matching criterion and actual optional backend.
Writes stage3-single-matching-verification.json beside this script; the earlier
two-matching verification result is preserved unchanged.
"""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
import hashlib
import platform
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/'frontier-scan'))
from curvature_probe import complement, connected, transport
sys.path.insert(0, str(HERE/'stage3'))
import star_transport


def maximum_matching(A, Z, adj):
    mate = {}
    def augment(t, seen):
        for u in A:
            if u not in adj[t] or u in seen:
                continue
            seen.add(u)
            if u not in mate or augment(mate[u], seen):
                mate[u] = t
                return True
        return False
    return sum(augment(t, set()) for t in Z)


def audit_edge(adj, h, k, x, y, stats, examples):
    stats['edges_inspected'] += 1
    if len(adj[x]) > len(adj[y]):
        x, y = y, x
    A, B, C = adj[x]-adj[y], adj[y]-adj[x], adj[x]&adj[y]
    bad = [(u,t) for u in A for t in B
           if t not in adj[u] and not (adj[u]&adj[t])]
    if not bad:
        stats['no_cost_three'] += 1
        return
    a,b = len(adj[x]),len(adj[y])
    d,M = b-a,a*len(B)
    bad_rows,bad_cols = {u for u,t in bad},{t for u,t in bad}
    row_star,column_star = len(bad_rows)==1,len(bad_cols)==1
    if len(adj)>4*k:
        assert row_star or column_star, (adj,x,y,k,bad)
        stats['large_order_star_checks'] += 1
    if len(C)>4*k-2:
        assert row_star or column_star, (adj,x,y,k,bad)
        stats['large_common_star_checks'] += 1
    Q = sorted(B-{x})
    records = []
    for mask in range(1<<len(Q)):
        S = {t for j,t in enumerate(Q) if mask>>j&1}
        p = sum(not (adj[u]&S) for u in A)
        q = sum(not (adj[u]&S) for u in C)
        L = len(S)+p-len(B)
        F = a*L+d*(p+q)
        records.append((S,L,F,p,q))
    delta = max(t[2] for t in records)
    assert delta>=0 and records[0][2]==0
    # Singleton nonpositivity is essential for the column-star argument.
    assert all(F<=0 for S,L,F,p,q in records if len(S)==1)
    if not (row_star or column_star):
        stats['nonstar_cost_three'] += 1
        return
    actual_curvature = transport(adj,x,y)
    actual_excess = (1-actual_curvature)*a*b-M
    assert actual_excess.denominator==1
    if column_star:
        assert actual_excess==delta, (adj,x,y,bad,actual_excess,delta)
        stats['column_star_checks'] += 1
    if row_star:
        z = next(iter(bad_rows))
        Z = bad_cols
        Qz = B-adj[z]
        restricted = [r for r in records if r[0]<=Z]
        delta_Z = max(r[2] for r in restricted)
        base = b-a*(len(B)-len(Qz))
        predicted = max(delta,base+delta_Z)
        assert actual_excess==predicted, (adj,x,y,bad,actual_excess,predicted)
        assert base<=next(r[2] for r in records if r[0]==Qz)<=delta
        stats['row_star_checks'] += 1
        if predicted>delta:
            stats['strict_row_correction'] += 1
        if delta_Z==0:
            stats['empty_restricted_maximum'] += 1
        if a>d*(k-1):
            # Include B itself: it has slope zero, while sets containing x
            # properly contained in B have negative slope and cannot maximize.
            full_records = records+[(set(B),0,0,0,0)]
            full_ell = max(r[1] for r in full_records)
            full_maximizers = [r[0] for r in full_records if r[1]==full_ell]
            full_S0 = set.intersection(*full_maximizers)
            full_entry = next(r for r in full_records if r[0]==full_S0)
            assert full_entry[1]==full_ell and full_entry[2]==delta
            assert full_ell==len(A)-maximum_matching(A,B,adj)
            trigger = d>0 and Qz==B-{x} and full_S0<=Z
            single_prediction = delta+(d if trigger else 0)
            assert single_prediction==predicted==actual_excess
            stats['single_matching_criterion_checks'] += 1
            stats['single_matching_corrections'] += int(trigger)
            if d>0 and Qz==B-{x}:
                assert full_S0<=Qz and full_entry[3]>=1
                assert delta>=a*full_ell+d
                if not full_S0<=Z and delta_Z>0:
                    assert delta-delta_Z>d
            if not full_S0:
                stats['empty_full_canonical_set'] += 1
            if full_S0==B:
                stats['full_B_canonical_set'] += 1
            maximum_L = max(r[1] for r in restricted)
            matching = maximum_matching(A,Z,adj)
            assert maximum_L==len(Z)-matching-d
            if maximum_L<0:
                canonical = 0
                stats['negative_restricted_slope'] += 1
            else:
                maximizers = [r[0] for r in restricted if r[1]==maximum_L]
                S0 = set.intersection(*maximizers)
                entry = next(r for r in records if r[0]==S0)
                assert entry[1]==maximum_L
                canonical = entry[2]
                if d:
                    assert len(S0)>=2 and x not in S0
                    s,t = sorted(S0)[:2]
                    q_from_pair = sum(u in C and S0<=h[u] for u in h[s]&h[t])
                    assert q_from_pair==entry[4]
                stats['nonnegative_restricted_slope'] += 1
            assert canonical==delta_Z
            stats['restricted_canonical_checks'] += 1
        if len(examples)<12 and (predicted>delta or column_star):
            examples.append({'n':len(adj),'edge':[x,y],'k':k,'a':a,'b':b,'c':len(C),
                             'bad_pairs':bad,'delta':delta,'delta_Z':delta_Z,
                             'row_base':base,'actual_excess':int(actual_excess)})
    production = star_transport.edge_curvature(adj,x,y,k,
        star_transport.preprocess(adj,k),allow_small_order=True)
    if production is None:
        stats['production_ineligible'] += 1
    else:
        value,proof = production
        assert value==actual_curvature, (adj,x,y,proof,actual_curvature)
        stats['production_star_checks'] += 1
    stats['full_transport_checks'] += 1


def audit_graph(adj, stats, examples):
    n=len(adj)
    if not connected(adj):
        return False
    h=[set(range(n))-{u}-adj[u] for u in range(n)]
    k=max(1,max((len(h[u]&h[v]) for u,v in combinations(range(n),2)),default=0))
    stats['graphs']+=1
    for x,y in combinations(range(n),2):
        if y in adj[x]:
            audit_edge(adj,h,k,x,y,stats,examples)
    return True


def run():
    start=time.perf_counter()
    names=('graphs','edges_inspected','no_cost_three','nonstar_cost_three',
           'full_transport_checks','column_star_checks','row_star_checks',
           'strict_row_correction','empty_restricted_maximum',
           'restricted_canonical_checks','negative_restricted_slope',
           'nonnegative_restricted_slope','large_common_star_checks',
           'large_order_star_checks','single_matching_criterion_checks',
           'single_matching_corrections','empty_full_canonical_set',
           'full_B_canonical_set','production_star_checks','production_ineligible')
    stats={name:0 for name in names}
    examples=[]
    exhaustive=[]
    for n in range(2,7):
        pairs=list(combinations(range(n),2))
        for mask in range(1<<len(pairs)):
            audit_graph(complement(n,[e for j,e in enumerate(pairs) if mask>>j&1]),stats,examples)
        exhaustive.append({'order':n,'cumulative':dict(stats)})
        print(json.dumps(exhaustive[-1]),flush=True)
    rng=random.Random(2026102107)
    for n in range(7,13):
        for trial in range(32):
            density=(.12,.25,.4,.6)[trial%4]
            adj=[set() for _ in range(n)]
            for u,v in combinations(range(n),2):
                if rng.random()<density:
                    adj[u].add(v);adj[v].add(u)
            audit_graph(adj,stats,examples)
    # The pendant source u=2 creates a row-star whose correction is essential.
    pendant=[]
    for c in (3,5,9,16,32,64):
        n=c+5;x,y,u,s,t=0,1,2,3,4
        adj=complement(n,[(u,v) for v in [y,s,t]+list(range(5,n))]+[(x,s),(x,t)])
        h=[set(range(n))-{v}-adj[v] for v in range(n)]
        audit_edge(adj,h,2,x,y,stats,examples)
        pendant.append({'common':c,'order':n})
    result={'passed':True,'python':platform.python_version(),'platform':platform.platform(),
            'seed':2026102107,'counts':stats,'exhaustive':exhaustive,
            'pendant_cases':pendant,'examples':examples,'seconds':time.perf_counter()-start,
            'production_source_sha256':hashlib.sha256((HERE/'stage3'/'star_transport.py').read_bytes()).hexdigest(),
            'scope':'graph-realizable cost-three star cases; no generic arbitrary matrix assertion'}
    destination=HERE/'stage3-single-matching-verification.json'
    destination.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'passed':True,'counts':stats,'seconds':result['seconds']}),flush=True)


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Run without -O; assertions are part of verification')
    run()
