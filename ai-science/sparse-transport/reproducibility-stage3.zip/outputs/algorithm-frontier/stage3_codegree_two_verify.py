"""Verify the complete complement-codegree-two curvature formula.

Run: python outputs/algorithm-frontier/stage3_codegree_two_verify.py
Exhausts all connected labeled graphs on 2..6 vertices whose complement
has distinct-pair codegree at most two. Uses the independent full-neighborhood
Bellman--Ford transport reference and exact fractions, plus all Hall subsets.
Writes a new result file; does not modify production or earlier results.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
import platform
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'frontier-scan'))
from curvature_probe import complement, connected, transport


def run():
    start = time.perf_counter()
    counts = Counter()
    by_order = []
    examples = {}
    for n in range(2, 7):
        pairs = list(combinations(range(n), 2))
        for mask in range(1 << len(pairs)):
            adj = complement(n, [e for j, e in enumerate(pairs) if mask >> j & 1])
            if not connected(adj):
                continue
            h = [set(range(n)) - {u} - adj[u] for u in range(n)]
            if any(len(h[u] & h[v]) > 2 for u, v in pairs):
                continue
            counts['graphs'] += 1
            for x0, y0 in pairs:
                if y0 not in adj[x0]:
                    continue
                x, y = x0, y0
                if len(adj[x]) > len(adj[y]):
                    x, y = y, x
                a, b = len(adj[x]), len(adj[y])
                A, B, C = adj[x] - adj[y], adj[y] - adj[x], adj[x] & adj[y]
                Q = B - {x}
                z = next(iter(A - {y})) if len(A) == 2 else None
                pattern = len(A) == 2 and len(B) == 3 and not (adj[z] & Q)
                pendant = pattern and len(adj[z]) == 1
                excess = (1 + int(pendant)) if pattern else 0
                predicted = Fraction(len(C), b) - Fraction(excess, a * b)
                actual = transport(adj, x, y)
                assert predicted == actual, (adj, x, y, predicted, actual)
                counts['transport_checks'] += 1
                records = []
                targets = sorted(Q)
                for subset_mask in range(1 << len(targets)):
                    S = {t for j, t in enumerate(targets) if subset_mask >> j & 1}
                    p = sum(not (adj[u] & S) for u in A)
                    q = sum(not (adj[u] & S) for u in C)
                    F = a * (len(S) + p - len(B)) + (b - a) * (p + q)
                    records.append((S, F, p, q))
                positives = [row for row in records if row[1] > 0]
                assert bool(positives) == pattern
                assert max(row[1] for row in records) == int(pattern)
                if pattern:
                    assert len(positives) == 1 and positives[0] == (Q, 1, 1, 0)
                    s, t = sorted(Q)
                    assert h[s] & h[t] == {x, z}
                    both_three = all(not (adj[z] & adj[v]) for v in Q)
                    assert both_three == pendant
                    counts['defective_edges'] += 1
                    counts['gap_two' if pendant else 'gap_one'] += 1
                    key = 'gap_two' if pendant else 'gap_one'
                    examples.setdefault(key, {'n': n, 'edge': [x, y], 'z': z,
                                             'adjacency': [sorted(row) for row in adj],
                                             'curvature': str(actual)})
                counts['hall_subset_checks'] += len(records)
        by_order.append({'n': n, 'cumulative': dict(counts)})
        print(json.dumps(by_order[-1]), flush=True)
    result = {'passed': True, 'python': platform.python_version(),
              'platform': platform.platform(), 'counts': dict(counts),
              'by_order': by_order, 'examples': examples,
              'seconds': time.perf_counter() - start,
              'scope': 'all connected labeled graphs n=2..6 with complement codegree <=2'}
    (HERE / 'stage3-codegree-two-verification.json').write_text(
        json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'passed': True, 'counts': dict(counts), 'seconds': result['seconds']}))


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Assertions must be enabled; run without -O.')
    run()
