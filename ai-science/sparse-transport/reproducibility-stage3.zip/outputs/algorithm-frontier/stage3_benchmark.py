"""Reproducible CPU benchmark; preserves all previous research scripts.

Run with Python 3.14 and the workspace-local scientific packages:
  python -B outputs/algorithm-frontier/stage3_benchmark.py --trials 5

Inputs are generated before timing. Every timed trial includes representation
construction, solving, and the checks implemented by its backend. The graph
baseline uses standard common-mass cancellation and an all-cost-one shortcut;
the SciPy graph baseline additionally uses assignment for equal degrees.
"""
from __future__ import annotations

import os
for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_name] = "1"
import sys
sys.dont_write_bytecode = True
from pathlib import Path
ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
sys.path.insert(0, str(WORKSPACE / "work" / "stage3-packages"))
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT.parent / "frontier-scan"))
import argparse
from collections import Counter, deque
from fractions import Fraction
from itertools import combinations
import gc
import hashlib
import json
import platform
import random
import statistics
import time
import warnings
import numpy as np
import scipy
from scipy.optimize import linprog, linear_sum_assignment, OptimizeWarning
from scipy.sparse import coo_matrix
import networkx as nx
import ot
import psutil
from threadpoolctl import threadpool_info, threadpool_limits
from adaptive_curvature import edge_curvature as adaptive, preprocess
from canonical_transport import edge_curvature as canonical
from batched_transport import transport_cost as batched
from curvature_probe import transport as full_integer_oracle
from general_complement import mincost as integer_matrix_oracle
from verify import cubic_family
from benchmark import instance as triple_instance

SEED = 2026102107
METHODS = ("batched_dense", "batched_segment", "networkx_simplex", "scipy_highs", "pot_emd")
GRAPH_METHODS = ("adaptive", "canonical_dispatch", "networkx_residual", "networkx_aggregated",
                 "scipy_dispatch", "scipy_aggregated_dispatch", "pot_aggregated_dispatch")
NUMERIC_TOL = 1e-7
MAX_LP_VARIABLES = 20000


class BudgetExceeded(Exception):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def cost_matrix(supplies, demands, exceptions):
    matrix = np.ones((len(supplies), len(demands)), dtype=np.int64)
    for i, row in enumerate(exceptions):
        for j, cost in row:
            matrix[i, j] = cost
    return matrix


def solve_highs(supplies, demands, exceptions):
    start = time.perf_counter()
    m, q = len(supplies), len(demands)
    if m*q > MAX_LP_VARIABLES:
        raise BudgetExceeded(f"HiGHS variable count {m*q} exceeds declared benchmark budget {MAX_LP_VARIABLES}")
    costs = cost_matrix(supplies, demands, exceptions)
    size = m*q
    ids = np.arange(size)
    row_ids = np.concatenate((np.repeat(np.arange(m), q), m+np.tile(np.arange(q), m)))
    mat = coo_matrix((np.ones(2*size), (row_ids, np.concatenate((ids, ids)))), shape=(m+q, size)).tocsr()
    rhs = np.asarray(supplies+demands, dtype=np.float64)
    built = time.perf_counter()
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Unrecognized options detected.*", category=OptimizeWarning)
        answer = linprog(costs.ravel().astype(float), A_eq=mat, b_eq=rhs,
                         bounds=(0, None), method="highs",
                         options={"threads": 1, "parallel": False,
                                  "primal_feasibility_tolerance": 1e-9,
                                  "dual_feasibility_tolerance": 1e-9})
    solved = time.perf_counter()
    assert answer.success, answer.message
    flow = np.rint(answer.x).astype(np.int64).reshape(m, q)
    rounding_error = float(np.max(np.abs(answer.x-flow.ravel())))
    assert rounding_error < NUMERIC_TOL
    assert np.all(flow >= 0)
    assert np.array_equal(flow.sum(axis=1), np.asarray(supplies))
    assert np.array_equal(flow.sum(axis=0), np.asarray(demands))
    objective = int(np.sum(costs*flow))
    # The solver is floating-point. This separately verifies an exact integer
    # primal-dual certificate when rounded equality marginals are feasible.
    dual = np.rint(answer.eqlin.marginals).astype(np.int64)
    dual_value = sum(int(x)*int(y) for x, y in zip(supplies+demands, dual))
    dual_ok = bool(np.all(dual[:m, None]+dual[None, m:] <= costs) and dual_value == objective)
    assert dual_ok, "HiGHS did not yield the anticipated exact rounded certificate"
    assert abs(float(answer.fun)-objective) < NUMERIC_TOL
    checked = time.perf_counter()
    return objective, {"build_seconds": built-start, "solve_seconds": solved-built,
                       "certificate_seconds": checked-solved, "variables": size,
                       "iterations": int(answer.nit), "exact_primal_dual_certificate": dual_ok,
                       "max_rounding_error": rounding_error, "numeric_solver": True}


def solve_pot(supplies, demands, exceptions):
    start=time.perf_counter()
    costs=cost_matrix(supplies,demands,exceptions)
    aa=np.asarray(supplies,dtype=np.float64);bb=np.asarray(demands,dtype=np.float64)
    matrix=costs.astype(np.float64)
    built=time.perf_counter()
    plan,log=ot.emd(aa,bb,matrix,log=True,center_dual=False,numThreads=1,numItermax=10000000)
    solved=time.perf_counter()
    assert log['warning'] is None,log
    flow=np.rint(plan).astype(np.int64)
    rounding_error=float(np.max(np.abs(plan-flow)))
    assert rounding_error<NUMERIC_TOL and np.all(flow>=0)
    assert np.array_equal(flow.sum(axis=1),np.asarray(supplies))
    assert np.array_equal(flow.sum(axis=0),np.asarray(demands))
    value=int(np.sum(flow*costs))
    u=np.rint(log['u']).astype(np.int64);v=np.rint(log['v']).astype(np.int64)
    dual_value=sum(int(x)*int(y) for x,y in zip(supplies,u))+sum(int(x)*int(y) for x,y in zip(demands,v))
    assert np.all(u[:,None]+v[None,:]<=costs) and dual_value==value
    assert abs(float(log['cost'])-value)<NUMERIC_TOL
    checked=time.perf_counter()
    return value,{'build_seconds':built-start,'solve_seconds':solved-built,
                  'certificate_seconds':checked-solved,'variables':len(supplies)*len(demands),
                  'exact_primal_dual_certificate':True,'max_rounding_error':rounding_error,'numeric_solver':True}


def solve_networkx(supplies, demands, exceptions):
    start = time.perf_counter()
    m, q = len(supplies), len(demands)
    costs = cost_matrix(supplies, demands, exceptions)
    graph = nx.DiGraph()
    graph.add_nodes_from((i, {"demand": -int(u)}) for i, u in enumerate(supplies))
    graph.add_nodes_from((m+j, {"demand": int(v)}) for j, v in enumerate(demands))
    total = sum(supplies)
    graph.add_weighted_edges_from((i, m+j, int(costs[i, j])) for i in range(m) for j in range(q))
    nx.set_edge_attributes(graph, total, "capacity")
    built = time.perf_counter()
    objective, flow = nx.network_simplex(graph)
    solved = time.perf_counter()
    target_sums = [0]*q
    checked_objective = 0
    for i, supply in enumerate(supplies):
        assert sum(flow[i].values()) == supply
        for j in range(q):
            amount = flow[i][m+j]
            assert isinstance(amount, int) and 0 <= amount <= total
            target_sums[j] += amount
            checked_objective += amount*int(costs[i, j])
    assert target_sums == demands and objective == checked_objective
    assert isinstance(objective, int)
    checked = time.perf_counter()
    return objective, {"build_seconds": built-start, "solve_seconds": solved-built,
                       "certificate_seconds": checked-solved, "variables": m*q,
                       "exact_primal_feasibility": True, "numeric_solver": False}


def solve_transport(method, supplies, demands, exceptions):
    if method.startswith("batched_"):
        value, proof = batched(supplies, demands, exceptions, certificate=True,
                               encoding=method.removeprefix("batched_"))
        return value, {"nodes": proof["nodes"], "arcs": proof["arcs"],
                       "stages": len(proof["stages"]), "phases": proof["phases"],
                       "augmentations": proof["augmentations"],
                       "exact_primal_dual_certificate": True, "numeric_solver": False}
    if method == "networkx_simplex":
        return solve_networkx(supplies, demands, exceptions)
    if method == "scipy_highs":
        return solve_highs(supplies, demands, exceptions)
    if method == "pot_emd":
        return solve_pot(supplies,demands,exceptions)
    raise ValueError(method)


def graph_from_edges(n, edges):
    adj = [set() for _ in range(n)]
    for u, v in edges:
        assert u != v
        adj[u].add(v); adj[v].add(u)
    return adj


def complement_from_edges(n, removed):
    adj = [set(range(n))-{i} for i in range(n)]
    for u, v in set(tuple(sorted(e)) for e in removed):
        adj[u].discard(v); adj[v].discard(u)
    return adj


def exact_codegree(adj):
    n = len(adj)
    h = [set(range(n))-{u}-adj[u] for u in range(n)]
    return max(1, max((len(h[u]&h[v]) for u, v in combinations(range(n), 2)), default=0))


def connected(adj):
    reached = {0}; queue = [0]
    for u in queue:
        for v in adj[u]-reached:
            reached.add(v); queue.append(v)
    return len(reached) == len(adj)


def choose_edges(adj, count, seed, marked=()):
    edges = [(u, v) for u in range(len(adj)) for v in sorted(adj[u]) if u < v]
    if count is None or len(edges) <= count:
        return edges
    chosen = list(dict.fromkeys(tuple(sorted(e)) for e in marked))
    assert all(v in adj[u] for u, v in chosen)
    remainder = [e for e in edges if e not in chosen]
    chosen += random.Random(seed).sample(remainder, count-len(chosen))
    return chosen


def graph_cases():
    out = []
    def add(name, adj, count=None, marked=(), provenance="synthetic", params=None):
        assert connected(adj), name
        edge_list = [(u,v) for u in range(len(adj)) for v in sorted(adj[u]) if u<v]
        selected=choose_edges(adj, count, SEED+len(out), marked)
        upper=[Fraction(len(adj[x]&adj[y]),max(len(adj[x]),len(adj[y]))) for x,y in selected]
        out.append({"name": name, "adj": adj, "k": exact_codegree(adj),
                    "selected": selected,"upper_bounds":upper,
                    "provenance": provenance, "parameters": params or {},
                    "n": len(adj), "edges": len(edge_list), "graph_sha256": digest(edge_list)})
    for name, graph in (("karate_club", nx.karate_club_graph()),
                        ("florentine_families", nx.florentine_families_graph()),
                        ("les_miserables", nx.les_miserables_graph())):
        graph = nx.convert_node_labels_to_integers(graph)
        add(name, graph_from_edges(len(graph), graph.edges()), provenance="NetworkX bundled empirical network; treated as unweighted simple graph",
            params={"networkx_generator": name+"_graph"})
    for n, p in ((24,.18),(24,.75),(64,.5),(96,.96)):
        rng = random.Random(SEED+int(100*p)+n)
        edges = {(i,i+1) for i in range(n-1)}
        edges |= {e for e in combinations(range(n),2) if rng.random()<p}
        add(f"connected_random_n{n}_p{p}", graph_from_edges(n, edges), None if n<=24 else 32,
            params={"p":p,"seed":SEED+int(100*p)+n,"connected_backbone":True})
    n=64; rng=random.Random(SEED+91)
    edges={(i,i+1) for i in range(n-1)}
    edges|={e for e in combinations(range(n),2) if rng.random()<(.6 if e[0]//32==e[1]//32 else .025)}
    add("two_community_n64",graph_from_edges(n,edges),32,params={"seed":SEED+91,"p_within":.6,"p_between":.025,"connected_backbone":True})
    add("complement_cycle_n96",complement_from_edges(96,[(i,(i+1)%96) for i in range(96)]),64)
    h=nx.random_regular_graph(4,96,seed=SEED+92)
    add("complement_regular4_n96",complement_from_edges(96,h.edges()),64,
        params={"degree":4,"seed":SEED+92})
    for k in (8,12,16,24):
        adj,_=cubic_family(k)
        add(f"cubic_defect_k{k}",adj,16 if k==8 else 8,[(0,1)],params={"k":k,"marked_edge":[0,1]})
    k=4;n=96;Z=list(range(2,k+1));S=list(range(k+1,2*k));T=list(range(2*k,3*k-2));R=list(range(3*k-2,4*k-2))
    removed=[(0,t) for t in S+T]+[(1,z) for z in Z]+[(z,t) for z in Z for t in S]+[(r,t) for r in R for t in (0,1)]
    add("persistent_defect_k4_n96",complement_from_edges(n,removed),16,[(0,1)],params={"k":k,"marked_edge":[0,1]})
    # u=2 is pendant at x=0 in G, so the marked edge necessarily uses cost 3.
    n=96;removed=[(2,v) for v in range(1,n) if v!=2]+[(0,3),(0,4)]
    add("pendant_cost3_n96",complement_from_edges(n,removed),16,[(0,1)],params={"marked_edge":[0,1]})
    k=4;W=list(range(3,k+1));S=list(range(k+1,2*k+1));T=list(range(2*k+1,k*k+1));R=list(range(k*k+1,k*k+k+1));n=k*k+k+1
    removed=[(0,v) for v in S+T]+[(2,v) for v in S+[1]]+[(u,v) for u in W for v in S]+[(r,v) for r in R for v in (0,1)]
    add("sharp_transient_k4",complement_from_edges(n,removed),None,params={"k":k,"marked_edge":[0,1]})
    add("path_n128",graph_from_edges(128,[(i,i+1) for i in range(127)]))
    add("cycle_n128",graph_from_edges(128,[(i,(i+1)%128) for i in range(128)]))
    # Same graph inputs, now querying every edge. These pairs of workloads
    # measure preprocessing amortization directly, not by extrapolation.
    for base in ("cubic_defect_k8","complement_cycle_n96","complement_regular4_n96"):
        original=next(g for g in out if g['name']==base)
        add(base+"_all_edges",original['adj'],None,provenance=original['provenance'],
            params={**original['parameters'],'same_graph_as':base,'workload':'all_edges'})
    return out


def matrix_cases():
    cases=[]
    for k in (8,16,24,32):
        s,d,e,expected=triple_instance(k)
        cases.append({"name":f"triple_cost12_k{k}","supplies":s,"demands":d,"exceptions":e,
                      "expected":expected,"generator":{"kind":"triple_mask","k":k,"cost":2}})
    for m,q,p,tag in ((64,64,.05,"few_exceptions"),(64,64,.5,"mixed"),
                       (64,64,.95,"mostly_exceptions"),(512,16,.1,"many_sources"),
                       (16,512,.1,"many_targets"),(128,128,.5,"balanced128")):
        seed=SEED+len(cases);rng=random.Random(seed)
        supplies=[q+rng.randrange(q+1) for _ in range(m)];total=sum(supplies)
        demands=[total//q+(j<total%q) for j in range(q)];rng.shuffle(demands)
        exceptions=[tuple((j,rng.choice((2,3))) for j in range(q) if rng.random()<p) for _ in range(m)]
        cases.append({"name":f"random_{tag}_{m}x{q}","supplies":supplies,"demands":demands,"exceptions":exceptions,
                      "generator":{"kind":"seeded_ternary","m":m,"q":q,"exception_probability":p,"seed":seed}})
    return cases


def residual_instance(adj,x,y):
    if len(adj[x])>len(adj[y]):x,y=y,x
    a,b=len(adj[x]),len(adj[y]);d=b-a
    A=sorted(adj[x]-adj[y]);B=sorted(adj[y]-adj[x]);C=list(adj[x]&adj[y]) if d else []
    sources=A+C
    supplies=[b]*len(A)+[d]*len(C)
    exceptions=[]
    for u in sources:
        row=[]
        for j,v in enumerate(B):
            if v not in adj[u]:
                row.append((j,2 if adj[u]&adj[v] else 3))
        exceptions.append(tuple(row))
    return a,b,a-len(A),supplies,[a]*len(B),exceptions


def scalar_shortcut(adj,x,y,k,data):
    h,common,_=data
    if len(adj[x])>len(adj[y]):x,y=y,x
    a,b=len(adj[x]),len(adj[y]);r=len(common[x][y]);beta=1+len(h[x])-r
    bk=max(k+1,2*k-2);large=len(adj)>=k*k+k+2
    return k==1 or beta>(bk if large else k*k-k+1) or (bk-beta)*a+(b-a)*(k-1)<=0


def graph_run(case, method):
    adj,k,selected=case["adj"],case["k"],case["selected"]
    start=time.perf_counter()
    data=preprocess(adj,k) if method in ("adaptive","canonical_dispatch") else None
    prepared=time.perf_counter();counts=Counter();answers=[];query_seconds=[];max_rows=max_targets=0
    for edge_index,(x,y) in enumerate(selected):
        query_start=time.perf_counter()
        if method in ("adaptive","canonical_dispatch"):
            outcome=None
            if method=="canonical_dispatch" and not scalar_shortcut(adj,x,y,k,data):
                outcome=canonical(adj,x,y,k,data)
                counts["canonical_used" if outcome is not None else "canonical_fallback"]+=1
            if outcome is None:outcome=adaptive(adj,x,y,k,data,certificate=True)
            value,meta=outcome
            counts["structural_shortcut"]+=int(meta["shortcut"])
            counts["primal_flow_calls"]+=int("network" in meta)
            max_rows=max(max_rows,meta.get("sources",meta.get("exclusive_sources",0)))
            max_targets=max(max_targets,meta.get("beta",meta.get("targets",0)))
        else:
            a,b,c,supplies,demands,exceptions=residual_instance(adj,x,y)
            if "aggregated" in method and not ((method.startswith("scipy") or method.startswith("pot")) and a==b):
                merged={}
                for supply,row in zip(supplies,exceptions):merged[row]=merged.get(row,0)+supply
                counts["rows_merged"]+=len(supplies)-len(merged)
                exceptions=list(merged);supplies=list(merged.values())
            max_rows=max(max_rows,len(supplies));max_targets=max(max_targets,len(demands))
            if not any(exceptions):
                cost=sum(supplies);counts["all_cost_one_shortcut"]+=1
            elif (method.startswith("scipy") or method.startswith("pot")) and a==b:
                mat=cost_matrix(supplies,demands,exceptions)
                ii,jj=linear_sum_assignment(mat)
                assert len(ii)==len(supplies)==len(demands) and len(set(jj))==len(jj)
                cost=a*int(mat[ii,jj].sum());counts["assignment_calls"]+=1
            else:
                name="networkx_simplex" if method.startswith("networkx") else ("pot_emd" if method.startswith("pot") else "scipy_highs")
                cost,proof=solve_transport(name,supplies,demands,exceptions)
                counts[name+"_calls"]+=1
                counts["exact_dual_certificates"]+=int(proof.get("exact_primal_dual_certificate",False))
            value=1-Fraction(cost,a*b)
        upper=case['upper_bounds'][edge_index]
        counts["triangle_equal"]+=int(value==upper)
        assert value<=upper
        answers.append(str(value))
        query_seconds.append(time.perf_counter()-query_start)
    finish=time.perf_counter()
    return answers,{"preprocess_seconds":prepared-start,"edge_seconds":finish-prepared,
                    "measured_total_seconds":finish-start,"counts":dict(counts),
                    "max_rows":max_rows,"max_targets":max_targets,
                    "query_seconds":query_seconds,
                    "pair_witness_updates":data[2] if data else 0}


def cpu_snapshot():
    t=psutil.cpu_times()
    return (t.user+t.system,t.user+t.system+t.idle)


def timed(call):
    gc.collect()
    before=cpu_snapshot();cpu=time.process_time();start=time.perf_counter()
    value,meta=call()
    wall=time.perf_counter()-start;own=time.process_time()-cpu;after=cpu_snapshot()
    host_fraction=(after[0]-before[0])/(after[1]-before[1]) if after[1]>before[1] else None
    return value,{"wall_seconds":wall,"process_cpu_seconds":own,"host_busy_fraction":host_fraction,
                  "rss_after_bytes":psutil.Process().memory_info().rss,"detail":meta}


def summary(trials):
    seconds=[r["wall_seconds"] for r in trials]
    return {"status":"complete","median_seconds":statistics.median(seconds),"min_seconds":min(seconds),"max_seconds":max(seconds),
            "mean_seconds":statistics.mean(seconds),"stdev_seconds":statistics.stdev(seconds) if len(seconds)>1 else 0,
            "median_process_cpu_seconds":statistics.median(r["process_cpu_seconds"] for r in trials),
            "trials":trials}


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--trials",type=int,default=5)
    parser.add_argument("--cpu",type=int,default=11);parser.add_argument("--quick",action="store_true")
    args=parser.parse_args();assert args.trials>=1
    proc=psutil.Process();original_affinity=proc.cpu_affinity()
    chosen=args.cpu if args.cpu in original_affinity else original_affinity[-1]
    proc.cpu_affinity([chosen])
    limits=threadpool_limits(limits=1)
    files=["batched_transport.py","adaptive_curvature.py","canonical_transport.py","stage3_benchmark.py",
           "verify.py","benchmark.py","../frontier-scan/curvature_probe.py","../frontier-scan/general_complement.py"]
    sources={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}
    output=ROOT/"stage3-benchmark.json"
    result={"status":"running","passed":False,"seed":SEED,"trials":args.trials,
            "started_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
            "environment":{"python":sys.version,"executable":sys.executable,"platform":platform.platform(),
                "processor":platform.processor(),"logical_cpus":os.cpu_count(),"cpu_affinity":[chosen],
                "original_affinity":original_affinity,"scipy":scipy.__version__,"numpy":np.__version__,
                "networkx":nx.__version__,"pot":ot.__version__,"psutil":psutil.__version__,"threadpools":threadpool_info(),
                "physical_cores":psutil.cpu_count(logical=False),"memory_total_bytes":psutil.virtual_memory().total,
                "thread_env":{n:os.environ[n] for n in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS")},
                "highs_options":{"threads":1,"parallel":False,"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9},
                "isolated_host":False,"gc":"enabled; explicit collection before each timed block"},
            "source_sha256":sources,"protocol":{"warmup":"one complete untimed run per case and method",
                "order":"seeded shuffle of methods separately in every trial; all orders recorded",
                "graph_input":"adjacency sets and supplied valid k available before timing; generation and exact k selection excluded",
                "equality_counting":"triangle upper bounds precomputed outside query clocks, used only for reporting equality counts and checking outputs",
                "graph_baselines":"standard common-mass cancellation; all-cost-one shortcut; SciPy/POT dispatch also uses SciPy assignment at equal degree; aggregated baselines merge identical rows by scanning sources",
                "highs_budget":"HiGHS omitted when a transport LP exceeds 20000 variables, a declared research-time budget after a slow pilot; all such cases retain native POT and exact NetworkX comparisons",
                "pilot":"Interrupted an initial incomplete run before adding POT, applying the explicit HiGHS size budget, and moving equality-count bookkeeping outside measured queries. A complete 19-graph exploratory run then motivated three additional all-edge counterparts. This record reports a fresh complete run of the final fixed 22-graph protocol; pilot timings are not included.",
                "graph_sampling":"all edges for small/empirical cases; fixed seeded selected edges otherwise, with marked hard edge where stated",
                "certificate_policy":"batched exact primal-dual internally; HiGHS/POT exact rounded primal-dual checked; NetworkX exact integer primal checked and objective agrees with independent exact dual; assignment feasible integer matching and cross-backend objective check",
                "numeric_status":"HiGHS, POT EMD and SciPy assignment are floating-point library algorithms; certified integer outputs do not make their algorithms exact arithmetic",
                "memory":"RSS after blocks, not peak or per-algorithm allocation"},"transport":[],"graphs":[]}
    def save():output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    save();started=time.perf_counter();rng=random.Random(SEED)
    try:
        mats=matrix_cases();graphs=graph_cases()
        if args.quick:mats=mats[:1]+mats[4:5];graphs=[g for g in graphs if g['name'] in ('karate_club','florentine_families','cubic_defect_k8','pendant_cost3_n96','path_n128')]
        for case in mats:
            s,d,e=case["supplies"],case["demands"],case["exceptions"]
            expected=case.get("expected");warm={};skipped={};active=[]
            for method in METHODS:
                try:value,proof=solve_transport(method,s,d,e)
                except BudgetExceeded as exc:
                    skipped[method]={'status':'not_run','reason':str(exc)};continue
                if expected is None:expected=value
                assert value==expected,(case["name"],method,value,expected)
                warm[method]=proof;active.append(method)
            oracle=None
            if len(s)*len(d)<=1024:
                oracle=integer_matrix_oracle(s,d,cost_matrix(s,d,e).tolist());assert oracle==expected
            trials={m:[] for m in active};orders=[]
            for trial in range(args.trials):
                order=list(active);rng.shuffle(order);orders.append(order)
                for method in order:
                    value,record=timed(lambda:solve_transport(method,s,d,e))
                    assert value==expected;trials[method].append(record)
            entry={"name":case["name"],"sources":len(s),"targets":len(d),"exception_incidence":sum(map(len,e)),
                   "mass":sum(s),"cost":expected,"generator":case["generator"],"input_sha256":digest([s,d,e]),
                   "integer_oracle_cost":oracle,"orders":orders,"methods":{**skipped,**{m:summary(trials[m]) for m in active}}}
            result["transport"].append(entry);save()
            print("transport",case["name"],{m:round(entry["methods"][m]["median_seconds"],6) for m in active},flush=True)
        for case in graphs:
            expected=None;skipped={};active=[]
            for method in GRAPH_METHODS:
                try:answer,detail=graph_run(case,method)
                except BudgetExceeded as exc:
                    skipped[method]={'status':'not_run','reason':str(exc)};continue
                if expected is None:expected=answer
                assert answer==expected,(case["name"],method)
                active.append(method)
            oracle_checks=[]
            if case["n"]<=34:
                for index in random.Random(SEED+case["n"]).sample(range(len(case["selected"])),min(5,len(case["selected"]))):
                    x,y=case["selected"][index];value=full_integer_oracle(case["adj"],x,y)
                    assert str(value)==expected[index]
                    oracle_checks.append({"edge":[x,y],"curvature":str(value)})
            trials={m:[] for m in active};orders=[]
            for trial in range(args.trials):
                order=list(active);rng.shuffle(order);orders.append(order)
                for method in order:
                    answer,record=timed(lambda:graph_run(case,method))
                    assert answer==expected;trials[method].append(record)
            entry={k:v for k,v in case.items() if k not in ("adj","selected","upper_bounds")}
            entry.update({"queried_edges":len(case["selected"]),"all_edges_queried":len(case["selected"])==case["edges"],
                          "selected_edges":case["selected"],"curvatures":expected,"orders":orders,
                          "full_integer_oracle_checks":oracle_checks,"methods":{**skipped,**{m:summary(trials[m]) for m in active}}})
            # Single queried-edge costs and reusable-index amortization, using
            # measured aggregate query cost. This is not an all-edge estimate.
            amort={}
            for m in active:
                prep=statistics.median(r["detail"]["preprocess_seconds"] for r in trials[m])
                edge=statistics.median(r["detail"]["edge_seconds"] for r in trials[m])/len(case["selected"])
                amort[m]={"median_preprocess_seconds":prep,"mean_query_seconds_within_median_batch":edge,
                          "cold_one_average_query_seconds":prep+edge,
                          "cold_first_query_seconds":statistics.median(r["detail"]["preprocess_seconds"]+r["detail"]["query_seconds"][0] for r in trials[m]),
                          "warm_first_query_seconds":statistics.median(r["detail"]["query_seconds"][0] for r in trials[m]),
                          "batch_amortized_seconds_per_query":prep/len(case["selected"])+edge}
            entry["amortization"]=amort
            result["graphs"].append(entry);save()
            print("graph",case["name"],"n",case["n"],"k",case["k"],"queries",entry["queried_edges"],
                  {m:round(entry["methods"][m]["median_seconds"],6) for m in active},flush=True)
        end_hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}
        assert sources==end_hashes,"Solver sources changed during the benchmark"
        result.update({"status":"complete","passed":True,"elapsed_seconds":time.perf_counter()-started,
                       "finished_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
                       "source_hashes_unchanged":True,"threadpools_after":threadpool_info()})
        save();print("complete",round(result["elapsed_seconds"],3),flush=True)
    except BaseException as exc:
        result.update({"status":"failed","error":repr(exc),"elapsed_seconds":time.perf_counter()-started})
        save();raise
    finally:
        limits.restore_original_limits();proc.cpu_affinity(original_affinity)


if __name__=="__main__":main()
