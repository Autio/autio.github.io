"""Bounded supplementary benchmark for the cost-three star matching extension.

Preserves stage3-benchmark.json. Reuses its conventional POT/assignment baseline.
Run: python -B outputs/algorithm-frontier/stage3_star_benchmark.py --trials 5
"""
from __future__ import annotations
import stage3_benchmark as base
from pathlib import Path
import sys
sys.path.insert(0,str(base.ROOT/'stage3'))
from star_transport import edge_curvature as star
import argparse, hashlib, json, platform, random, statistics, time
from collections import Counter
from fractions import Fraction
from itertools import combinations

ROOT=base.ROOT
SEED=2026102123
METHODS=('star_dispatch','canonical_dispatch','adaptive','pot_dispatch')


def cases():
    out=[]
    def add(name,adj,count=None,marked=(),expected_kind=None,formula=None):
        assert base.connected(adj)
        selected=base.choose_edges(adj,count,SEED+len(out),marked)
        all_edges=[(u,v) for u in range(len(adj)) for v in sorted(adj[u]) if u<v]
        out.append({'name':name,'adj':adj,'n':len(adj),'k':base.exact_codegree(adj),
                    'edges':len(all_edges),'selected':selected,'expected_kind':expected_kind,
                    'formula':formula,'graph_sha256':base.digest(all_edges),
                    'upper':[Fraction(len(adj[x]&adj[y]),max(len(adj[x]),len(adj[y]))) for x,y in selected]})
    for c in (10,50,200,500):
        n=c+5
        removed=[(2,v) for v in range(1,n) if v!=2]+[(0,3),(0,4)]
        adj=base.complement_from_edges(n,removed)
        formula=str(Fraction(c,c+3)-Fraction(2,(c+2)*(c+3)))
        add(f'row_star_c{c}_marked',adj,1,[(0,1)],'cost_three_row_star',formula)
        if c==200:add('row_star_c200_batch16',adj,16,[(0,1)],'cost_three_row_star',formula)
    for c in (10,50,200):
        # A={y,s1,s2}, B={x,v,t1,t2}; v is pendant at y in G.
        # A complement K4 on common vertices raises actual k to 3, so the
        # scalar filter does not dispose of the marked column-star instance.
        n=c+7;C=list(range(7,n))
        removed=[(2,v) for v in range(n) if v not in (1,2)]
        removed += [(1,3),(1,4),(0,5),(0,6)] + list(combinations(C[:4],2))
        adj=base.complement_from_edges(n,removed)
        add(f'column_star_c{c}_marked',adj,1,[(0,1)],'cost_three_column_star')
        if c==200:add('column_star_c200_batch16',adj,16,[(0,1)],'cost_three_column_star')
    for k in (8,16):
        adj,_=base.cubic_family(k)
        add(f'cubic_k{k}_batch8',adj,8,[(0,1)],'one_two_cost')
    graph=base.nx.convert_node_labels_to_integers(base.nx.karate_club_graph())
    add('karate_all',base.graph_from_edges(len(graph),graph.edges()))
    add('path64_all',base.graph_from_edges(64,[(i,i+1) for i in range(63)]))
    for prefix in ('row_star','column_star'):
        original=next(g for g in out if g['name']==prefix+'_c50_marked')
        add(prefix+'_c50_all',original['adj'],expected_kind=original['expected_kind'],formula=original['formula'])
    return out


def run(case,method,cached=None):
    adj,k=case['adj'],case['k'];start=time.perf_counter()
    data=(cached if cached is not None else base.preprocess(adj,k)) if method!='pot_dispatch' else None
    prepared=time.perf_counter();values=[];counts=Counter();proofs=[];query_seconds=[]
    for index,(x,y) in enumerate(case['selected']):
        query_start=time.perf_counter()
        if method=='pot_dispatch':
            a,b,c,supplies,demands,exceptions=base.residual_instance(adj,x,y)
            if a!=b:
                merged={}
                for supply,row in zip(supplies,exceptions):merged[row]=merged.get(row,0)+supply
                counts['rows_merged']+=len(supplies)-len(merged)
                exceptions=list(merged);supplies=list(merged.values())
            if not any(exceptions):
                cost=sum(supplies);meta={'case':'all_cost_one'}
            elif a==b:
                mat=base.cost_matrix(supplies,demands,exceptions)
                ii,jj=base.linear_sum_assignment(mat)
                assert len(ii)==len(supplies)==len(demands) and len(set(jj))==len(jj)
                cost=a*int(mat[ii,jj].sum());meta={'case':'assignment'}
            else:
                cost,meta=base.solve_pot(supplies,demands,exceptions)
                meta['case']='pot_emd'
            value=1-Fraction(cost,a*b)
            counts[meta['case']]+=1
        else:
            outcome=None
            if method=='star_dispatch':
                outcome=star(adj,x,y,k,data)
                counts['star_used' if outcome is not None else 'star_fallback']+=1
            elif method=='canonical_dispatch' and not base.scalar_shortcut(adj,x,y,k,data):
                outcome=base.canonical(adj,x,y,k,data)
                counts['canonical_used' if outcome is not None else 'canonical_fallback']+=1
            if outcome is None:outcome=base.adaptive(adj,x,y,k,data,certificate=True)
            value,meta=outcome
            counts['structural_shortcut']+=int(meta['shortcut'])
            counts['primal_flow_calls']+=int('network' in meta)
            if 'case' in meta:counts[meta['case']]+=1
        assert value<=case['upper'][index]
        counts['triangle_equal']+=int(value==case['upper'][index])
        values.append(str(value));proofs.append(meta)
        query_seconds.append(time.perf_counter()-query_start)
    return values,{'preprocess_seconds':prepared-start,'query_seconds':query_seconds,
                   'counts':dict(counts),'first_query_proof':proofs[0],
                   'edge_seconds':time.perf_counter()-prepared}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--trials',type=int,default=5)
    args=parser.parse_args();assert args.trials>=1
    proc=base.psutil.Process();original=proc.cpu_affinity();cpu=11 if 11 in original else original[-1]
    proc.cpu_affinity([cpu]);limits=base.threadpool_limits(limits=1)
    files=['stage3_star_benchmark.py','stage3_benchmark.py','stage3/star_transport.py',
           'adaptive_curvature.py','canonical_transport.py','batched_transport.py']
    hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}
    result={'status':'running','passed':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
      'seed':SEED,'trials':args.trials,'source_sha256':hashes,
      'environment':{'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),
        'numpy':base.np.__version__,'scipy':base.scipy.__version__,'networkx':base.nx.__version__,
        'pot':base.ot.__version__,'cpu_affinity':[cpu],'threadpools':base.threadpool_info(),
        'isolated_host':False,'concurrent_work':'parent research verification and compilation may run'},
      'protocol':{'scope':'supplement, not replacement of prior 22-workload benchmark',
        'pilot':'An initial complete 13-workload two-matching pilot motivated two genuine all-edge cost-three family workloads. A complete 15-workload two-matching run followed. The final implementation then changed to one canonical matching with an exact row-star correction criterion, justifying this fresh rerun of the same fixed 15-workload protocol. Only single-matching timings appear in this final JSON; none are mixed with either two-matching pilot. The original 22-workload comparison is untouched. The two-matching prototype is preserved separately as stage3/star_transport_two_matching.py.',
        'algorithm_version':'single canonical matching; row correction d iff sole cost-one target is anchor and canonical set lies in cost-three targets',
        'warmup':'one untimed complete run of each method in each mode per case',
        'order':'all eight method/mode configurations shuffled independently each trial',
        'cold':'fresh global index in every measured indexed batch, including return-time destruction',
        'warm':'one prebuilt shared index, measured query batch only; POT still builds its per-query residual',
        'input':'adjacency, query list, actual k and equality reporting bounds prepared outside timing',
        'fallback':'None from optional star/canonical invokes adaptive exact flow',
        'certificate':'star matching/witness metadata without full transport plan; exact equality with checked POT/assignment and adaptive flow outputs',
        'memory':'RSS after blocks, not peak; largest graph order 505',
        'numeric':'POT floating-point EMD checked by exact rounded integer primal-dual certificate; assignment checked feasible and cross-backend objective'},
      'graphs':[]}
    output=ROOT/'stage3-star-benchmark.json'
    def save():output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    save();started=time.perf_counter();rng=random.Random(SEED)
    try:
        for case in cases():
            data=base.preprocess(case['adj'],case['k'])
            a,b,c,s,d,e=base.residual_instance(case['adj'],*case['selected'][0])
            bad=[(i,j) for i,row in enumerate(e) for j,cost in row if cost==3]
            expected=None;configs=[(mode,m) for mode in ('cold','warm') for m in METHODS]
            for mode,method in configs:
                values,proof=run(case,method,data if mode=='warm' else None)
                if expected is None:expected=values
                assert values==expected,(case['name'],mode,method)
                if method=='star_dispatch' and case['expected_kind']:
                    assert proof['first_query_proof']['case']==case['expected_kind'],proof
                    assert proof['first_query_proof']['common_rows_materialized']==0
                    if case['expected_kind']=='cost_three_row_star':
                        assert proof['first_query_proof']['restricted']['single_matching_criterion']
                        assert proof['first_query_proof']['restricted']['computed'] is False
            if case['formula'] is not None:assert expected[0]==case['formula']
            if case['expected_kind']=='cost_three_row_star':assert len({i for i,j in bad})==1 and len(bad)>=2
            if case['expected_kind']=='cost_three_column_star':assert len({j for i,j in bad})==1 and len(bad)>=2
            trials={mode+':'+method:[] for mode,method in configs};orders=[]
            for trial in range(args.trials):
                order=list(configs);rng.shuffle(order);orders.append(order)
                for mode,method in order:
                    values,record=base.timed(lambda:run(case,method,data if mode=='warm' else None))
                    assert values==expected
                    trials[mode+':'+method].append(record)
            entry={k:v for k,v in case.items() if k not in ('adj','selected','upper')}
            entry.update({'selected_edges':case['selected'],'queried_edges':len(case['selected']),
                'all_edges_queried':len(case['selected'])==case['edges'],'curvatures':expected,
                'marked_residual':{'sources':len(s),'targets':len(d),'a':a,'b':b,'common':c,
                                   'cost_three_pairs_by_index':bad},
                'orders':orders,'methods':{key:base.summary(records) for key,records in trials.items()}})
            result['graphs'].append(entry);save()
            print(case['name'],{key:round(m['median_seconds']*1000,4) for key,m in entry['methods'].items()},flush=True)
        assert hashes=={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},'Source changed during timing'
        result.update({'status':'complete','passed':True,'source_hashes_unchanged':True,
                       'elapsed_seconds':time.perf_counter()-started,
                       'finished_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
        save();print('complete',result['elapsed_seconds'],flush=True)
    except BaseException as exc:
        result.update({'status':'failed','error':repr(exc)});save();raise
    finally:limits.restore_original_limits();proc.cpu_affinity(original)


if __name__=='__main__':main()
