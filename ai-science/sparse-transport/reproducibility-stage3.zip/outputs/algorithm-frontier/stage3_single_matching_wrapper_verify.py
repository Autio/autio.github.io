"""Reproduce the final single-matching all-orders wrapper cross-check.

Run: python outputs/algorithm-frontier/stage3_single_matching_wrapper_verify.py
Writes stage3-single-matching-wrapper-check.json; never edits solver sources.
"""
from pathlib import Path
from itertools import combinations
import hashlib
import json
import platform
import random
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'stage3'))
import star_transport as star
from curvature_probe import complement,connected,transport


def run():
    start=time.perf_counter()
    graphs=edges=fallbacks=0
    cases=[]
    for n in range(2,6):
        pairs=list(combinations(range(n),2))
        for mask in range(1<<len(pairs)):
            adj=complement(n,[e for j,e in enumerate(pairs) if mask>>j&1])
            if connected(adj):cases.append(adj)
    rng=random.Random(2026102108)
    for n in range(6,11):
        for trial in range(20):
            adj=[set() for _ in range(n)]
            for u,v in combinations(range(n),2):
                if rng.random()<(.2,.4,.7,.9)[trial%4]:
                    adj[u].add(v);adj[v].add(u)
            if connected(adj):cases.append(adj)
    for adj in cases:
        n=len(adj)
        h=[set(range(n))-{u}-adj[u] for u in range(n)]
        k=max(1,max(len(h[u]&h[v]) for u,v in combinations(range(n),2)))
        got,meta=star.all_curvatures(adj,k)
        expected={(x,y):transport(adj,x,y)
                  for x,y in combinations(range(n),2) if y in adj[x]}
        assert got==expected
        graphs+=1;edges+=len(got);fallbacks+=meta['star_fallbacks']
    result={'passed':True,'graphs':graphs,'edges':edges,'fallbacks':fallbacks,
            'seconds':time.perf_counter()-start,'seed':2026102108,
            'source_sha256':hashlib.sha256((HERE/'stage3'/'star_transport.py').read_bytes()).hexdigest(),
            'python':platform.python_version(),'platform':platform.platform()}
    (HERE/'stage3-single-matching-wrapper-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Run without -O; assertions verify the result')
    run()
