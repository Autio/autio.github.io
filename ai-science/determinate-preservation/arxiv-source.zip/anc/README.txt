Reproducibility materials for Determinate Preservation, Petri Mikael Autio.
Run the six verify_*.py programs with Python 3 from this directory. Standard library only. The programs supplement the written proofs; they do not formally verify all homotopy statements. See the paper appendix for scope. Reader data record editorial structure, not assertions of logical dependence.
